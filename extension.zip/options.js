document.addEventListener('DOMContentLoaded', () => {
    const loadingElement = document.getElementById('loading');
    const errorElement = document.getElementById('error');
    const amountSpan = document.getElementById('amount');
    const totalEarningsSection = document.getElementById('totalEarningsSection');
    const projectEarningsSection = document.getElementById('projectEarningsSection');
    const projectEarningsList = document.getElementById('projectEarningsList');

    // Audio settings elements
    const energyThresholdInput = document.getElementById('energyThreshold');
    const variationThresholdInput = document.getElementById('variationThreshold');
    const zeroCrossingThresholdInput = document.getElementById('zeroCrossingThreshold');
    const minSegmentDurationInput = document.getElementById('minSegmentDuration');
    const segmentVariationThresholdInput = document.getElementById('segmentVariationThreshold');

    const energyThresholdValue = document.getElementById('energyThresholdValue');
    const variationThresholdValue = document.getElementById('variationThresholdValue');
    const zeroCrossingThresholdValue = document.getElementById('zeroCrossingThresholdValue');
    const minSegmentDurationValue = document.getElementById('minSegmentDurationValue');
    const segmentVariationThresholdValue = document.getElementById('segmentVariationThresholdValue');

    const saveAudioSettingsButton = document.getElementById('saveAudioSettings');
    const resetAudioSettingsButton = document.getElementById('resetAudioSettings');
    const settingsSavedMessage = document.getElementById('settingsSaved');

    // Text classifications elements
    const classificationsListContainer = document.getElementById('classificationsListContainer');
    const noClassificationsDiv = document.getElementById('noClassifications');
    const classificationsTable = document.getElementById('classificationsTable');
    const classificationsList = document.getElementById('classificationsList');
    const clearClassificationsButton = document.getElementById('clearClassifications');

    // Arabic Evaluation settings elements
    const defaultSelectionInput = document.getElementById('defaultSelection');
    const textLengthThresholdInput = document.getElementById('textLengthThreshold');
    const addRuleButton = document.getElementById('addRule');
    const rulesList = document.getElementById('rules-list');
    const ruleTemplate = document.getElementById('rule-template');
    const saveArabicSettingsButton = document.getElementById('saveArabicSettings');
    const resetArabicSettingsButton = document.getElementById('resetArabicSettings');
    const arabicSettingsSavedMessage = document.getElementById('arabicSettingsSaved');

    // New Audio Answers elements
    const audioAnswersListContainer = document.getElementById('audioAnswersListContainer');
    const noAudioAnswersDiv = document.getElementById('noAudioAnswers');
    const audioAnswersTable = document.getElementById('audioAnswersTable');
    const audioAnswersList = document.getElementById('audioAnswersList');
    const paginationControls = document.getElementById('paginationControls');
    const exportDataButton = document.getElementById('exportData');
    const exportForFriendButton = document.getElementById('exportForFriend');
    const importFileInput = document.getElementById('importFile');
    const clearAnswersButton = document.getElementById('clearAnswers');

    // Manual dates elements
    const newManualDateInput = document.getElementById('newManualDate');
    const addManualDateBtn = document.getElementById('addManualDateBtn');
    const manualDatesList = document.getElementById('manualDatesList');

    const ITEMS_PER_PAGE = 10;
    let currentPage = 1;
    let allAudioAnswers = [];
    let filteredAudioAnswers = [];
    let searchQuery = '';
    let debugLoggingEnabled = false;
    let showClickIndicator = false;

    // Search input
    const audioSearchInput = document.getElementById('audioSearchInput');
    const searchResultCount = document.getElementById('searchResultCount');

    // Default audio settings
    const defaultSettings = {
        energyThreshold: 0.001,
        variationThreshold: 0.4,
        zeroCrossingThreshold: 0.35,
        minSegmentDuration: 6,
        segmentVariationThreshold: 0.15
    };

    // Default Arabic evaluation settings
    const defaultArabicSettings = {
        defaultSelection: 'ok',
        textLengthThreshold: 500,
        rules: []
    };

    function displayError() {
        if (loadingElement) loadingElement.style.display = 'none';
        if (totalEarningsSection) totalEarningsSection.style.display = 'none';
        if (projectEarningsSection) projectEarningsSection.style.display = 'none';
        if (errorElement) errorElement.style.display = 'block';
    }

    function displayEarnings(totalAmount, projectData) {
        if (loadingElement) loadingElement.style.display = 'none';
        if (errorElement) errorElement.style.display = 'none';
        if (totalEarningsSection) totalEarningsSection.style.display = 'block';
        if (projectEarningsSection) projectEarningsSection.style.display = 'block';
        if (amountSpan) amountSpan.textContent = totalAmount.toFixed(2) + ' $';

        if (projectEarningsList) {
            projectEarningsList.innerHTML = '';
            if (projectData && projectData.length > 0) {
                projectData.forEach(project => {
                    const listItem = document.createElement('li');
                    const taskCountText = project.taskCount ? ` (${project.taskCount} pages)` : '';
                    const poolText = project.poolInfo ? ` ${project.poolInfo}` : '';
                    const timeText = project.totalTime ? ` - Time: ${project.totalTime}` : '';

                    listItem.textContent = `${project.name}: ${project.totalReward.toFixed(2)} $${taskCountText}${poolText}${timeText}`;
                    projectEarningsList.appendChild(listItem);
                });
            } else {
                const listItem = document.createElement('li');
                listItem.textContent = 'No project earnings details available.';
                projectEarningsList.appendChild(listItem);
            }
        }
    }

    function fetchDailyEarnings() {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, '0');
        const day = String(today.getDate()).padStart(2, '0');
        const formattedDate = `${year}-${month}-${day}`;
        const projectEarningsApiUrl = `https://yang.yandex-team.ru/crowd/api/worker/income/history/day?day=${formattedDate}`;

        fetch(projectEarningsApiUrl, { headers: { 'Accept': 'application/json' } })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status} for URL: ${response.url}`);
                }
                return response.json();
            })
            .then(projectEarningsResponse => {
                let totalRewardValue = 0;
                let projectEarningsDetails = [];

                if (Array.isArray(projectEarningsResponse) && projectEarningsResponse.length > 0 && projectEarningsResponse[0].projects) {
                    projectEarningsDetails = projectEarningsResponse[0].projects.map(proj => {
                        const stats = calculateProjectStats(proj.assignments || []);
                        return {
                            name: proj.project.name,
                            totalReward: proj.totalReward,
                            taskCount: proj.assignments ? proj.assignments.length : 0,
                            poolInfo: stats.poolInfo,
                            totalTime: stats.totalTimeFormatted
                        };
                    });
                    totalRewardValue = projectEarningsDetails.reduce((sum, project) => sum + project.totalReward, 0);
                } else {
                    console.warn("Project Earnings Data format incorrect or projects array missing:", projectEarningsResponse);
                }
                displayEarnings(totalRewardValue, projectEarningsDetails);
            })
            .catch(error => {
                console.error("Fetch error:", error);
                displayError();
            });
    }

    function calculateProjectStats(assignments) {
        if (!assignments || assignments.length === 0) {
            return { poolInfo: '', totalTimeFormatted: '00:00:00' };
        }

        // Sort by submit date (oldest first)
        const sorted = [...assignments].sort((a, b) => new Date(a.submitDate) - new Date(b.submitDate));

        // 1. Calculate Pools
        const pools = [];
        let currentPoolId = null;
        let currentCount = 0;

        sorted.forEach(a => {
            if (a.poolId !== currentPoolId) {
                if (currentPoolId !== null) {
                    pools.push(currentCount);
                }
                currentPoolId = a.poolId;
                currentCount = 1;
            } else {
                currentCount++;
            }
        });
        if (currentPoolId !== null) pools.push(currentCount);

        const poolInfo = pools.length > 0 ? `(Pools: ${pools.join(', ')})` : '';

        // 2. Calculate Total Time (excluding > 5 min breaks)
        let totalTimeMs = 0;
        for (let i = 0; i < sorted.length - 1; i++) {
            const current = new Date(sorted[i].submitDate);
            const next = new Date(sorted[i + 1].submitDate);
            const diff = next - current;

            // Only count if diff is less than 5 minutes (300000 ms)
            if (diff < 300000) {
                totalTimeMs += diff;
            }
            // Add a base time per task? Usually time is diff between tasks. 
            // The last task has no "next", so its time isn't counted in this diff method 
            // unless we had start times. Assuming average duration for last task or ignoring it.
            // Strict interpretation of user request: "excluding breaks longer than 5 minutes" implies summing gaps.
        }

        // Add minimal time for single/last task if total is 0 to avoid confusion, 
        // or just accept sum of intervals. Let's stick to sum of valid intervals.

        const seconds = Math.floor((totalTimeMs / 1000) % 60);
        const minutes = Math.floor((totalTimeMs / (1000 * 60)) % 60);
        const hours = Math.floor((totalTimeMs / (1000 * 60 * 60)));

        const pad = (num) => String(num).padStart(2, '0');
        const totalTimeFormatted = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;

        return { poolInfo, totalTimeFormatted };
    }

    function loadTextClassifications() {
        // Classifications are now merged into Arabic Settings rules
        // This function is kept for backward compatibility but does nothing visible
    }

    function clearTextClassifications() {
        if (confirm('Are you sure you want to clear all text classifications?')) {
            chrome.storage.local.set({ textClassifications: [] }, () => {
                loadTextClassifications();
            });
        }
    }

    function loadAudioSettings() {
        chrome.storage.local.get('audioSettings', (data) => {
            const settings = data.audioSettings || defaultSettings;
            if (energyThresholdInput) energyThresholdInput.value = settings.energyThreshold;
            if (variationThresholdInput) variationThresholdInput.value = settings.variationThreshold;
            if (zeroCrossingThresholdInput) zeroCrossingThresholdInput.value = settings.zeroCrossingThreshold;
            if (minSegmentDurationInput) minSegmentDurationInput.value = settings.minSegmentDuration;
            if (segmentVariationThresholdInput) segmentVariationThresholdInput.value = settings.segmentVariationThreshold;
            updateDisplayedValues();
        });
        // Load debug logging toggle
        const debugToggle = document.getElementById('debugLoggingToggle');
        chrome.storage.local.get('debugLogging', (data) => {
            debugLoggingEnabled = !!data.debugLogging;
            if (debugToggle) debugToggle.checked = debugLoggingEnabled;
        });

        // Load click indicator toggle
        const indicatorToggle = document.getElementById('showClickIndicator');
        chrome.storage.local.get('showClickIndicator', (data) => {
            showClickIndicator = !!data.showClickIndicator;
            if (indicatorToggle) indicatorToggle.checked = showClickIndicator;
        });

        // Load click result toggle
        const clickResultToggle = document.getElementById('showClickResult');
        chrome.storage.local.get('showClickResult', (data) => {
            if (clickResultToggle) clickResultToggle.checked = !!data.showClickResult;
        });
    }

    function saveAudioSettings() {
        const settings = {
            energyThreshold: parseFloat(energyThresholdInput.value),
            variationThreshold: parseFloat(variationThresholdInput.value),
            zeroCrossingThreshold: parseFloat(zeroCrossingThresholdInput.value),
            minSegmentDuration: parseInt(minSegmentDurationInput.value),
            segmentVariationThreshold: parseFloat(segmentVariationThresholdInput.value)
        };

        chrome.storage.local.set({ audioSettings: settings }, () => {
            console.log('Audio settings saved');
            chrome.runtime.sendMessage({ action: 'audioSettingsUpdated', settings: settings });
            showSavedMessage(settingsSavedMessage);
        });
    }

    function resetAudioSettings() {
        if (energyThresholdInput) energyThresholdInput.value = defaultSettings.energyThreshold;
        if (variationThresholdInput) variationThresholdInput.value = defaultSettings.variationThreshold;
        if (zeroCrossingThresholdInput) zeroCrossingThresholdInput.value = defaultSettings.zeroCrossingThreshold;
        if (minSegmentDurationInput) minSegmentDurationInput.value = defaultSettings.minSegmentDuration;
        if (segmentVariationThresholdInput) segmentVariationThresholdInput.value = defaultSettings.segmentVariationThreshold;
        updateDisplayedValues();
        saveAudioSettings();
    }

    function updateDisplayedValues() {
        if (energyThresholdValue && energyThresholdInput) energyThresholdValue.textContent = parseFloat(energyThresholdInput.value).toFixed(4);
        if (variationThresholdValue && variationThresholdInput) variationThresholdValue.textContent = parseFloat(variationThresholdInput.value).toFixed(2);
        if (zeroCrossingThresholdValue && zeroCrossingThresholdInput) zeroCrossingThresholdValue.textContent = parseFloat(zeroCrossingThresholdInput.value).toFixed(2);
        if (minSegmentDurationValue && minSegmentDurationInput) minSegmentDurationValue.textContent = minSegmentDurationInput.value;
        if (segmentVariationThresholdValue && segmentVariationThresholdInput) segmentVariationThresholdValue.textContent = parseFloat(segmentVariationThresholdInput.value).toFixed(2);
    }

    function showSavedMessage(messageElement) {
        if (messageElement) {
            messageElement.style.display = 'block';
            setTimeout(() => {
                messageElement.style.display = 'none';
            }, 3000);
        }
    }

    function loadArabicSettings() {
        chrome.storage.local.get(['arabicSettings', 'textClassifications'], (data) => {
            const settings = data.arabicSettings || defaultArabicSettings;
            const classifications = data.textClassifications || [];

            if (defaultSelectionInput) defaultSelectionInput.value = settings.defaultSelection;
            if (textLengthThresholdInput) textLengthThresholdInput.value = settings.textLengthThreshold || defaultArabicSettings.textLengthThreshold;
            if (rulesList) rulesList.innerHTML = ''; // Clear existing rules

            // Add rules from arabicSettings
            settings.rules.forEach(rule => addRuleToUI(rule.pattern, rule.action));

            // Also add classifications as rules (marked with source)
            classifications.forEach(item => {
                // Check if this pattern already exists in rules to avoid duplicates
                const existsInRules = settings.rules.some(r => r.pattern === item.text);
                if (!existsInRules) {
                    addRuleToUI(item.text, item.classification, true); // true = from context menu
                }
            });
        });
    }

    function saveArabicSettings() {
        const rules = [];
        if (rulesList) {
            rulesList.querySelectorAll('.rule-container').forEach(ruleDiv => {
                if (ruleDiv.id === 'rule-template') return; // Skip template
                const patternInput = ruleDiv.querySelector('.rule-pattern');
                const actionSelect = ruleDiv.querySelector('.rule-action');
                if (patternInput && actionSelect && patternInput.value.trim() !== '') {
                    rules.push({
                        pattern: patternInput.value.trim(),
                        action: actionSelect.value
                    });
                }
            });
        }

        const settings = {
            defaultSelection: defaultSelectionInput ? defaultSelectionInput.value : 'ok',
            textLengthThreshold: textLengthThresholdInput ? parseInt(textLengthThresholdInput.value) : defaultArabicSettings.textLengthThreshold,
            rules: rules
        };

        chrome.storage.local.set({ arabicSettings: settings }, () => {
            console.log('Arabic settings saved');
            showSavedMessage(arabicSettingsSavedMessage);
        });
    }

    function resetArabicSettings() {
        if (defaultSelectionInput) defaultSelectionInput.value = defaultArabicSettings.defaultSelection;
        if (textLengthThresholdInput) textLengthThresholdInput.value = defaultArabicSettings.textLengthThreshold;
        if (rulesList) {
            rulesList.innerHTML = ''; // Clear UI rules
            defaultArabicSettings.rules.forEach(rule => addRuleToUI(rule.pattern, rule.action)); // Add default rules to UI
        }
        saveArabicSettings(); // Save the reset state
    }

    function addRuleToUI(pattern = '', action = 'mistake', fromContextMenu = false) {
        if (!ruleTemplate || !rulesList) return;

        const newRuleDiv = ruleTemplate.cloneNode(true);
        newRuleDiv.style.display = 'flex'; // Make it visible
        newRuleDiv.removeAttribute('id'); // Remove template ID
        if (fromContextMenu) {
            newRuleDiv.dataset.fromContextMenu = 'true';
            newRuleDiv.style.borderLeft = '3px solid #2ecc71';
            newRuleDiv.title = 'Added via right-click context menu';
        }

        const patternInput = newRuleDiv.querySelector('.rule-pattern');
        const actionSelect = newRuleDiv.querySelector('.rule-action');
        const removeButton = newRuleDiv.querySelector('.remove-rule');

        if (patternInput) patternInput.value = pattern;
        if (actionSelect) actionSelect.value = action;
        if (removeButton) removeButton.addEventListener('click', () => newRuleDiv.remove());

        rulesList.appendChild(newRuleDiv);
    }

    // Copy to clipboard helper
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            showCopyToast('Copied to clipboard!');
        }).catch(() => {
            // Fallback for older browsers
            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            showCopyToast('Copied to clipboard!');
        });
    }

    function showCopyToast(message) {
        const existing = document.querySelector('.copy-toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = 'copy-toast';
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 1500);
    }

    // Filter audio answers based on search query
    function filterAudioAnswers() {
        if (!searchQuery.trim()) {
            filteredAudioAnswers = allAudioAnswers;
        } else {
            const q = searchQuery.toLowerCase();
            filteredAudioAnswers = allAudioAnswers.filter(item =>
                item.url.toLowerCase().includes(q) ||
                (item.text && item.text.toLowerCase().includes(q))
            );
        }
        if (searchResultCount) {
            searchResultCount.textContent = searchQuery.trim()
                ? `${filteredAudioAnswers.length} of ${allAudioAnswers.length}`
                : '';
        }
    }

    // Load and display audio answers with pagination
    function loadAudioAnswers(page = 1) {
        currentPage = page;
        chrome.storage.local.get('uncommonTaskAnswers', (data) => {
            // uncommonTaskAnswers is stored as an array of entries from a Map
            // New format: Map<url, Array<{text, answer}>>
            // Old formats: Map<url, string> or Map<url, {text, answer}>
            const uncommonTaskEntries = data.uncommonTaskAnswers || [];
            allAudioAnswers = [];

            uncommonTaskEntries.forEach(entry => {
                const url = entry[0];
                const value = entry[1];

                if (typeof value === 'string') {
                    // Old format 1: just answer string
                    allAudioAnswers.push({ url, answer: value, text: '', entryIndex: 0 });
                } else if (Array.isArray(value)) {
                    // New format: array of {text, answer} objects
                    value.forEach((item, idx) => {
                        allAudioAnswers.push({
                            url,
                            answer: item.answer || 'ok',
                            text: item.text || '',
                            entryIndex: idx
                        });
                    });
                } else if (value && typeof value === 'object') {
                    // Old format 2: single {text, answer} object
                    allAudioAnswers.push({
                        url,
                        answer: value.answer || 'ok',
                        text: value.text || '',
                        entryIndex: 0
                    });
                }
            });

            filterAudioAnswers();

            if (noAudioAnswersDiv) noAudioAnswersDiv.style.display = filteredAudioAnswers.length === 0 ? 'block' : 'none';
            if (audioAnswersTable) audioAnswersTable.style.display = filteredAudioAnswers.length === 0 ? 'none' : 'table';
            if (paginationControls) paginationControls.innerHTML = '';

            if (filteredAudioAnswers.length === 0) return;

            if (audioAnswersList) {
                audioAnswersList.innerHTML = '';
                const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
                const endIndex = startIndex + ITEMS_PER_PAGE;
                const paginatedItems = filteredAudioAnswers.slice(startIndex, endIndex);

                paginatedItems.forEach(item => {
                    const row = document.createElement('tr');

                    // URL cell - truncated with tooltip, double-click to copy
                    const urlCell = document.createElement('td');
                    urlCell.className = 'url-cell';
                    const urlSpan = document.createElement('span');
                    urlSpan.className = 'url-text';
                    // Show just filename part of URL
                    const urlParts = item.url.split('/');
                    const filename = urlParts[urlParts.length - 1] || item.url;
                    urlSpan.textContent = filename.length > 30 ? filename.substring(0, 30) + '...' : filename;
                    urlSpan.title = item.url + '\n(Double-click to copy)';
                    urlSpan.addEventListener('dblclick', () => copyToClipboard(item.url));
                    urlCell.appendChild(urlSpan);
                    row.appendChild(urlCell);

                    // Text cell - the Arabic text content, double-click to copy
                    const textCell = document.createElement('td');
                    textCell.className = 'text-cell';
                    if (item.text) {
                        textCell.textContent = item.text.length > 40 ? item.text.substring(0, 40) + '...' : item.text;
                        textCell.title = item.text + '\n(Double-click to copy)';
                        textCell.dir = 'rtl'; // Right-to-left for Arabic
                        textCell.addEventListener('dblclick', () => copyToClipboard(item.text));
                    } else {
                        textCell.textContent = '(no text saved)';
                        textCell.style.color = '#999';
                        textCell.style.fontStyle = 'italic';
                    }
                    row.appendChild(textCell);

                    // Answer cell with dropdown
                    const answerCell = document.createElement('td');
                    const answerSelect = document.createElement('select');
                    answerSelect.className = 'answer-select';
                    [['ok', 'OK'], ['mistake', 'Mistake'], ['unclear', 'Unclear']].forEach(([val, label]) => {
                        const opt = document.createElement('option');
                        opt.value = val; opt.textContent = label;
                        if (item.answer === val) opt.selected = true;
                        answerSelect.appendChild(opt);
                    });
                    answerCell.appendChild(answerSelect);
                    row.appendChild(answerCell);

                    // Actions cell
                    const actionsCell = document.createElement('td');
                    actionsCell.className = 'actions-cell';

                    const saveBtn = document.createElement('button');
                    saveBtn.textContent = 'Save';
                    saveBtn.className = 'btn-save';
                    saveBtn.addEventListener('click', () => {
                        chrome.storage.local.get('uncommonTaskAnswers', (data) => {
                            const entries = data.uncommonTaskAnswers || [];
                            const map = new Map(entries);

                            // Get existing entries for this URL
                            let urlEntries = map.get(item.url);

                            // Convert to array format if needed
                            if (!urlEntries) {
                                urlEntries = [];
                            } else if (!Array.isArray(urlEntries)) {
                                // Convert old format to array
                                if (typeof urlEntries === 'string') {
                                    urlEntries = [{ text: '', answer: urlEntries }];
                                } else if (urlEntries && typeof urlEntries === 'object') {
                                    urlEntries = [{ text: urlEntries.text || '', answer: urlEntries.answer }];
                                }
                            }

                            // Update the specific entry by index
                            if (item.entryIndex !== undefined && urlEntries[item.entryIndex]) {
                                urlEntries[item.entryIndex].answer = answerSelect.value;
                            } else {
                                // Fallback: find by text match or update first entry
                                const matchIdx = urlEntries.findIndex(e => e.text === item.text);
                                if (matchIdx >= 0) {
                                    urlEntries[matchIdx].answer = answerSelect.value;
                                } else if (urlEntries.length > 0) {
                                    urlEntries[0].answer = answerSelect.value;
                                }
                            }

                            map.set(item.url, urlEntries);
                            chrome.storage.local.set({ uncommonTaskAnswers: Array.from(map.entries()) }, () => {
                                saveBtn.textContent = 'Saved!';
                                setTimeout(() => { saveBtn.textContent = 'Save'; }, 1000);
                                loadAudioAnswers(currentPage);
                            });
                        });
                    });

                    const playBtn = document.createElement('button');
                    playBtn.textContent = '▶ Play';
                    playBtn.className = 'btn-play';
                    playBtn.addEventListener('click', () => {
                        // Check if audio row already exists
                        const nextRow = row.nextElementSibling;
                        if (nextRow && nextRow.classList.contains('audio-player-row')) {
                            nextRow.remove();
                            playBtn.textContent = '▶ Play';
                            return;
                        }
                        // Create audio player row
                        const audioRow = document.createElement('tr');
                        audioRow.className = 'audio-player-row';
                        const audioCell = document.createElement('td');
                        audioCell.colSpan = 4;
                        const audioEl = document.createElement('audio');
                        audioEl.controls = true;
                        audioEl.src = item.url;
                        audioEl.style.width = '100%';
                        audioCell.appendChild(audioEl);
                        audioRow.appendChild(audioCell);
                        row.parentNode.insertBefore(audioRow, row.nextSibling);
                        playBtn.textContent = '⏹ Hide';
                    });

                    const deleteBtn = document.createElement('button');
                    deleteBtn.textContent = '✕';
                    deleteBtn.className = 'btn-delete';
                    deleteBtn.title = 'Delete this answer';
                    deleteBtn.addEventListener('click', () => {
                        if (!confirm('Delete this saved answer?')) return;
                        chrome.storage.local.get('uncommonTaskAnswers', (data) => {
                            const entries = data.uncommonTaskAnswers || [];
                            const map = new Map(entries);

                            // Get existing entries for this URL
                            let urlEntries = map.get(item.url);

                            // Convert to array format if needed
                            if (!urlEntries) {
                                // Nothing to delete
                                loadAudioAnswers(currentPage);
                                return;
                            } else if (!Array.isArray(urlEntries)) {
                                // Old format - delete the whole URL entry
                                map.delete(item.url);
                            } else if (urlEntries.length <= 1) {
                                // Only one entry - delete the whole URL
                                map.delete(item.url);
                            } else {
                                // Multiple entries - delete only the specific one
                                if (item.entryIndex !== undefined) {
                                    urlEntries.splice(item.entryIndex, 1);
                                } else {
                                    // Fallback: find by text match
                                    const matchIdx = urlEntries.findIndex(e => e.text === item.text);
                                    if (matchIdx >= 0) {
                                        urlEntries.splice(matchIdx, 1);
                                    }
                                }
                                map.set(item.url, urlEntries);
                            }

                            chrome.storage.local.set({ uncommonTaskAnswers: Array.from(map.entries()) }, () => {
                                loadAudioAnswers(currentPage);
                            });
                        });
                    });

                    actionsCell.appendChild(saveBtn);
                    actionsCell.appendChild(playBtn);
                    actionsCell.appendChild(deleteBtn);
                    row.appendChild(actionsCell);

                    audioAnswersList.appendChild(row);
                });
            }
            renderPaginationControls();
        });
    }

    function renderPaginationControls() {
        if (!paginationControls) return;
        paginationControls.innerHTML = '';
        const totalPages = Math.ceil(filteredAudioAnswers.length / ITEMS_PER_PAGE);

        if (totalPages <= 1) return;

        const createBtn = (text, page, isEllipsis = false) => {
            const btn = document.createElement('button');
            btn.textContent = text;
            btn.classList.add('pagination-button');
            if (isEllipsis) {
                btn.disabled = true;
                btn.classList.add('ellipsis');
            } else if (page === currentPage) {
                btn.classList.add('active');
            } else {
                btn.addEventListener('click', () => loadAudioAnswers(page));
            }
            return btn;
        };

        // Smart pagination: show first, last, and range around current
        const range = 2; // pages to show around current
        const pages = [];

        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - range && i <= currentPage + range)) {
                pages.push(i);
            } else if (pages[pages.length - 1] !== '...') {
                pages.push('...');
            }
        }

        pages.forEach(p => {
            if (p === '...') {
                paginationControls.appendChild(createBtn('…', null, true));
            } else {
                paginationControls.appendChild(createBtn(p, p));
            }
        });
    }

    // Export data function
    function exportData() {
        const dataToExport = {};
        const keysToExport = ['uncommonTaskAnswers', 'textClassifications', 'audioSettings', 'arabicSettings', 'manualUncommonDates'];

        chrome.storage.local.get(keysToExport, (result) => {
            keysToExport.forEach(key => {
                if (result[key] !== undefined) {
                    dataToExport[key] = result[key];
                } else {
                    // Ensure a default empty value if key doesn't exist, for consistent export structure
                    if (key === 'uncommonTaskAnswers' || key === 'textClassifications' || key === 'manualUncommonDates') {
                        dataToExport[key] = [];
                    } else if (key === 'arabicSettings' && result[key] && Array.isArray(result[key].rules)) {
                        dataToExport[key] = { ...defaultArabicSettings, ...result[key] }; // Merge with defaults, keeping existing rules if any
                    } else if (key === 'audioSettings') {
                        dataToExport[key] = defaultSettings;
                    } else if (key === 'arabicSettings') {
                        dataToExport[key] = defaultArabicSettings;
                    } else {
                        dataToExport[key] = {};
                    }
                }
            });

            const jsonData = JSON.stringify(dataToExport, null, 2);
            const blob = new Blob([jsonData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'extension_data.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            alert('Data exported successfully as extension_data.json!');
        });
    }

    // Export for Friend - creates a clean, human-readable text file
    // Only exports Arabic pronunciation tasks (with بشغِّل pattern), skips other task types
    function exportForFriend() {
        chrome.storage.local.get('uncommonTaskAnswers', (data) => {
            const uncommonTaskEntries = data.uncommonTaskAnswers || [];

            if (uncommonTaskEntries.length === 0) {
                alert('No saved audio answers to export.');
                return;
            }

            // Build clean text content
            let textContent = '';
            let entryNumber = 1;

            uncommonTaskEntries.forEach(entry => {
                const url = entry[0];
                const value = entry[1];

                // Extract all text+answer pairs for this URL
                let items = [];
                if (typeof value === 'string') {
                    items.push({ text: '', answer: value });
                } else if (Array.isArray(value)) {
                    items = value;
                } else if (value && typeof value === 'object') {
                    items.push(value);
                }

                items.forEach(item => {
                    let text = item.text || '';
                    let answer = item.answer || '';

                    // Skip entries with numeric answers (0, 1, -1) - these are from different task type
                    if (answer === '0' || answer === '1' || answer === '-1') return;

                    // Skip entries that contain context-based task markers
                    if (text.includes('السياق') || text.includes('الجملة') ||
                        text.includes('فيه مشاكل') || text.includes('النبرة')) return;

                    // Skip if no text
                    if (!text.trim()) return;

                    // Clean up the text - extract just the content after بشغِّل/بشغّل/بشغل
                    let cleanText = text;

                    // Remove common instruction labels
                    const labelsToRemove = [
                        'النص بشغِّل',
                        'النص بشغّل',
                        'النص بشغل',
                        'بشغِّل',
                        'بشغّل',
                        'بشغل',
                        'النص',
                        '. الصوت',
                        '.الصوت',
                        'الصوت'
                    ];

                    labelsToRemove.forEach(label => {
                        cleanText = cleanText.replace(new RegExp(label, 'g'), '');
                    });

                    // Clean up extra spaces, dots, and trim
                    cleanText = cleanText.replace(/\s+/g, ' ').trim();
                    cleanText = cleanText.replace(/^\.\s*/, '').replace(/\.\s*$/, '').trim();

                    // Skip if after cleaning there's no meaningful text
                    if (!cleanText) return;

                    // Format answer in Arabic only
                    let answerLabel = '';
                    switch (answer) {
                        case 'ok': answerLabel = 'صحيح'; break;
                        case 'mistake': answerLabel = 'خاطئ'; break;
                        case 'unclear': answerLabel = 'غير واضح'; break;
                        default: answerLabel = answer;
                    }

                    textContent += `${entryNumber}.\n`;
                    textContent += `text: ${cleanText}\n`;
                    textContent += `url: ${url}\n`;
                    textContent += `answer: ${answerLabel}\n`;
                    textContent += `\n`;
                    entryNumber++;
                });
            });

            if (!textContent.trim()) {
                alert('No valid entries to export. Make sure you have saved Arabic pronunciation task answers.');
                return;
            }

            // Create and download file
            const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
            const downloadUrl = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = downloadUrl;
            a.download = 'audio_evaluations.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(downloadUrl);
            alert('Exported ' + (entryNumber - 1) + ' entries to audio_evaluations.txt');
        });
    }

    // Import data function
    function importData(event) {
        const file = event.target.files[0];
        if (!file) {
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                const dataToStore = {};
                let validDataFound = false;
                const validKeys = ['uncommonTaskAnswers', 'textClassifications', 'audioSettings', 'arabicSettings', 'manualUncommonDates'];

                validKeys.forEach(key => {
                    if (importedData[key] !== undefined) {
                        // Basic validation for expected structures
                        if (key === 'uncommonTaskAnswers' && !Array.isArray(importedData[key])) throw new Error(`Invalid structure for ${key}. Expected array of [url,answer] pairs.`);
                        if (key === 'manualUncommonDates' && !Array.isArray(importedData[key])) throw new Error(`Invalid structure for ${key}. Expected array.`);
                        if (key === 'textClassifications' && !Array.isArray(importedData[key])) throw new Error(`Invalid structure for ${key}. Expected array.`);
                        if (key === 'audioSettings' && typeof importedData[key] !== 'object') throw new Error(`Invalid structure for ${key}. Expected object.`);
                        if (key === 'arabicSettings' && (typeof importedData[key] !== 'object' || !Array.isArray(importedData[key].rules))) throw new Error(`Invalid structure for ${key}. Expected object with a rules array.`);

                        dataToStore[key] = importedData[key];
                        validDataFound = true;
                    }
                });

                if (!validDataFound) {
                    alert('No valid data found in the imported file. Please ensure the file structure is correct (e.g., contains keys like "uncommonTaskAnswers", "textClassifications", etc.) and data types are as expected.');
                    if (importFileInput) importFileInput.value = ''; // Reset file input
                    return;
                }

                if (confirm('Import will MERGE with existing data (new entries added, duplicates updated). Continue?')) {
                    // Get existing data to merge with
                    chrome.storage.local.get(validKeys, (existingData) => {
                        const mergedData = {};

                        // Merge uncommonTaskAnswers (by URL key)
                        if (dataToStore.uncommonTaskAnswers) {
                            const existingMap = new Map(existingData.uncommonTaskAnswers || []);
                            const importedMap = new Map(dataToStore.uncommonTaskAnswers);
                            // Imported overwrites existing for same URL
                            for (const [url, val] of importedMap) {
                                existingMap.set(url, val);
                            }
                            mergedData.uncommonTaskAnswers = Array.from(existingMap.entries());
                        }

                        // Merge manualUncommonDates
                        if (dataToStore.manualUncommonDates) {
                            const existingDates = new Set(existingData.manualUncommonDates || []);
                            dataToStore.manualUncommonDates.forEach(d => existingDates.add(d));
                            mergedData.manualUncommonDates = Array.from(existingDates);
                        }

                        // Merge textClassifications (by text key, newer wins)
                        if (dataToStore.textClassifications) {
                            const existingClassifications = existingData.textClassifications || [];
                            const importedClassifications = dataToStore.textClassifications;
                            const classMap = new Map();
                            existingClassifications.forEach(c => classMap.set(c.text, c));
                            importedClassifications.forEach(c => classMap.set(c.text, c)); // Imported wins
                            mergedData.textClassifications = Array.from(classMap.values());
                        }

                        // Merge arabicSettings (rules merged by pattern, other settings overwritten)
                        if (dataToStore.arabicSettings) {
                            const existingSettings = existingData.arabicSettings || defaultArabicSettings;
                            const importedSettings = dataToStore.arabicSettings;

                            // Merge rules by pattern
                            const ruleMap = new Map();
                            (existingSettings.rules || []).forEach(r => ruleMap.set(r.pattern, r));
                            (importedSettings.rules || []).forEach(r => ruleMap.set(r.pattern, r)); // Imported wins

                            mergedData.arabicSettings = {
                                ...existingSettings,
                                ...importedSettings,
                                rules: Array.from(ruleMap.values())
                            };
                        }

                        // audioSettings: just overwrite (simple object)
                        if (dataToStore.audioSettings) {
                            mergedData.audioSettings = dataToStore.audioSettings;
                        }

                        chrome.storage.local.set(mergedData, () => {
                            alert('Data merged successfully! Reloading settings.');
                            // Reload all settings displays
                            loadAudioSettings();
                            loadTextClassifications();
                            loadArabicSettings();
                            loadAudioAnswers();
                        });
                    });
                }
            } catch (error) {
                alert('Error processing import file: ' + error.message);
                console.error('Error importing data:', error);
            }
            if (importFileInput) importFileInput.value = '';
        };
        reader.readAsText(file);
    }

    function clearAllSavedAnswers() {
        if (!confirm('This will permanently delete all saved uncommon task answers. Continue?')) return;
        chrome.storage.local.remove('uncommonTaskAnswers', () => {
            loadAudioAnswers();
            alert('Saved answers cleared.');
        });
    }

    // === TEXT MARKING ANSWERS ===

    const textMarkingList = document.getElementById('textMarkingList');
    const noTextMarkingDiv = document.getElementById('noTextMarkingAnswers');
    const textMarkingPagination = document.getElementById('textMarkingPagination');
    const textMarkingSearchInput = document.getElementById('textMarkingSearchInput');
    const textMarkingSearchCount = document.getElementById('textMarkingSearchCount');
    const exportTextMarkingBtn = document.getElementById('exportTextMarking');
    const exportTextMarkingJSONBtn = document.getElementById('exportTextMarkingSettings');
    const importTextMarkingInput = document.getElementById('importTextMarking');
    const clearTextMarkingBtn = document.getElementById('clearTextMarking');

    const TM_PER_PAGE = 10;
    let tmCurrentPage = 1;
    let tmAllEntries = [];
    let tmFilteredEntries = [];
    let tmSearchQuery = '';

    function filterTextMarkingEntries() {
        if (!tmSearchQuery.trim()) {
            tmFilteredEntries = tmAllEntries;
        } else {
            const q = tmSearchQuery.toLowerCase();
            tmFilteredEntries = tmAllEntries.filter(item =>
                (item.fullText && item.fullText.toLowerCase().includes(q)) ||
                (item.segmentText && item.segmentText.toLowerCase().includes(q)) ||
                (item.markings && item.markings.some(m => m.text.toLowerCase().includes(q)))
            );
        }
        if (textMarkingSearchCount) {
            textMarkingSearchCount.textContent = tmSearchQuery.trim()
                ? `${tmFilteredEntries.length} of ${tmAllEntries.length}`
                : '';
        }
    }

    // Build the segment text with inline color highlighting
    function buildHighlightedSegment(entry) {
        if (!entry.segmentText || !entry.markings || entry.markings.length === 0) {
            return document.createTextNode(entry.segmentText || '');
        }

        const fragment = document.createDocumentFragment();
        let text = entry.segmentText;
        let lastIndex = 0;

        // For each marking, find its position in the segment text and wrap with a span
        // We need to find the markings in order of their appearance
        const sortedMarkings = [];
        let searchFrom = 0;
        for (const marking of entry.markings) {
            const idx = text.indexOf(marking.text, searchFrom);
            if (idx >= 0) {
                sortedMarkings.push({ ...marking, startIdx: idx, endIdx: idx + marking.text.length });
                searchFrom = idx + marking.text.length;
            }
        }

        sortedMarkings.sort((a, b) => a.startIdx - b.startIdx);

        for (const m of sortedMarkings) {
            // Add text before this marking
            if (m.startIdx > lastIndex) {
                fragment.appendChild(document.createTextNode(text.substring(lastIndex, m.startIdx)));
            }
            // Add the highlighted marking
            const span = document.createElement('span');
            span.className = m.type === 'mistake' ? 'tm-mark-mistake' : 'tm-mark-unclear';
            span.textContent = m.text;
            span.title = m.type === 'mistake' ? 'خاطئ (Mistake)' : 'غير واضح (Unclear)';
            fragment.appendChild(span);
            lastIndex = m.endIdx;
        }

        // Add remaining text
        if (lastIndex < text.length) {
            fragment.appendChild(document.createTextNode(text.substring(lastIndex)));
        }

        return fragment;
    }

    function loadTextMarkingAnswers(page = 1) {
        tmCurrentPage = page;
        chrome.storage.local.get('textMarkingAnswers', (data) => {
            tmAllEntries = data.textMarkingAnswers || [];
            filterTextMarkingEntries();

            if (noTextMarkingDiv) noTextMarkingDiv.style.display = tmFilteredEntries.length === 0 ? 'block' : 'none';
            if (!textMarkingList) return;
            textMarkingList.innerHTML = '';

            if (tmFilteredEntries.length === 0) return;

            const startIndex = (tmCurrentPage - 1) * TM_PER_PAGE;
            const endIndex = startIndex + TM_PER_PAGE;
            const pageEntries = tmFilteredEntries.slice(startIndex, endIndex);

            pageEntries.forEach((entry, idx) => {
                const globalIdx = startIndex + idx;
                const card = document.createElement('div');
                card.className = 'tm-card';

                // Header
                const header = document.createElement('div');
                header.className = 'tm-card-header';
                const num = document.createElement('span');
                num.className = 'tm-card-number';
                num.textContent = '#' + (globalIdx + 1);
                header.appendChild(num);
                if (entry.timestamp) {
                    const ts = document.createElement('span');
                    ts.textContent = new Date(entry.timestamp).toLocaleString();
                    header.appendChild(ts);
                }
                card.appendChild(header);

                // Full text section
                if (entry.fullText && entry.fullText !== entry.segmentText) {
                    const ftLabel = document.createElement('div');
                    ftLabel.className = 'tm-full-text-label';
                    ftLabel.textContent = 'النص الكامل (Full Text)';
                    card.appendChild(ftLabel);

                    const ft = document.createElement('div');
                    ft.className = 'tm-full-text';
                    ft.textContent = entry.fullText;
                    card.appendChild(ft);
                }

                // Segment text (with highlights)
                const segLabel = document.createElement('div');
                segLabel.className = 'tm-segment-label';
                segLabel.textContent = 'الجزء المحدد من النص (Highlighted Segment)';
                card.appendChild(segLabel);

                const seg = document.createElement('div');
                seg.className = 'tm-segment';
                seg.appendChild(buildHighlightedSegment(entry));
                card.appendChild(seg);

                // Markings summary tags
                if (entry.noMistake) {
                    const noMistakeDiv = document.createElement('div');
                    noMistakeDiv.className = 'tm-no-mistake';
                    noMistakeDiv.textContent = '✓ لا توجد أخطاء (No mistakes)';
                    card.appendChild(noMistakeDiv);
                }

                if (entry.markings && entry.markings.length > 0) {
                    const summary = document.createElement('div');
                    summary.className = 'tm-markings-summary';
                    entry.markings.forEach(m => {
                        const tag = document.createElement('span');
                        tag.className = 'tm-marking-tag ' + m.type;
                        const dot = document.createElement('span');
                        dot.className = 'tag-dot';
                        tag.appendChild(dot);
                        const label = document.createElement('span');
                        label.textContent = m.text + ' (' + (m.type === 'mistake' ? 'خاطئ' : 'غير واضح') + ')';
                        tag.appendChild(label);
                        summary.appendChild(tag);
                    });
                    card.appendChild(summary);
                }

                // Actions
                const actions = document.createElement('div');
                actions.className = 'tm-card-actions';

                if (entry.audioUrl) {
                    const playBtn = document.createElement('button');
                    playBtn.textContent = '▶ Play';
                    playBtn.style.cssText = 'background: #3498db; color: white;';
                    playBtn.addEventListener('click', () => {
                        const existingAudio = card.querySelector('audio');
                        if (existingAudio) {
                            existingAudio.parentElement.remove();
                            playBtn.textContent = '▶ Play';
                            return;
                        }
                        const audioWrap = document.createElement('div');
                        audioWrap.style.cssText = 'margin-top: 8px; padding: 8px; background: #ecf0f1; border-radius: 6px;';
                        const audioEl = document.createElement('audio');
                        audioEl.controls = true;
                        audioEl.src = entry.audioUrl;
                        audioEl.style.width = '100%';
                        audioWrap.appendChild(audioEl);
                        card.appendChild(audioWrap);
                        playBtn.textContent = '⏹ Hide';
                    });
                    actions.appendChild(playBtn);
                }

                const deleteBtn = document.createElement('button');
                deleteBtn.textContent = '✕ Delete';
                deleteBtn.style.cssText = 'background: #e74c3c; color: white;';
                deleteBtn.addEventListener('click', () => {
                    if (!confirm('Delete this text marking entry?')) return;
                    chrome.storage.local.get('textMarkingAnswers', (data) => {
                        let entries = data.textMarkingAnswers || [];
                        // Find and remove this exact entry
                        entries = entries.filter((e, i) => {
                            return !(e.audioUrl === entry.audioUrl && e.segmentText === entry.segmentText);
                        });
                        chrome.storage.local.set({ textMarkingAnswers: entries }, () => {
                            loadTextMarkingAnswers(tmCurrentPage);
                        });
                    });
                });
                actions.appendChild(deleteBtn);

                card.appendChild(actions);
                textMarkingList.appendChild(card);
            });

            renderTextMarkingPagination();
        });
    }

    function renderTextMarkingPagination() {
        if (!textMarkingPagination) return;
        textMarkingPagination.innerHTML = '';
        const totalPages = Math.ceil(tmFilteredEntries.length / TM_PER_PAGE);
        if (totalPages <= 1) return;

        const range = 2;
        const pages = [];
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= tmCurrentPage - range && i <= tmCurrentPage + range)) {
                pages.push(i);
            } else if (pages[pages.length - 1] !== '...') {
                pages.push('...');
            }
        }

        // Reuse existing pagination styles
        textMarkingPagination.style.cssText = 'display:flex;justify-content:center;gap:4px;margin-top:15px;flex-wrap:wrap;';
        pages.forEach(p => {
            const btn = document.createElement('button');
            btn.classList.add('pagination-button');
            if (p === '...') {
                btn.textContent = '…';
                btn.disabled = true;
                btn.classList.add('ellipsis');
            } else {
                btn.textContent = p;
                if (p === tmCurrentPage) {
                    btn.classList.add('active');
                } else {
                    btn.addEventListener('click', () => loadTextMarkingAnswers(p));
                }
            }
            textMarkingPagination.appendChild(btn);
        });
    }

    function exportTextMarkingAnswers() {
        chrome.storage.local.get('textMarkingAnswers', (data) => {
            const entries = data.textMarkingAnswers || [];
            if (entries.length === 0) {
                alert('No text marking answers to export.');
                return;
            }

            let textContent = '';
            entries.forEach((entry, idx) => {
                textContent += `${idx + 1}.  النص الكامل\n`;
                textContent += `${entry.fullText || entry.segmentText}\n\n`;
                textContent += `الجزء المحدد من النص\n`;
                textContent += `${entry.segmentText}\n\n`;

                // Group markings by type
                const mistakes = (entry.markings || []).filter(m => m.type === 'mistake');
                const unclear = (entry.markings || []).filter(m => m.type === 'unclear');

                if (mistakes.length > 0) {
                    textContent += `mistake: ${mistakes.map(m => m.text).join('، ')}\n`;
                }
                if (unclear.length > 0) {
                    textContent += `unclear: ${unclear.map(m => m.text).join('، ')}\n`;
                }
                if (entry.noMistake) {
                    textContent += `(لا توجد أخطاء - no mistakes)\n`;
                }

                if (entry.audioUrl) {
                    textContent += `audio: ${entry.audioUrl}\n`;
                }

                textContent += '\n---\n\n';
            });

            const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'text_marking_answers.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            alert('Exported ' + entries.length + ' text marking entries.');
        });
    }

    function exportTextMarkingJSON() {
        chrome.storage.local.get('textMarkingAnswers', (data) => {
            const entries = data.textMarkingAnswers || [];
            if (entries.length === 0) {
                alert('No text marking answers to export.');
                return;
            }

            const exportObj = {
                textMarkingAnswers: entries
            };

            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportObj, null, 2));
            const dlAnchorElem = document.createElement('a');
            dlAnchorElem.setAttribute("href", dataStr);
            dlAnchorElem.setAttribute("download", "text_marking_answers_settings.json");
            dlAnchorElem.click();
            alert('Exported ' + entries.length + ' text marking entries to JSON.');
        });
    }

    function importTextMarkingJSON(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const contents = e.target.result;
                const data = JSON.parse(contents);

                if (data && data.textMarkingAnswers && Array.isArray(data.textMarkingAnswers)) {
                    const newEntries = data.textMarkingAnswers;

                    chrome.storage.local.get('textMarkingAnswers', (existingData) => {
                        let existing = existingData.textMarkingAnswers || [];
                        let added = 0;
                        let updated = 0;

                        newEntries.forEach(entry => {
                            const existingIdx = existing.findIndex(existingEntry =>
                                existingEntry.audioUrl === entry.audioUrl && existingEntry.segmentText === entry.segmentText
                            );
                            if (existingIdx >= 0) {
                                existing[existingIdx] = entry;
                                updated++;
                            } else {
                                existing.push(entry);
                                added++;
                            }
                        });

                        chrome.storage.local.set({ textMarkingAnswers: existing }, () => {
                            loadTextMarkingAnswers(tmCurrentPage);
                            alert(`Imported Text Marking Answers successfully!\nAdded: ${added}\nUpdated: ${updated}`);
                        });
                    });
                } else {
                    alert('Invalid JSON file. Please ensure it was exported correctly.');
                }
            } catch (error) {
                alert('Error processing JSON file: ' + error.message);
                console.error('Error importing text marking data:', error);
            }
            if (e.target) e.target.value = '';
        };
        reader.readAsText(file);
    }

    function clearTextMarkingAnswers() {
        if (!confirm('This will permanently delete all saved text marking answers. Continue?')) return;
        chrome.storage.local.remove('textMarkingAnswers', () => {
            loadTextMarkingAnswers();
            alert('Text marking answers cleared.');
        });
    }

    // Initial calls to load data
    fetchDailyEarnings();
    loadAudioSettings();
    loadTextClassifications();
    loadArabicSettings();
    loadAudioAnswers();
    loadTextMarkingAnswers();

    // Event listeners
    if (saveAudioSettingsButton) saveAudioSettingsButton.addEventListener('click', saveAudioSettings);
    if (resetAudioSettingsButton) resetAudioSettingsButton.addEventListener('click', resetAudioSettings);
    if (clearClassificationsButton) clearClassificationsButton.addEventListener('click', clearTextClassifications);
    if (addRuleButton) addRuleButton.addEventListener('click', () => addRuleToUI());
    if (saveArabicSettingsButton) saveArabicSettingsButton.addEventListener('click', saveArabicSettings);
    if (resetArabicSettingsButton) resetArabicSettingsButton.addEventListener('click', resetArabicSettings);

    const allSliders = [energyThresholdInput, variationThresholdInput, zeroCrossingThresholdInput, minSegmentDurationInput, segmentVariationThresholdInput];
    allSliders.forEach(input => {
        if (input) input.addEventListener('input', updateDisplayedValues);
    });

    // Event listeners for export and import
    if (exportDataButton) exportDataButton.addEventListener('click', exportData);
    if (exportForFriendButton) exportForFriendButton.addEventListener('click', exportForFriend);
    if (importFileInput) importFileInput.addEventListener('change', importData);
    if (clearAnswersButton) clearAnswersButton.addEventListener('click', clearAllSavedAnswers);

    // Search functionality
    if (audioSearchInput) {
        let searchTimeout;
        audioSearchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                searchQuery = e.target.value;
                loadAudioAnswers(1); // Reset to page 1 and re-render
            }, 150); // Debounce for smooth typing
        });
    }
    // Text marking event listeners
    if (exportTextMarkingBtn) exportTextMarkingBtn.addEventListener('click', exportTextMarkingAnswers);
    if (exportTextMarkingJSONBtn) exportTextMarkingJSONBtn.addEventListener('click', exportTextMarkingJSON);
    if (importTextMarkingInput) importTextMarkingInput.addEventListener('change', importTextMarkingJSON);
    if (clearTextMarkingBtn) clearTextMarkingBtn.addEventListener('click', clearTextMarkingAnswers);
    if (textMarkingSearchInput) {
        let tmSearchTimeout;
        textMarkingSearchInput.addEventListener('input', (e) => {
            clearTimeout(tmSearchTimeout);
            tmSearchTimeout = setTimeout(() => {
                tmSearchQuery = e.target.value;
                loadTextMarkingAnswers(1);
            }, 150);
        });
    }
    const debugToggle = document.getElementById('debugLoggingToggle');
    if (debugToggle) debugToggle.addEventListener('change', (e) => {
        const enabled = !!e.target.checked;
        chrome.storage.local.set({ debugLogging: enabled }, () => {
            chrome.runtime.sendMessage({ action: 'debugLoggingUpdated', debugLogging: enabled });
            alert('Debug logging ' + (enabled ? 'enabled' : 'disabled') + '. Open DevTools Console on the task iframe to view logs.');
        });
    });

    const indicatorToggle = document.getElementById('showClickIndicator');
    if (indicatorToggle) indicatorToggle.addEventListener('change', (e) => {
        const enabled = !!e.target.checked;
        chrome.storage.local.set({ showClickIndicator: enabled }, () => {
            chrome.runtime.sendMessage({ action: 'showClickIndicatorUpdated', enabled });
            alert('Click attempt badges ' + (enabled ? 'enabled' : 'disabled') + '.');
        });
    });

    const clickResultToggle = document.getElementById('showClickResult');
    if (clickResultToggle) clickResultToggle.addEventListener('change', (e) => {
        const enabled = !!e.target.checked;
        chrome.storage.local.set({ showClickResult: enabled }, () => {
            alert('Click result display ' + (enabled ? 'enabled' : 'disabled') + '.');
        });
    });

    // --- Mismatch Resolution ---
    function checkMismatch() {
        chrome.storage.local.get('lastMismatch', (data) => {
            if (data.lastMismatch) {
                const info = data.lastMismatch;
                // Only show if it's recent (e.g. within last 5 minutes) to avoid showing old stale data
                if (Date.now() - info.timestamp < 300000) {
                    showMismatchModal(info);
                } else {
                    // limit cleared
                    chrome.storage.local.remove('lastMismatch');
                }
            }
        });
    }

    function showMismatchModal(info) {
        const modal = document.getElementById('mismatchModal');
        const savedTextP = document.getElementById('mismatchSavedText');
        const currentTextP = document.getElementById('mismatchCurrentText');
        const actionSpan = document.getElementById('mismatchSavedAction');
        const audioContainer = document.getElementById('mismatchAudioContainer');
        const updateBtn = document.getElementById('mismatchUpdateBtn');
        const deleteBtn = document.getElementById('mismatchDeleteBtn');
        const ignoreBtn = document.getElementById('mismatchIgnoreBtn');

        if (!modal) return;

        savedTextP.textContent = info.savedText || '(No text saved)';
        currentTextP.textContent = info.currentText || '(Empty)';
        actionSpan.textContent = info.savedAnswer;

        audioContainer.innerHTML = '';
        const audio = document.createElement('audio');
        audio.controls = true;
        audio.src = info.audioUrl;
        audio.style.width = '100%';
        audioContainer.appendChild(audio);

        modal.style.display = 'flex';

        // Handlers
        updateBtn.onclick = () => {
            chrome.storage.local.get('uncommonTaskAnswers', (data) => {
                const entries = data.uncommonTaskAnswers || [];
                const map = new Map(entries);
                // Update with NEW text but KEEP old answer
                map.set(info.audioUrl, { answer: info.savedAnswer, text: info.currentText });
                chrome.storage.local.set({ uncommonTaskAnswers: Array.from(map.entries()) }, () => {
                    alert('Updated! The extension will now recognize this text.');
                    closeModal();
                    loadAudioAnswers(); // Refresh table
                });
            });
        };

        deleteBtn.onclick = () => {
            if (confirm("Delete this saved answer entirely?")) {
                chrome.storage.local.get('uncommonTaskAnswers', (data) => {
                    const entries = data.uncommonTaskAnswers || [];
                    const map = new Map(entries);
                    map.delete(info.audioUrl);
                    chrome.storage.local.set({ uncommonTaskAnswers: Array.from(map.entries()) }, () => {
                        alert('Deleted.');
                        closeModal();
                        loadAudioAnswers();
                    });
                });
            }
        };

        ignoreBtn.onclick = closeModal;

        function closeModal() {
            modal.style.display = 'none';
            chrome.storage.local.remove('lastMismatch');
        }
    }

    // Check for mismatch on load
    checkMismatch();

    // === Manual Uncommon Dates Logic ===

    function loadManualDates() {
        if (!manualDatesList) return;
        chrome.storage.local.get('manualUncommonDates', (data) => {
            const dates = data.manualUncommonDates || [];
            manualDatesList.innerHTML = '';

            if (dates.length === 0) {
                manualDatesList.innerHTML = '<p class="no-items" style="color: #888; width: 100%;">No manual dates added yet.</p>';
                return;
            }

            dates.forEach(dateStr => {
                const tag = document.createElement('div');
                tag.style.cssText = 'background: #2d2d2d; border: 1px solid #444; border-radius: 4px; padding: 5px 10px; display: flex; align-items: center; gap: 8px; color: #f093fb;';

                const span = document.createElement('span');
                span.textContent = dateStr;
                tag.appendChild(span);

                const removeBtn = document.createElement('button');
                removeBtn.textContent = '×';
                removeBtn.style.cssText = 'background: none; border: none; color: #e74c3c; cursor: pointer; font-size: 16px; font-weight: bold; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center;';
                removeBtn.addEventListener('click', () => {
                    if (confirm(`Remove ${dateStr} from manually uncommon dates?`)) {
                        removeManualDate(dateStr);
                    }
                });

                tag.appendChild(removeBtn);
                manualDatesList.appendChild(tag);
            });
        });
    }

    function addManualDate(dateStr) {
        if (!dateStr || !dateStr.trim()) return;
        dateStr = dateStr.trim();

        chrome.storage.local.get('manualUncommonDates', (data) => {
            const dates = new Set(data.manualUncommonDates || []);
            dates.add(dateStr);
            chrome.storage.local.set({ manualUncommonDates: Array.from(dates) }, () => {
                loadManualDates();
                if (newManualDateInput) newManualDateInput.value = '';
            });
        });
    }

    function removeManualDate(dateStr) {
        chrome.storage.local.get('manualUncommonDates', (data) => {
            let dates = data.manualUncommonDates || [];
            dates = dates.filter(d => d !== dateStr);
            chrome.storage.local.set({ manualUncommonDates: dates }, () => {
                loadManualDates();
            });
        });
    }

    if (addManualDateBtn) {
        addManualDateBtn.addEventListener('click', () => {
            addManualDate(newManualDateInput.value);
        });
    }

    // Initial load
    loadManualDates();

    // === Cloud Sync (Firebase Realtime Database REST API) ===

    const FIREBASE_URL = 'https://geno-e0098-default-rtdb.firebaseio.com/sync.json';
    const SYNC_KEYS = [
        'arabicSettings', 'audioSettings', 'uncommonTaskAnswers',
        'manualUncommonDates', 'comparisonSaveAll',
        'debugLogging', 'showClickIndicator', 'showClickResult',
        'textMarkingAnswers'
    ];

    const pushBtn = document.getElementById('pushToCloudBtn');
    const pullBtn = document.getElementById('pullFromCloudBtn');
    const syncStatusText = document.getElementById('syncStatusText');
    const syncMessage = document.getElementById('syncMessage');

    function getDeviceName() {
        const ua = navigator.userAgent;
        if (/Android/i.test(ua)) return 'Kiwi Android';
        if (/iPhone|iPad/i.test(ua)) return 'iOS';
        return 'Chrome Desktop';
    }

    function showSyncMessage(text, isError) {
        if (!syncMessage) return;
        syncMessage.textContent = text;
        syncMessage.style.display = 'block';
        syncMessage.style.backgroundColor = isError ? '#f8d7da' : '#d4edda';
        syncMessage.style.color = isError ? '#721c24' : '#155724';
        setTimeout(() => { syncMessage.style.display = 'none'; }, 5000);
    }

    function setSyncButtonsDisabled(disabled) {
        if (pushBtn) pushBtn.disabled = disabled;
        if (pullBtn) pullBtn.disabled = disabled;
    }

    function loadCloudStatus() {
        fetch(FIREBASE_URL, { method: 'GET' })
            .then(r => r.json())
            .then(data => {
                if (data && data.lastSyncTimestamp) {
                    const date = new Date(data.lastSyncTimestamp);
                    const timeStr = date.toLocaleString();
                    const device = data.lastSyncDevice || 'Unknown';
                    if (syncStatusText) syncStatusText.textContent = `Last push: ${timeStr} from ${device}`;
                } else {
                    if (syncStatusText) syncStatusText.textContent = 'No cloud data yet. Push to upload your settings.';
                }
            })
            .catch(() => {
                if (syncStatusText) syncStatusText.textContent = 'Could not reach cloud. Check your connection.';
            });
    }

    async function pushToCloud() {
        setSyncButtonsDisabled(true);
        if (syncStatusText) syncStatusText.textContent = 'Pushing to cloud...';

        try {
            const data = await new Promise(resolve => {
                chrome.storage.local.get(SYNC_KEYS, resolve);
            });

            data.lastSyncTimestamp = new Date().toISOString();
            data.lastSyncDevice = getDeviceName();

            const response = await fetch(FIREBASE_URL, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            if (!response.ok) throw new Error('HTTP ' + response.status);

            const timeStr = new Date(data.lastSyncTimestamp).toLocaleString();
            if (syncStatusText) syncStatusText.textContent = `Last push: ${timeStr} from ${data.lastSyncDevice}`;
            showSyncMessage('Pushed to cloud successfully!', false);
        } catch (err) {
            showSyncMessage('Push failed: ' + err.message, true);
            if (syncStatusText) syncStatusText.textContent = 'Push failed. Check connection.';
        } finally {
            setSyncButtonsDisabled(false);
        }
    }

    async function pullFromCloud() {
        if (!confirm('This will overwrite ALL local settings and saved answers with the cloud copy. Continue?')) return;

        setSyncButtonsDisabled(true);
        if (syncStatusText) syncStatusText.textContent = 'Pulling from cloud...';

        try {
            const response = await fetch(FIREBASE_URL, { method: 'GET' });
            if (!response.ok) throw new Error('HTTP ' + response.status);

            const data = await response.json();
            if (!data) {
                showSyncMessage('Cloud is empty. Nothing to pull.', true);
                if (syncStatusText) syncStatusText.textContent = 'No cloud data yet.';
                return;
            }

            const toStore = {};
            SYNC_KEYS.forEach(key => {
                if (data[key] !== undefined) toStore[key] = data[key];
            });

            await new Promise(resolve => {
                chrome.storage.local.set(toStore, resolve);
            });

            const timeStr = data.lastSyncTimestamp ? new Date(data.lastSyncTimestamp).toLocaleString() : 'Unknown';
            const device = data.lastSyncDevice || 'Unknown';
            if (syncStatusText) syncStatusText.textContent = `Last push: ${timeStr} from ${device}`;
            showSyncMessage('Pulled from cloud! Reloading settings...', false);

            // Broadcast updated settings to all tabs
            if (toStore.arabicSettings) {
                chrome.runtime.sendMessage({ action: 'arabicSettingsUpdated', settings: toStore.arabicSettings });
            }
            if (toStore.audioSettings) {
                chrome.runtime.sendMessage({ action: 'audioSettingsUpdated', settings: toStore.audioSettings });
            }
            if (toStore.debugLogging !== undefined) {
                chrome.runtime.sendMessage({ action: 'debugLoggingUpdated', debugLogging: toStore.debugLogging });
            }

            // Reload all UI sections with the new data
            loadAudioSettings();
            loadArabicSettings();
            loadAudioAnswers();
            loadManualDates();
            loadTextMarkingAnswers();
        } catch (err) {
            showSyncMessage('Pull failed: ' + err.message, true);
            if (syncStatusText) syncStatusText.textContent = 'Pull failed. Check connection.';
        } finally {
            setSyncButtonsDisabled(false);
        }
    }

    if (pushBtn) pushBtn.addEventListener('click', pushToCloud);
    if (pullBtn) pullBtn.addEventListener('click', pullFromCloud);

    loadCloudStatus();
});
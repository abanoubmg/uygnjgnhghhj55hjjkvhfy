(function () {
  // === Media Helper + Geno Audio Helper Combined Content Script ===
  // Namespace all shared state under a single window property
  window._mh = window._mh || {};

  // Debug logging flag (can be toggled from options page)
  let DEBUG_ENABLED = false;
  chrome.runtime.sendMessage({ action: 'getDebugLogging' }, (res) => {
    DEBUG_ENABLED = !!(res && res.debugLogging);
    try { window._mh.dbg = DEBUG_ENABLED; } catch (_) { }
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === 'debugLoggingUpdated') {
      DEBUG_ENABLED = !!message.enabled;
      try { window._mh.dbg = DEBUG_ENABLED; } catch (_) { }
    }
  });

  function dlog(...args) {
    if (!DEBUG_ENABLED) return;
    try { console.log('[MH]', ...args); } catch (_) { }
  }

  function debugScanArabic(stageLabel = '') {
    if (!DEBUG_ENABLED) return;
    try {
      const containers = Array.from(document.querySelectorAll('.tb-task, .lUeJm._2t-aw'));
      const totalButtons = Array.from(document.querySelectorAll('button[payload]'));
      console.log('[MH][DBG] Arabic scan', stageLabel, 'containers', containers.length, 'buttons', totalButtons.length);
      containers.slice(0, 3).forEach((c, idx) => {
        const btns = Array.from(c.querySelectorAll('button[payload]'));
        const payloads = btns.map(b => b && b.getAttribute && b.getAttribute('payload')).filter(Boolean);
        console.log('[MH][DBG] container', idx, 'btnCount', btns.length, 'payloads', payloads);
      });
    } catch (_) { }
  }

  // Gaussian random delay for more natural, less detectable timing patterns
  function gaussianRandomDelay(min, max) {
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    let num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    // Transform to 0-1 range (clamped)
    num = Math.max(0, Math.min(1, (num + 3) / 6));
    return Math.floor(min + num * (max - min));
  }

  // Shadow DOM helper functions - search across shadow roots
  function queryShadowSelector(selector, root = document) {
    // First check regular DOM
    let result = root.querySelector(selector);
    if (result) return result;

    // Check if root itself has a shadow DOM (e.g. is already an mh-wrapper)
    if (root && root.shadowRoot) {
      result = root.shadowRoot.querySelector(selector);
      if (result) return result;
    }

    // Then search in all shadow roots inside root
    const wrappers = root.querySelectorAll('.mh-wrapper');
    for (const wrapper of wrappers) {
      if (wrapper.shadowRoot) {
        result = wrapper.shadowRoot.querySelector(selector);
        if (result) return result;
      }
    }
    return null;
  }

  function queryShadowSelectorAll(selector, root = document) {
    const results = [];

    // Get from regular DOM
    results.push(...root.querySelectorAll(selector));

    // Get from shadow roots
    const wrappers = root.querySelectorAll('.mh-wrapper');
    for (const wrapper of wrappers) {
      if (wrapper.shadowRoot) {
        results.push(...wrapper.shadowRoot.querySelectorAll(selector));
      }
    }
    return results;
  }

  // Get the wrapper element for a shadow DOM element
  function getWrapperForShadowElement(element) {
    const root = element.getRootNode();
    if (root instanceof ShadowRoot) {
      return root.host;
    }
    return element.closest('.mh-wrapper');
  }

  // Check if a task contains a broken/expired audio element
  // Returns true if the audio file has expired (error_uIAm3 class or error text present)
  function hasBrokenAudio(taskElement) {
    if (!taskElement) return false;

    // Method 1: Check for error class (error_uIAm3, errorCompact_1JF7h)
    const errorElement = taskElement.querySelector('.error_uIAm3, .errorCompact_1JF7h, [class*="error"]');
    if (errorElement) {
      // Verify it's actually an audio error (contains specific error text)
      const errorText = errorElement.textContent || '';
      if (errorText.includes('failed to load') || errorText.includes('Error:') ||
        errorText.includes('does not contain audio')) {
        return true;
      }
    }

    // Method 2: Check for error text directly in the task
    const taskText = taskElement.textContent || '';
    if (taskText.includes('Error: failed to load the audio') ||
      taskText.includes('does not contain audio')) {
      return true;
    }

    // Method 3: Check for audio elements that have error state
    const audioElements = taskElement.querySelectorAll('audio');
    for (const audio of audioElements) {
      // Check if the audio has a network error (error code 4 = MEDIA_ERR_SRC_NOT_SUPPORTED)
      if (audio.error || (audio.networkState === 3)) { // 3 = NETWORK_NO_SOURCE
        return true;
      }
    }

    return false;
  }

  // Get shadow root for a wrapper, creating if needed
  function getOrCreateShadowRoot(wrapper) {
    if (!wrapper.shadowRoot) {
      const shadow = wrapper.attachShadow({ mode: 'open' });
      // Inject styles into shadow DOM - matching original styles.css
      const style = document.createElement('style');
      style.textContent = `
      :host {
        display: block;
        width: 100%;
        min-width: 300px;
        position: relative;
        margin-bottom: 10px;
      }
      ::slotted(audio) {
        width: 100%;
      }
      .mh-info {
        font-size: 0.9em;
        color: #666;
        margin-top: 5px;
        display: block;
        clear: both;
        width: 100%;
        min-width: 300px;
        padding: 2px 4px;
        transition: all 0.3s ease;
        border-radius: 3px;
      }
      .mh-info.highlight {
        color: white;
        font-weight: bold;
        background-color: #ff0000;
      }
      .mh-s-a {
        color: white;
        font-weight: bold;
        background-color: #2ecc71;
      }
      .mh-info::after {
        content: '\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0\\00a0';
      }
    `;
      shadow.appendChild(style);

      // Add slot for the audio element (light DOM content)
      const slot = document.createElement('slot');
      shadow.appendChild(slot);
    }
    return wrapper.shadowRoot;
  }

  // --- Expiration Date Detection & Highlighting (Media Helper) ---
  // --- Expiration Date Detection & Highlighting (Media Helper) ---
  let audioInfo = new Map();
  // Prevent FocusLock fighting by ensuring our elements don't trap focus aggressively
  // This is a passive fix: we don't fix the site, we just behave better.

  let updateTimeout = null;
  let lastUncommonResult = null;
  let audioElements = [];
  let observingAudio = new Set();

  // Add a global variable to track processed tasks
  let processedTasks = new Set();

  // Add storage for uncommon task answers
  // Map of audio URLs to ARRAY of {text, answer} objects (supports multiple texts per URL)
  // Format: Map<url, Array<{text, answer}>>
  // Map of audio URLs to ARRAY of {text, answer} objects (supports multiple texts per URL)
  // Format: Map<url, Array<{text, answer}>>
  let uncommonTaskAnswers = new Map();

  // Manual Uncommon Dates (User explicitly added)
  let manualUncommonDates = new Set();
  function loadManualUncommonDates() {
    chrome.storage.local.get('manualUncommonDates', (data) => {
      if (data.manualUncommonDates) {
        manualUncommonDates = new Set(data.manualUncommonDates);
      }
    });
  }
  loadManualUncommonDates();
  // Listen for storage changes to update manual dates and answers in real-time
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace !== 'local') return;

    if (changes.manualUncommonDates) {
      manualUncommonDates = new Set(changes.manualUncommonDates.newValue || []);
      updateAllExpirationElements();
    }

    if (changes.comparisonSaveAll !== undefined) {
      window._mh.csa = !!changes.comparisonSaveAll.newValue;
    }

    if (changes.uncommonTaskAnswers) {
      const rawMap = new Map(changes.uncommonTaskAnswers.newValue || []);
      uncommonTaskAnswers = new Map();
      // Re-process to ensure correct format (just like in loadUncommonTaskAnswers)
      for (const [url, value] of rawMap) {
        if (typeof value === 'string') {
          uncommonTaskAnswers.set(url, [{ text: '', answer: value }]);
        } else if (Array.isArray(value)) {
          uncommonTaskAnswers.set(url, value);
        } else if (value && typeof value === 'object' && value.answer) {
          uncommonTaskAnswers.set(url, [{ text: value.text || '', answer: value.answer }]);
        }
      }
      window._mh.uta = uncommonTaskAnswers;
      dlog('Synced uncommonTaskAnswers from storage update', uncommonTaskAnswers.size);
    }
  });

  // Text normalization for comparison (same as in arabic-evaluation.js)
  function normalizeTextForComparison(text) {
    if (!text) return '';
    return text.replace(/[^\u0621-\u064A\s]/g, '').replace(/\s+/g, ' ').trim();
  }

  // Check if two texts match (rough comparison for Arabic text)
  function textsMatch(savedText, currentText) {
    if (!savedText && !currentText) return true;
    if (!savedText || !currentText) return false;

    const s = normalizeTextForComparison(savedText);
    const c = normalizeTextForComparison(currentText);

    // Exact match after normalization
    if (s === c) return true;

    // If one contains the other
    if (s.includes(c) || c.includes(s)) return true;

    // Basic overlap check for long texts
    if (s.length > 20 && c.length > 20) {
      const sPart = s.substring(0, 20);
      if (c.includes(sPart)) return true;
    }

    return false;
  }

  // Load saved uncommon task answers from storage (with backward compatibility)
  function loadUncommonTaskAnswers() {
    chrome.storage.local.get('uncommonTaskAnswers', (data) => {
      if (data.uncommonTaskAnswers) {
        // Convert to Map and handle backward compatibility
        const rawMap = new Map(data.uncommonTaskAnswers);
        uncommonTaskAnswers = new Map();

        for (const [url, value] of rawMap) {
          // Handle THREE formats:
          // 1. Old format 1: string (just answer) -> [{text: '', answer}]
          // 2. Old format 2: {answer, text} single object -> [{text, answer}]
          // 3. New format: Array<{text, answer}> -> use as-is

          if (typeof value === 'string') {
            // Old format 1 - single answer string
            uncommonTaskAnswers.set(url, [{ text: '', answer: value }]);
          } else if (Array.isArray(value)) {
            // New format - array of entries
            uncommonTaskAnswers.set(url, value);
          } else if (value && typeof value === 'object' && value.answer) {
            // Old format 2 - single {answer, text} object -> convert to array
            uncommonTaskAnswers.set(url, [{ text: value.text || '', answer: value.answer }]);
          }
        }
        // Expose to window object so it's accessible by other scripts
        window._mh.uta = uncommonTaskAnswers;
      }
    });
  }

  // Find a saved entry by URL and text (returns {text, answer} or null)
  function findSavedEntry(audioUrl, currentText) {
    const entries = uncommonTaskAnswers.get(audioUrl);
    if (!entries || !Array.isArray(entries) || entries.length === 0) return null;

    // If no current text provided, return first entry (backward compat for old code)
    if (!currentText || !currentText.trim()) {
      return entries[0];
    }

    // Find entry with matching text
    for (const entry of entries) {
      if (textsMatch(entry.text, currentText)) {
        return entry;
      }
    }

    // No matching text found - return null (this is a new text for this URL)
    return null;
  }

  // Helper function to get just the answer from saved data (handles all formats)
  // Note: This is a legacy function for backward compatibility
  function getSavedAnswer(audioUrl, currentText) {
    const entry = findSavedEntry(audioUrl, currentText);
    return entry ? entry.answer : null;
  }

  // Save or update an entry for a URL+text combination
  function saveOrUpdateEntry(audioUrl, text, answer) {
    let entries = uncommonTaskAnswers.get(audioUrl);

    if (!entries || !Array.isArray(entries)) {
      // No entries for this URL yet - create new array
      uncommonTaskAnswers.set(audioUrl, [{ text: text || '', answer }]);
      return;
    }

    // Check if we have an entry with matching text
    let found = false;
    for (let i = 0; i < entries.length; i++) {
      if (textsMatch(entries[i].text, text)) {
        // Update existing entry's answer
        entries[i].answer = answer;
        // Also update the text in case the new one is more complete
        if (text && (!entries[i].text || text.length > entries[i].text.length)) {
          entries[i].text = text;
        }
        found = true;
        break;
      }
    }

    if (!found) {
      // No matching text - add new entry (same URL, different text)
      entries.push({ text: text || '', answer });
    }

    uncommonTaskAnswers.set(audioUrl, entries);
  }

  // Save uncommon task answers to storage
  function saveUncommonTaskAnswers() {
    chrome.storage.local.set({
      uncommonTaskAnswers: Array.from(uncommonTaskAnswers.entries())
    }, () => {
      // Update window object
      window._mh.uta = uncommonTaskAnswers;
    });
  }

  // Initialize by loading saved answers
  loadUncommonTaskAnswers();
  // Expose helper functions globally
  window._mh.gsa = getSavedAnswer;
  window._mh.fse = findSavedEntry;
  window._mh.tm = textsMatch;

  // Comparison task mode: save/apply ALL tasks vs only uncommon
  window._mh.csa = false;
  chrome.storage.local.get('comparisonSaveAll', (data) => {
    window._mh.csa = !!(data && data.comparisonSaveAll);
  });

  function getDateKey(dateString) {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return null;
      return date.toISOString().split('T')[0];
    } catch {
      return null;
    }
  }

  function findUncommonDates(dates) {
    if (!dates || dates.length < 2) return null;
    const validDates = dates.map(dateString => {
      try {
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return null;
        return {
          original: dateString,
          date,
          dateKey: getDateKey(dateString),
          month: date.getMonth(),
          year: date.getFullYear()
        };
      } catch { return null; }
    }).filter(Boolean);
    if (validDates.length < 2) return null;
    const dateCounts = new Map();
    for (const dateObj of validDates) {
      dateCounts.set(dateObj.dateKey, (dateCounts.get(dateObj.dateKey) || 0) + 1);
    }
    const monthYearGroups = new Map();
    for (const dateObj of validDates) {
      const key = `${dateObj.year}-${dateObj.month}`;
      if (!monthYearGroups.has(key)) monthYearGroups.set(key, []);
      monthYearGroups.get(key).push(dateObj);
    }
    if (monthYearGroups.size > 1) {
      let maxCount = 0, mostCommonKey = null;
      for (const [key, group] of monthYearGroups.entries()) {
        if (group.length > maxCount) { maxCount = group.length; mostCommonKey = key; }
      }
      const uncommonDates = validDates.filter(dateObj => {
        const key = `${dateObj.year}-${dateObj.month}`;
        return key !== mostCommonKey;
      }).map(dateObj => dateObj.dateKey);
      return uncommonDates.length > 0 ? { type: 'dates', values: uncommonDates } : null;
    }
    let maxCount = 0, mostCommonDateKey = null;
    for (const [dateKey, count] of dateCounts.entries()) {
      if (count > maxCount) { maxCount = count; mostCommonDateKey = dateKey; }
    }
    const uncommonDates = Array.from(dateCounts.entries())
      .filter(([dateKey, count]) => count < maxCount)
      .map(([dateKey]) => dateKey);
    return uncommonDates.length > 0 ? { type: 'dates', values: uncommonDates } : null;
  }

  function formatDisplayDate(dateString) {
    try {
      const date = new Date(dateString);
      const year = date.getFullYear().toString().slice(-1);
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const day = date.getDate().toString().padStart(2, '0');
      return `${year}${month}${day}`;
    } catch {
      return dateString;
    }
  }

  function injectExpirationDate(audioElement, expirationDate) {
    if (!audioElement || !expirationDate || typeof expirationDate !== 'string') return;
    if (expirationDate === 'NO_DATE') return; // Do not inject anything for audios that have missing dates
    
    let wrapper = audioElement.parentElement;
    if (!wrapper.classList.contains('mh-wrapper')) {
      wrapper = document.createElement('div');
      wrapper.className = 'mh-wrapper';
      audioElement.parentNode.insertBefore(wrapper, audioElement);
      wrapper.appendChild(audioElement);
    }

    // Use Shadow DOM for the date display
    const shadow = getOrCreateShadowRoot(wrapper);
    let expirationElement = shadow.querySelector('.mh-info');
    if (!expirationElement) {
      expirationElement = document.createElement('div');
      expirationElement.className = 'mh-info';
      shadow.appendChild(expirationElement);

      // Add double-click listener to mark as manually uncommon
      expirationElement.addEventListener('dblclick', (e) => {
        e.stopPropagation();
        const dateText = expirationElement.textContent;
        if (confirm(`Mark date ${dateText} as always uncommon?`)) {
          manualUncommonDates.add(dateText);
          chrome.storage.local.set({ manualUncommonDates: Array.from(manualUncommonDates) });
          updateAllExpirationElements();
        }
      });
    }
    const currentDates = Array.from(audioInfo.values()).filter(Boolean);
    if (currentDates.length >= 2) {
      lastUncommonResult = findUncommonDates(currentDates);
    }
    const currentDateKey = getDateKey(expirationDate);
    const displayDate = formatDisplayDate(expirationDate);
    expirationElement.textContent = displayDate;

    // Check if this is the only audio with a date while others exist without dates
    const totalAudioOnPage = findAllAudioElements().length;
    const audiosWithDates = currentDates.length;
    const isSoleDateAmongMany = audiosWithDates === 1 && totalAudioOnPage > 1;

    if (isSoleDateAmongMany || (lastUncommonResult !== null && currentDateKey && lastUncommonResult.type === 'dates' && lastUncommonResult.values.includes(currentDateKey)) || manualUncommonDates.has(displayDate)) {
      expirationElement.classList.add('highlight');
      dlog('Highlight set for audio', audioElement.src, 'dateKey', currentDateKey, 'manual', manualUncommonDates.has(displayDate), 'soleDateAmongMany', isSoleDateAmongMany);
    } else {
      expirationElement.classList.remove('highlight');
    }
  }

  function findAllAudioElements() {
    const directAudioElements = Array.from(document.getElementsByTagName('audio'));
    const iframes = Array.from(document.getElementsByTagName('iframe'));
    let iframeAudioElements = [];
    iframes.forEach(iframe => {
      try {
        if (iframe.contentDocument) {
          const audioInIframe = Array.from(iframe.contentDocument.getElementsByTagName('audio'));
          iframeAudioElements = iframeAudioElements.concat(audioInIframe);
        }
      } catch { }
    });
    return [...directAudioElements, ...iframeAudioElements];
  }

  let updateAudioPlayersTimeout = null;
  let nextUpdateForce = false;
  let nextUpdateRetain = false;

  function updateAudioPlayers(force = false, retainOverlays = false) {
    nextUpdateForce = nextUpdateForce || force;
    nextUpdateRetain = nextUpdateRetain || retainOverlays;
    
    if (updateAudioPlayersTimeout) {
      clearTimeout(updateAudioPlayersTimeout);
    }
    
    updateAudioPlayersTimeout = setTimeout(() => {
      executeUpdateAudioPlayers(nextUpdateForce, nextUpdateRetain);
      nextUpdateForce = false;
      nextUpdateRetain = false;
    }, 50); // Debounce by 50ms to prevent rapid, successive recalculations
  }

  function executeUpdateAudioPlayers(force = false, retainOverlays = false) {
    try {
      audioElements = findAllAudioElements();
      for (let audio of audioElements) {
        if (!audio) continue;
        if (!force && observingAudio.has(audio)) continue;

        if (!audio.querySelectorAll) continue;

        let sources = [];
        if (audio.src) sources.push(audio.src);

        try {
          const sourceElements = audio.querySelectorAll('source');
          if (sourceElements && sourceElements.length) {
            sources = [...sources, ...[...sourceElements].map(source => source && source.src).filter(Boolean)];
          }
        } catch (e) {
        }

        let foundDateForThisAudio = false;
        for (const src of sources) {
          if (!src) continue;
          const expirationDate = audioInfo.get(src) || audioInfo.get(src.replace('http://', 'https://'));
          if (expirationDate) {
            if (expirationDate !== 'NO_DATE' && audio) {
              injectExpirationDate(audio, expirationDate);
              foundDateForThisAudio = true;
            } else {
              // Handle NO_DATE gracefully without triggering another fetch
              foundDateForThisAudio = false;
            }
          } else {
            chrome.runtime.sendMessage({ action: 'checkAudioUrl', url: src });
            dlog('Requested header check for', src);
          }
        }
        // If no current date found for this audio, remove any stale overlay to avoid acting on old data
        if (!foundDateForThisAudio && !retainOverlays) {
          try {
            const wrapper = audio.closest('.mh-wrapper') || audio.parentElement;
            if (wrapper && wrapper.shadowRoot) {
              const info = wrapper.shadowRoot.querySelector('.mh-info');
              if (info) info.remove();
            }
          } catch (_) { }
        }
      }
      updateAllExpirationElements();
    } catch (error) { }
  }

  function updateAllExpirationElements() {
    const infoElements = queryShadowSelectorAll('.mh-info');
    const currentDates = Array.from(audioInfo.values());
    if (currentDates.length >= 2) {
      lastUncommonResult = findUncommonDates(currentDates);
      infoElements.forEach(element => {
        // Remove stale overlays that are not attached to an audio with a current known date
        const wrapper = getWrapperForShadowElement(element);
        const audio = wrapper ? wrapper.querySelector('audio') : null;
        if (!audio) {
          element.remove();
          return;
        }
        const hasAnyCurrent = (audio.src && (audioInfo.has(audio.src) || audioInfo.has(audio.src.replace('http://', 'https://'))));
        if (!hasAnyCurrent) {
          element.remove();
          return;
        }
        const dateText = element.textContent;
        if (!dateText) return;
        if (dateText.length === 5) {
          const y = '202' + dateText.substring(0, 1);
          const m = dateText.substring(1, 3);
          const d = dateText.substring(3, 5);
          const date = new Date(`${y}-${m}-${d}`);
          const dateKey = getDateKey(date);
          if ((lastUncommonResult.type === 'dates' && lastUncommonResult.values.includes(dateKey)) || manualUncommonDates.has(dateText)) {
            element.classList.add('highlight');
            dlog('Re-marked highlight for dateKey', dateKey, 'manual', manualUncommonDates.has(dateText));
          } else {
            element.classList.remove('highlight');
          }
        }
      });
    } else {
      // Fewer than 2 dates - check if there's exactly 1 date among multiple audios
      const totalAudioOnPage = findAllAudioElements().length;
      const isSoleDateAmongMany = currentDates.length === 1 && totalAudioOnPage > 1;

      infoElements.forEach(element => {
        // Also remove stale overlays when we do not yet have enough dates
        const wrapper = getWrapperForShadowElement(element);
        const audio = wrapper ? wrapper.querySelector('audio') : null;
        const hasAnyCurrent = audio && audio.src && (audioInfo.has(audio.src) || audioInfo.has(audio.src.replace('http://', 'https://')));
        if (!hasAnyCurrent) {
          element.remove();
        } else {
          const dateText = element.textContent;
          if (isSoleDateAmongMany || manualUncommonDates.has(dateText)) {
            element.classList.add('highlight');
            dlog('Sole date among many audios, highlighted:', dateText);
          } else {
            element.classList.remove('highlight');
          }
        }
      });
    }
  }

  // Recalculate uncommon dates based ONLY on dates currently visible on the page
  // This is used by quickRunAutomation to properly detect uncommon dates on the current page
  // without being affected by dates from previous pages still in audioInfo
  function recalculateVisibleDates() {
    const infoElements = queryShadowSelectorAll('.mh-info');

    // Collect only the dates currently visible on the page
    const visibleDates = [];
    const elementDateMap = new Map(); // Map element to its date key

    infoElements.forEach(element => {
      // Skip saved answer indicators
      if (element.classList.contains('mh-s-a')) return;

      const dateText = element.textContent;
      if (!dateText || dateText.length !== 5) return;

      // Parse the date from the 5-digit format (YMMDD where Y is last digit of year)
      const y = '202' + dateText.substring(0, 1);
      const m = dateText.substring(1, 3);
      const d = dateText.substring(3, 5);
      const date = new Date(`${y}-${m}-${d}`);
      const dateKey = getDateKey(date);

      if (dateKey) {
        visibleDates.push(dateKey);
        elementDateMap.set(element, dateKey);
      }
    });

    dlog('Visible dates on page:', visibleDates);

    if (visibleDates.length >= 2) {
      // Find uncommon dates among ONLY the visible ones
      const visibleUncommonResult = findUncommonDates(visibleDates);
      lastUncommonResult = visibleUncommonResult;

      dlog('Visible uncommon result:', visibleUncommonResult);

      // Update highlights based on visible dates comparison
      // Update highlights based on visible dates comparison
      elementDateMap.forEach((dateKey, element) => {
        const dateText = element.textContent;
        if ((visibleUncommonResult && visibleUncommonResult.type === 'dates' && visibleUncommonResult.values.includes(dateKey)) || manualUncommonDates.has(dateText)) {
          element.classList.add('highlight');
          dlog('Marked visible highlight for dateKey', dateKey, 'manual', manualUncommonDates.has(dateText));
        } else {
          element.classList.remove('highlight');
        }
      });
    } else if (visibleDates.length === 1) {
      // Only one date visible - check if it's the sole audio with a date among many audios
      const totalAudioOnPage = findAllAudioElements().length;
      const isSoleDateAmongMany = totalAudioOnPage > 1;

      elementDateMap.forEach((dateKey, element) => {
        const dateText = element.textContent;
        if (isSoleDateAmongMany || manualUncommonDates.has(dateText)) {
          element.classList.add('highlight');
          dlog('Single visible date highlighted:', dateKey, 'soleDateAmongMany', isSoleDateAmongMany, 'manual', manualUncommonDates.has(dateText));
        } else {
          element.classList.remove('highlight');
        }
      });
      // Set lastUncommonResult so downstream code treats this as uncommon
      if (isSoleDateAmongMany) {
        lastUncommonResult = { type: 'dates', values: visibleDates };
      } else {
        lastUncommonResult = null;
      }
    } else {
      // No visible dates found OR dates found but not enough to compare (0 dates)
      // Still need to check for manual highlights on any elements that might exist but failed parsing?
      // Actually if visibleDates is 0, elementDateMap is empty.

      // Fallback: iterate all elements again to check manual list (just in case they were filtered out somehow or logic above missed them)
      infoElements.forEach(element => {
        if (!element.classList.contains('mh-s-a')) {
          const dateText = element.textContent;
          if (manualUncommonDates.has(dateText)) {
            element.classList.add('highlight');
          } else {
            element.classList.remove('highlight');
          }
        }
      });
    }
  }

  function triggerInitialFullRefresh() {
    chrome.runtime.sendMessage({ action: 'getAudioInfo' }, (response) => {
      if (response && response.audioInfo) {
        audioInfo = new Map(response.audioInfo);
        updateAudioPlayers(true);
      }
    });
  }

  if (window.top === window.self) {
    document.addEventListener('DOMContentLoaded', triggerInitialFullRefresh);
  } else {
    window.addEventListener('load', triggerInitialFullRefresh);
  }

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'refreshAudioInfo') {
      audioInfo = new Map();
      updateAudioPlayers(true, true);

      // Reset any tracking of processed tasks
      if (window._mh.aeh && typeof window._mh.aeh.resetProcessedTasks === 'function') {
        window._mh.aeh.resetProcessedTasks();
      }
    } else if (request.type === 'allAudioInfo' && request.audioInfo) {
      audioInfo = new Map(request.audioInfo);
      updateAudioPlayers(true);
    } else if (request.action === 'selectOptions') {
      dlog('Message: selectOptions');
      injectPanel(); // Inject touch controls if needed
      runGenoAutomation();
    } else if (request.action === 'refreshAudioInfoAndSelectOptions') {
      // Reset any tracking of processed tasks
      if (window._mh.aeh && typeof window._mh.aeh.resetProcessedTasks === 'function') {
        window._mh.aeh.resetProcessedTasks();
      }
      chrome.runtime.sendMessage({ action: 'getAudioInfo' }, (response) => {
        if (response && response.audioInfo) {
          audioInfo = new Map(response.audioInfo);
          updateAudioPlayers(true);
        }
        injectPanel(); // Inject touch controls if needed
        runGenoAutomation();
      });
    } else if (request.action === 'fullRefreshAndSelect') {
      dlog('Message: fullRefreshAndSelect');
      audioInfo.clear();
      updateAudioPlayers(true, true);
      // Reset any tracking of processed tasks
      if (window._mh.aeh && typeof window._mh.aeh.resetProcessedTasks === 'function') {
        window._mh.aeh.resetProcessedTasks();
      }
      chrome.runtime.sendMessage({ action: 'getAudioInfo' }, (response) => {
        if (response && response.audioInfo) {
          audioInfo = new Map(response.audioInfo);
          updateAudioPlayers(true);
        }
        injectPanel(); // Inject touch controls if needed
        runGenoAutomation();
      });
    } else if (request.action === 'captureUncommonAnswers') {
      // Handle the Ctrl+M shortcut from background script
      captureUncommonTaskAnswers();
    } else if (request.action === 'clearUncommonAnswers') {
      // Handle the Ctrl+Shift+M shortcut from background script
      clearUncommonTaskAnswers();
    }
  });

  function waitForExpirationHighlights(maxAttempts = 5, delay = 100) {
    return new Promise((resolve, reject) => {
      let attempts = 0;
      function check() {
        const highlights = queryShadowSelectorAll('.mh-info');
        if (highlights.length > 0) {
          dlog('Highlights exist:', highlights.length);
          resolve();
        } else if (++attempts < maxAttempts) {
          setTimeout(check, delay);
        } else {
          dlog('No highlights after wait. Continuing.');
          resolve();
        }
      }
      check();
    });
  }

  // Smart adaptive wait for expiration data:
  // Polls audio elements on the page and background pending-header count.
  // Resolves as soon as ALL audio elements have dates OR no headers are pending
  // for a stable window. Uses exponential back-off polling (50ms -> 200ms) and
  // a generous safety timeout (8s) so slow networks eventually proceed.
  function waitForExpirationDataReady(timeoutMs = 8000) {
    return new Promise((resolve) => {
      const start = Date.now();
      const stableRequiredMs = 250; // pending must stay 0 for this long
      let stableSince = null;
      let pollInterval = 50; // start fast, back off

      const check = () => {
        try {
          const audioEls = document.querySelectorAll('audio');
          const totalAudios = audioEls.length;
          const datesCount = Array.from(audioInfo.values()).filter(Boolean).length;

          // If we have dates for every audio element, we're done
          if (totalAudios > 0 && datesCount >= totalAudios) {
            dlog('ExpirationReady: all', totalAudios, 'audios have dates');
            resolve();
            return;
          }

          // If we have at least 2 dates and have been waiting > 2s, good enough
          if (datesCount >= 2 && Date.now() - start > 2000) {
            dlog('ExpirationReady: 2+ dates after 2s, proceeding');
            resolve();
            return;
          }

          chrome.runtime.sendMessage({ action: 'getPendingHeaderStatus' }, (res) => {
            const pending = res && typeof res.pendingCount === 'number' ? res.pendingCount : 0;

            if (pending === 0) {
              if (stableSince === null) stableSince = Date.now();
              if (Date.now() - stableSince >= stableRequiredMs) {
                dlog('ExpirationReady: no pending headers for', stableRequiredMs, 'ms');
                resolve();
                return;
              }
            } else {
              stableSince = null;
              // Reset to fast polling while requests are active
              pollInterval = 50;
            }

            // Safety timeout
            if (Date.now() - start >= timeoutMs) {
              dlog('ExpirationReady: safety timeout reached at', timeoutMs, 'ms');
              resolve();
              return;
            }

            // Exponential back-off: 50 -> 75 -> 112 -> 168 -> 200 (capped)
            pollInterval = Math.min(pollInterval * 1.5, 200);
            setTimeout(check, pollInterval);
          });
        } catch (e) {
          resolve();
        }
      };
      check();
    });
  }

  // Detect mobile once and cache: true on Android / iOS / touch-only devices
  const isMobileDevice = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) ||
    ('ontouchstart' in window && !window.matchMedia('(pointer:fine)').matches);

  function stealthClick(element) {
    if (!element) return;

    // Get element position for realistic coordinates
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width * (0.3 + Math.random() * 0.4);
    const y = rect.top + rect.height * (0.3 + Math.random() * 0.4);

    const baseOpts = {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: x + window.screenX,
      screenY: y + window.screenY
    };

    if (isMobileDevice) {
      // Touch event sequence: pointerdown -> touchstart -> pointerup -> touchend -> click
      const touch = new Touch({
        identifier: Date.now(),
        target: element,
        clientX: x,
        clientY: y,
        screenX: x,
        screenY: y,
        pageX: x + window.scrollX,
        pageY: y + window.scrollY
      });

      const pointerOpts = {
        ...baseOpts,
        pointerId: 1,
        pointerType: 'touch',
        isPrimary: true,
        width: 1,
        height: 1,
        pressure: 0.5
      };

      const touchOpts = {
        bubbles: true,
        cancelable: true,
        touches: [touch],
        targetTouches: [touch],
        changedTouches: [touch]
      };

      element.dispatchEvent(new PointerEvent('pointerdown', pointerOpts));
      element.dispatchEvent(new TouchEvent('touchstart', touchOpts));

      element.dispatchEvent(new PointerEvent('pointerup', { ...pointerOpts, pressure: 0 }));
      element.dispatchEvent(new TouchEvent('touchend', {
        ...touchOpts,
        touches: [],
        targetTouches: []
      }));

      element.dispatchEvent(new MouseEvent('click', { ...baseOpts, button: 0, buttons: 0 }));
    } else {
      // Desktop: pointer + mouse event sequence
      const pointerOpts = {
        ...baseOpts,
        pointerId: 1,
        pointerType: 'mouse',
        isPrimary: true,
        button: 0,
        buttons: 1
      };

      const mouseOpts = { ...baseOpts, button: 0, buttons: 1 };

      // PointerEvents first, then MouseEvents
      element.dispatchEvent(new PointerEvent('pointerover', pointerOpts));
      element.dispatchEvent(new PointerEvent('pointerenter', { ...pointerOpts, bubbles: false }));
      element.dispatchEvent(new MouseEvent('mouseenter', { ...mouseOpts, bubbles: false }));
      element.dispatchEvent(new MouseEvent('mouseover', mouseOpts));

      element.dispatchEvent(new PointerEvent('pointerdown', pointerOpts));
      element.dispatchEvent(new MouseEvent('mousedown', mouseOpts));

      element.dispatchEvent(new PointerEvent('pointerup', { ...pointerOpts, buttons: 0 }));
      element.dispatchEvent(new MouseEvent('mouseup', { ...mouseOpts, buttons: 0 }));

      element.dispatchEvent(new MouseEvent('click', { ...mouseOpts, buttons: 0 }));
    }
  }

  function scheduleInjectedElementRemoval() {
    // This function is disabled to keep highlights visible permanently
    // The original implementation removed highlights after a timeout
    return;

    // Original code kept for reference
    /*
    const infos = document.querySelectorAll('.mh-info');
    if (infos.length === 0) return;
    let timeout = infos.length === 1 ? 3000 : 60000; 
    setTimeout(() => {
      infos.forEach(el => {
        const wrapper = el.closest('.mh-wrapper');
        el.remove();
        if (wrapper && wrapper.classList.contains('mh-wrapper')) {
          if (wrapper.children.length === 1 && wrapper.querySelector('audio')) {
            const audio = wrapper.querySelector('audio');
            wrapper.parentNode.insertBefore(audio, wrapper);
            wrapper.remove();
          } else if (wrapper.children.length === 0) {
            wrapper.remove();
          }
        }
      });
    }, timeout);
    */
  }

  // --- Audio Comparison Tasks (تعادل) ---

  function detectAudioComparisonTask() {
    const pageText = document.body.innerText || '';
    return pageText.includes('تعادل');
  }

  function getComparisonCategory(taskElement) {
    const h3 = taskElement.querySelector('.container_2G9RK h3');
    return h3 ? h3.textContent.trim() : '';
  }

  function getComparisonKey(taskElement) {
    const audioUrls = Array.from(taskElement.querySelectorAll('audio'))
      .map(a => a.src)
      .filter(Boolean)
      .sort();
    if (audioUrls.length < 2) return null;
    const category = getComparisonCategory(taskElement);
    return 'cmp:' + (category ? category + ':' : '') + audioUrls.join('|');
  }

  function getComparisonTaskText(taskElement) {
    const category = getComparisonCategory(taskElement);

    let mainText = '';
    const rtlContainer = taskElement.querySelector('.container_3rKiN[dir="rtl"]');
    if (rtlContainer) {
      mainText = rtlContainer.textContent.trim();
    } else {
      const containers = taskElement.querySelectorAll('.container_3rKiN');
      for (const c of containers) {
        const text = c.textContent.trim();
        if (/[\u0600-\u06FF]/.test(text) && !text.includes('تعادل')) {
          mainText = text;
          break;
        }
      }
    }

    if (category && mainText) return '[' + category + '] ' + mainText;
    if (category) return '[' + category + ']';
    return mainText;
  }

  function identifyComparisonChoices(task) {
    const radios = task.querySelectorAll('input[type="radio"]');
    const choices = {};

    radios.forEach(radio => {
      const labelId = radio.getAttribute('aria-labelledby');
      const label = labelId ? document.getElementById(labelId) : null;
      const labelText = label ? label.textContent : '';
      const radioValue = radio.value || '';

      if (labelText.includes('تعادل') || radioValue.includes('equal')) {
        choices.equal = radio;
      } else if (labelText.includes('الأول')) {
        choices.first = radio;
      } else if (labelText.includes('الثاني')) {
        choices.second = radio;
      }
    });

    if (choices.first && choices.second && choices.equal) return choices;
    return null;
  }

  function getSelectedComparisonAnswer(task) {
    const choices = identifyComparisonChoices(task);
    if (!choices) return null;

    for (const [answer, radio] of Object.entries(choices)) {
      if (radio.checked || radio.getAttribute('aria-checked') === 'true') {
        return answer;
      }
      const label = radio.closest('label');
      if (label && label.classList.contains('Radiobox-Radio_checked')) {
        return answer;
      }
    }
    return null;
  }

  function handleAudioComparisonTasks() {
    let taskContainers = Array.from(document.querySelectorAll('div[data-test-id^="task-"]'));
    if (taskContainers.length === 0) {
      taskContainers = Array.from(document.querySelectorAll('.tb-task, .lUeJm._2t-aw'));
      taskContainers = taskContainers.filter(t =>
        !taskContainers.some(other => other !== t && other.contains(t)));
    }

    if (taskContainers.length === 0) return;

    const distribution = [];
    const count = taskContainers.length;
    const firstCount = Math.round(count * 0.35);
    const secondCount = Math.round(count * 0.35);
    const equalCount = count - firstCount - secondCount;
    distribution.push(...Array(firstCount).fill('first'));
    distribution.push(...Array(secondCount).fill('second'));
    distribution.push(...Array(equalCount).fill('equal'));
    for (let i = distribution.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [distribution[i], distribution[j]] = [distribution[j], distribution[i]];
    }

    const saveAllMode = !!window._mh.csa;
    dlog('Comparison: mode =', saveAllMode ? 'ALL' : 'TEST-ONLY');

    let normalIdx = 0;
    for (const task of taskContainers) {
      const choices = identifyComparisonChoices(task);
      if (!choices) continue;

      let isUncommon = false;
      const audioElements = task.querySelectorAll('audio');
      for (const audio of audioElements) {
        const wrapper = audio.closest('.mh-wrapper');
        if (wrapper && queryShadowSelector('.mh-info.highlight', wrapper)) {
          isUncommon = true;
          break;
        }
      }
      if (!isUncommon) isUncommon = hasBrokenAudio(task);

      const shouldLookup = isUncommon || saveAllMode;

      if (shouldLookup) {
        const compKey = getComparisonKey(task);
        const taskText = getComparisonTaskText(task);

        if (compKey) {
          const savedEntry = findSavedEntry(compKey, taskText);
          if (savedEntry && choices[savedEntry.answer]) {
            clickRadioButton(choices[savedEntry.answer]);
            const clickedLabel = choices[savedEntry.answer].closest('label');
            if (clickedLabel) clickedLabel.click();

            const firstAudio = audioElements[0];
            if (firstAudio) {
              const wrapper = firstAudio.closest('.mh-wrapper');
              if (wrapper && wrapper.shadowRoot) {
                let indicator = wrapper.shadowRoot.querySelector('.mh-s-a');
                if (!indicator) {
                  indicator = document.createElement('div');
                  indicator.className = 'mh-info mh-s-a';
                  indicator.textContent = savedEntry.answer + (savedEntry.text ? ': ' + savedEntry.text.substring(0, 60) : '');
                  wrapper.shadowRoot.appendChild(indicator);
                }
              }
            }
            dlog('Comparison: applied saved answer', savedEntry.answer, 'for key', compKey.substring(0, 40));
          } else {
            dlog('Comparison: no saved answer, skipping task');
          }
        }
      } else {
        const pick = distribution[normalIdx % distribution.length] || 'first';
        normalIdx++;
        if (choices[pick]) {
          clickRadioButton(choices[pick]);
          const clickedLabel = choices[pick].closest('label');
          if (clickedLabel) clickedLabel.click();
        }
      }

      audioElements.forEach(audio => {
        try {
          audio.dispatchEvent(new Event('play', { bubbles: true }));
          audio.dispatchEvent(new Event('timeupdate', { bubbles: true }));
          audio.dispatchEvent(new Event('ended', { bubbles: true }));
        } catch (e) { }
      });
    }

    simulateAllAudioEvents();

    setTimeout(() => {
      const redTextElement = queryShadowSelector('.mh-info.highlight');
      if (redTextElement) {
        const wrapper = getWrapperForShadowElement(redTextElement);
        if (wrapper) {
          wrapper.scrollIntoView({ behavior: 'instant', block: 'center' });
        }
        const parentContainer = wrapper || redTextElement.closest('.container_2CZFB');
        const audioElement = parentContainer ? parentContainer.querySelector('audio') : null;
        if (audioElement) {
          if (audioElement.readyState >= 2) audioElement.play().catch(() => { });
          else audioElement.addEventListener('canplay', () => audioElement.play().catch(() => { }), { once: true });
        }
        setTimeout(() => {
          if (typeof window._mh.crt === 'function') window._mh.crt();
          else clickRedText();
        }, 30);
      }
    }, 150);
  }

  // --- Geno's selectOptions and helpers (from Geno Audio Helper) ---

  async function selectOptions() {
    // If this is the top frame and not an iframe, just provide debug feedback but don't execute
    if (window === window.top) {
      dlog('Top frame - skipping');
      return { handled: true, reason: "Top frame" };
    }

    // Initialize Arabic evaluation handler if it exists
    if (window._mh.aeh && typeof window._mh.aeh.init === 'function') {
      // Always re-initialize to ensure latest settings
      window._mh.aeh.init({
        stealthClick: stealthClick
      });

      // Force a refresh of settings for the Arabic handler
      chrome.runtime.sendMessage({ action: 'getArabicSettings' }, (response) => {
        if (response && response.arabicSettings) {
          // Create an event to notify about settings
          const event = new CustomEvent('arabicSettingsUpdated', {
            detail: { settings: response.arabicSettings }
          });
          document.dispatchEvent(event);
        }
      });
    }

    // Avoid acting before expiration data is ready enough on slow networks
    try {
      dlog('Waiting for expiration readiness...');
      await waitForExpirationDataReady();
      dlog('Expiration readiness OK');
    } catch (e) { dlog('Expiration readiness wait error', e); }

    // flag to track if we need to click red text after task processing
    let shouldCheckForRedText = true;

    // === PRIORITY #0: Audio Comparison Tasks (تعادل) ===
    if (detectAudioComparisonTask()) {
      dlog('Audio comparison task detected (تعادل)');
      handleAudioComparisonTasks();
      return { handled: true, reason: "Audio comparison" };
    }

    // === PRIORITY #1: Arabic Evaluation Check ===
    if (window._mh.aeh && typeof window._mh.aeh.detectArabicEvaluation === 'function') {
      try {
        dlog('Arabic: detect start');
        let isArabicTask = window._mh.aeh.detectArabicEvaluation();
        dlog('Arabic: detect result', isArabicTask);

        if (isArabicTask) {
          if (typeof window._mh.aeh.handleArabicEvaluationTasks === 'function') {
            dlog('Arabic: handling tasks...');
            debugScanArabic('pre');
            window._mh.aeh.handleArabicEvaluationTasks();
            setTimeout(() => debugScanArabic('post'), 300);
            shouldCheckForRedText = false;
            return { handled: true, reason: "Arabic evaluation" };
          }
        }
      } catch (e) {
        dlog('Arabic error', e);
      }
    }

    // === PRIORITY #2: Standard Task Containers ===
    const radioButtons = document.querySelectorAll('input[type="radio"]');
    const hasHighlightMark = document.querySelector('mark'); // For "select text" tasks

    // === PRIORITY #2.5: Payload Button Tasks (e.g. Arabic Evaluation) ===
    // Enhanced handling for the HTML structure provided by user
    const payloadButtons = document.querySelectorAll('button[payload]');
    if (payloadButtons.length > 0) {
      dlog('Found payload buttons, processing...');

      // Use the improved task container logic
      let taskContainers = Array.from(document.querySelectorAll('div[data-test-id^="task-"]'));
      if (taskContainers.length === 0) {
        taskContainers = Array.from(document.querySelectorAll('.tb-task, .lUeJm'));
        // Filter out nested
        taskContainers = taskContainers.filter(t => !taskContainers.some(other => other !== t && other.contains(t)));
      }

      let handledCount = 0;

      for (const container of taskContainers) {
        const btns = container.querySelectorAll('button[payload]');
        if (btns.length === 0) continue;

        // Check if this task is "uncommon" (highlighted OR has broken/expired audio)
        const isUncommon = !!queryShadowSelector('.mh-info.highlight', container) ||
          !!queryShadowSelector('.mh-info.highlight', container.closest('.mh-wrapper') || container) ||
          hasBrokenAudio(container);

        let btnToClick = null;

        if (isUncommon) {
          // For uncommon tasks, we might want to double check or select a specific option
          // Defaulting to 'ok' for now as it's the safest fast option, 
          // but user can manually correct if needed.
          // If previous logic selected 'mistake' and was wrong, 'ok' is a better bet.
          btnToClick = Array.from(btns).find(b => b.getAttribute('payload') === 'ok');
        } else {
          // Standard task - Default to 'ok'
          btnToClick = Array.from(btns).find(b => b.getAttribute('payload') === 'ok');
        }

        // Fallback to first button if 'ok' not found
        if (!btnToClick) btnToClick = btns[0];

        if (btnToClick) {
          // Fast click
          stealthClick(btnToClick);
          // Native click for good measure (some frameworks need it)
          btnToClick.click();
          handledCount++;
        }
      }

      // Simulate audio events to ensure the page thinks we listened
      simulateAllAudioEvents();

      if (handledCount > 0) {
        return { handled: true, reason: "Payload buttons processed" };
      }
    }

    if (radioButtons.length === 0 && hasHighlightMark) {
      dlog('No radios; found <mark>; invoking clickRedText');
      clickRedText();
      shouldCheckForRedText = false;
      return { handled: true, reason: "No radio buttons, but highlighted text (mark) found" };
    }

    // === PRIORITY #3: Standard Radio Button Tasks ===
    if (radioButtons.length > 0) {
      // --- START OF INTEGRATED OLD LOGIC ---
      dlog('Radio flow: waiting for audio players');
      await waitForAudioPlayersReady();
      // const highlightFoundOnPage = await findHighlightElement(); // Check for any .mh-info.highlight on the page

      document.querySelectorAll('.selection-indicator').forEach(el => el.remove());

      let taskContainers = Array.from(document.querySelectorAll('.tb-task .container_2CZFB, .lUeJm .container_2CZFB'));
      if (taskContainers.length === 0) {
        // Fallback to any container_2CZFB if more specific ones aren't found
        taskContainers = Array.from(document.querySelectorAll('.container_2CZFB'));
      }

      // Filter containers: must have radio buttons and not be nested inside another selected container
      taskContainers = taskContainers.filter(container => {
        const hasRadio = container.querySelectorAll('input[type="radio"]').length > 0;
        const isNested = Array.from(taskContainers).some(otherContainer =>
          otherContainer !== container && otherContainer.contains(container));
        return hasRadio && !isNested;
      });

      if (taskContainers.length === 0) {
        // console.log("Radio buttons exist on page, but no suitable task containers found for detailed processing. Using fallback clickByStrategy.");
        dlog('No task containers -> clickByStrategy fallback');
        clickByStrategy(radioButtons); // Fallback to simpler strategy
        simulateAllAudioEvents();
      } else {
        let uncommonTasks = [];
        let regularTasks = []; // Tasks with >= 4 buttons
        let twoButtonTasks = [];

        taskContainers.forEach((container, i) => {
          const taskElement = container.closest('.tb-task, .task, .lUeJm');
          // Ensure taskIndex is reliably determined
          const taskIndex = taskElement ?
            parseInt(
              taskElement.getAttribute('data-microtask-index') ||
              taskElement.getAttribute('data-test-id')?.replace('task-', '') ||
              i.toString(), // Ensure string for parseInt if i is the only source
              10) : i;

          const currentTaskRadioButtons = container.querySelectorAll('input[type="radio"]');
          if (currentTaskRadioButtons.length === 0) return;

          // Check if task is uncommon (highlighted OR has broken/expired audio)
          let isUncommonTask = !!queryShadowSelector('.mh-info.highlight', container) ||
            !!queryShadowSelector('.mh-info.highlight', container.closest('.mh-wrapper') || container) ||
            hasBrokenAudio(container);

          if (isUncommonTask) {
            uncommonTasks.push({ container, index: taskIndex, buttonCount: currentTaskRadioButtons.length });
          } else if (currentTaskRadioButtons.length === 2) {
            twoButtonTasks.push({ container, index: taskIndex });
          } else if (currentTaskRadioButtons.length >= 4) {
            regularTasks.push({ container, index: taskIndex });
          }
        });

        uncommonTasks.forEach(({ container, buttonCount, index }) => {
          const uncommonRadioButtons = container.querySelectorAll('input[type="radio"]');
          if (buttonCount >= 4) {
            if (uncommonRadioButtons[0]) clickRadioButton(uncommonRadioButtons[0]);
            if (uncommonRadioButtons[2]) clickRadioButton(uncommonRadioButtons[2]);
          } else if (buttonCount === 2) {
            twoButtonTasks.push({ container, index }); // Add to twoButtonTasks for speech detection
          }
        });

        if (regularTasks.length > 0) {
          const target02Count = Math.round(regularTasks.length * 0.33);
          const target12Count = Math.round(regularTasks.length * 0.44);
          const target13Count = regularTasks.length - target02Count - target12Count;
          let choices4Button = [
            ...Array(target02Count).fill('02'),
            ...Array(target12Count).fill('12'),
            ...Array(target13Count).fill('13')
          ];
          choices4Button = shuffleArray(choices4Button);

          regularTasks.forEach(({ container }, i) => {
            const regularRadioButtons = container.querySelectorAll('input[type="radio"]');
            const choice = choices4Button[i % choices4Button.length];
            if (regularRadioButtons.length >= 4) {
              let firstIndex, secondIndex;
              switch (choice) {
                case '02': firstIndex = 0; secondIndex = 2; break;
                case '12': firstIndex = 1; secondIndex = 2; break;
                case '13': firstIndex = 1; secondIndex = 3; break;
                default: firstIndex = 0; secondIndex = 2;
              }
              if (regularRadioButtons[firstIndex]) clickRadioButton(regularRadioButtons[firstIndex]);
              if (regularRadioButtons[secondIndex]) clickRadioButton(regularRadioButtons[secondIndex]);
            }
          });
        }

        if (twoButtonTasks.length > 0) {
          dlog('Two-button tasks count', twoButtonTasks.length);
          await processTwoButtonTasksWithSpeechDetection(twoButtonTasks);
        }
        simulateAllAudioEvents();
      }
      // --- END OF INTEGRATED OLD LOGIC ---

      // After clicking radio buttons (either by detailed logic or fallback), check for red text with a delay
      setTimeout(() => {
        if (shouldCheckForRedText) {
          const redTextElement = queryShadowSelector('.mh-info.highlight');
          if (redTextElement) {
            // Just add the missing audio playback before calling clickRedText
            const parentContainer = redTextElement.closest('.container_2CZFB, .audio-container, .mh-wrapper') || redTextElement.parentElement;
            const audioElement = parentContainer ? parentContainer.querySelector('.player_2DX_F, audio') : null;
            if (audioElement && audioElement.tagName === 'AUDIO') {
              if (audioElement.readyState >= 2) {
                audioElement.play().catch(() => { });
              } else {
                audioElement.addEventListener('canplay', () => {
                  audioElement.play().catch(() => { });
                }, { once: true });
              }

              // Add stealth click after audio play
              setTimeout(() => {
                stealthClick(redTextElement);
                clickRedText(); // This handles scrolling, simulation, and clicking
              }, 100);
            } else {
              clickRedText(); // No audio, just do the normal clickRedText
            }
          }
        }
      }, 500);

      return { handled: true, reason: "Radio buttons" };
    }

    // === PRIORITY #4: Audio Classification Tasks ===
    const audioContainer = document.getElementById('audioContainer');
    if (audioContainer && audioContainer.querySelector('audio')) {
      processAudioClassification();

      // After processing audio classification, check for red text with a delay
      setTimeout(() => {
        if (shouldCheckForRedText) {
          const redTextElement = queryShadowSelector('.mh-info.highlight');
          if (redTextElement) {
            clickRedText();
          }
        }
      }, 500);

      return { handled: true, reason: "Audio classification" };
    }

    // === FALLBACK: Check for standalone highlight if no other actions taken ===
    const standaloneHighlight = queryShadowSelector('.mh-info.highlight');
    if (standaloneHighlight) {
      clickRedText(); // This function handles scrolling, clicking, and playing audio
      return { handled: true, reason: "Standalone highlight processed" };
    }

    // If we reach here, no actionable elements were found
    return { handled: false, reason: "No actionable elements" };
  }

  async function processTwoButtonTasksWithSpeechDetection(twoButtonTasks) {
    if (twoButtonTasks.length === 0) return;

    for (const { container, index } of twoButtonTasks) {
      const radioButtons = container.querySelectorAll('input[type="radio"]');
      if (radioButtons.length !== 2) continue;
      let audioElement =
        container.querySelector('.player_2DX_F, audio') ||
        container.querySelector('.container_1d44k .player_2DX_F, .container_1d44k audio') ||
        container.closest('.tb-task, .task, .lUeJm')?.querySelector('.player_2DX_F, audio');
      let selectionResult = "";
      if (audioElement) {
        try {
          const hasSpeech = await detectSpeechWithEnergy(audioElement);
          const buttonIndex = hasSpeech ? 0 : 1;
          clickRadioButton(radioButtons[buttonIndex]);
        } catch (error) {
          clickRadioButton(radioButtons[1]);
        }
      } else {
        const iframe = document.querySelector('iframe');
        if (iframe) {
          try {
            const iframeAudio = iframe.contentDocument.querySelector(`.task[data-microtask-index="${index}"] audio, .tb-task[data-microtask-index="${index}"] audio`);
            if (iframeAudio) {
              const hasSpeech = await detectSpeechWithEnergy(iframeAudio);
              const buttonIndex = hasSpeech ? 0 : 1;
              clickRadioButton(radioButtons[buttonIndex]);
              continue;
            }
          } catch (e) {
            // Error accessing iframe content
          }
        }
        const microtaskIndex = container.closest('.tb-task, .task')?.getAttribute('data-microtask-index');
        let foundAudio = null;
        if (microtaskIndex !== null) {
          document.querySelectorAll('.tb-task, .task').forEach(task => {
            if (task.getAttribute('data-microtask-index') === microtaskIndex) {
              const audio = task.querySelector('audio, .player_2DX_F');
              if (audio) foundAudio = audio;
            }
          });
        }
        if (foundAudio) {
          try {
            const hasSpeech = await detectSpeechWithEnergy(foundAudio);
            const buttonIndex = hasSpeech ? 0 : 1;
            clickRadioButton(radioButtons[buttonIndex]);
          } catch (error) {
            clickRadioButton(radioButtons[1]);
          }
        } else {
          clickRadioButton(radioButtons[1]);
        }
      }
    }
  }

  let audioSettings = {
    energyThreshold: 0.001,
    variationThreshold: 0.4,
    zeroCrossingThreshold: 0.35,
    minSegmentDuration: 6,
    segmentVariationThreshold: 0.15
  };

  chrome.runtime.sendMessage({ action: 'getAudioSettings' }, (response) => {
    if (response && response.audioSettings) {
      audioSettings = response.audioSettings;
    }
  });

  // This listener is for audio settings, keep it separate from Arabic settings listener in arabic-evaluation.js
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'audioSettingsUpdated' && message.audioSettings) {
      audioSettings = message.audioSettings;
    }

    // Add direct forwarding of settings to the Arabic evaluation handler
    if (message.type === 'arabicSettingsUpdated' && message.settings &&
      window._mh.aeh) {
      // Forward the message to the Arabic evaluation handler
      if (window._mh.aeh.resetProcessedTasks) {
        window._mh.aeh.resetProcessedTasks();
      }
    }
  });

  function detectSpeechWithEnergy(audioElement) {
    return new Promise((resolve, reject) => {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      const audioContext = new AudioContext();
      const energyThreshold = audioSettings.energyThreshold;
      const variationThreshold = audioSettings.variationThreshold;
      const zeroCrossingThreshold = audioSettings.zeroCrossingThreshold;
      const minSegmentDuration = audioSettings.minSegmentDuration;
      const segmentVariationThreshold = audioSettings.segmentVariationThreshold;
      if (!audioElement.src) {
        audioContext.close();
        reject(new Error("Audio element has no source"));
        return;
      }
      fetch(audioElement.src)
        .then(response => {
          if (!response.ok) {
            throw new Error(`Failed to fetch audio: ${response.status} ${response.statusText}`);
          }
          return response.arrayBuffer();
        })
        .then(arrayBuffer => audioContext.decodeAudioData(arrayBuffer))
        .then(audioBuffer => {
          const audioData = audioBuffer.getChannelData(0);
          const sampleRate = audioBuffer.sampleRate;
          const chunkSize = Math.floor(sampleRate * 0.1);
          const skipFirstSecond = audioBuffer.duration > 2;
          const skipChunks = skipFirstSecond ? Math.floor(sampleRate / chunkSize) : 0;
          const chunkEnergies = [];
          for (let i = skipFirstSecond ? (skipChunks * chunkSize) : 0; i < audioData.length; i += chunkSize) {
            const end = Math.min(i + chunkSize, audioData.length);
            const chunk = audioData.slice(i, end);
            let sumSquares = 0;
            for (let j = 0; j < chunk.length; j++) {
              sumSquares += chunk[j] * chunk[j];
            }
            const rms = Math.sqrt(sumSquares / chunk.length);
            chunkEnergies.push(rms);
          }
          if (chunkEnergies.length < 3) {
            audioContext.close();
            resolve(false);
            return;
          }
          const maxEnergy = Math.max(...chunkEnergies);
          const avgEnergy = chunkEnergies.reduce((sum, val) => sum + val, 0) / chunkEnergies.length;
          let variance = chunkEnergies.reduce((sum, val) => sum + Math.pow(val - avgEnergy, 2), 0) / chunkEnergies.length;
          const stdDev = Math.sqrt(variance);
          let zeroCrossings = 0;
          const startSample = skipFirstSecond ? sampleRate : 0;
          const sampleSize = Math.min(48000, audioData.length - startSample);
          for (let i = startSample + 1; i < startSample + sampleSize; i++) {
            if ((audioData[i] >= 0 && audioData[i - 1] < 0) ||
              (audioData[i] < 0 && audioData[i - 1] >= 0)) {
              zeroCrossings++;
            }
          }
          const zeroCrossingRate = zeroCrossings / sampleSize;
          const energyThresholdForChunk = energyThreshold * 1.5;
          let activeChunks = chunkEnergies.map(energy => energy > energyThresholdForChunk);
          let speechSegments = [];
          let currentSegment = [];
          for (let i = 0; i < activeChunks.length; i++) {
            if (activeChunks[i]) {
              currentSegment.push(i);
            } else if (currentSegment.length > 0) {
              speechSegments.push(currentSegment);
              currentSegment = [];
            }
          }
          if (currentSegment.length > 0) {
            speechSegments.push(currentSegment);
          }
          const speechSegmentStats = speechSegments.map(segment => {
            const duration = segment.length;
            const segmentEnergies = segment.map(idx => chunkEnergies[idx]);
            const meanEnergy = segmentEnergies.reduce((sum, e) => sum + e, 0) / duration;
            const segVariance = segmentEnergies.reduce((sum, e) => sum + Math.pow(e - meanEnergy, 2), 0) / duration;
            const segStdDev = Math.sqrt(segVariance);
            return { duration, meanEnergy, segStdDev, variationCoeff: segStdDev / meanEnergy };
          });
          const hasSustainedSegments = speechSegmentStats.some(seg =>
            seg.duration >= minSegmentDuration &&
            seg.variationCoeff > segmentVariationThreshold
          );
          const hasSpeech = (
            maxEnergy > energyThreshold &&
            (stdDev / avgEnergy) > variationThreshold &&
            zeroCrossingRate < zeroCrossingThreshold &&
            hasSustainedSegments
          );
          audioContext.close();
          resolve(hasSpeech);
        })
        .catch(error => {
          audioContext.close();
          reject(error);
        });
    });
  }

  function simulateAudioEvents(audio) {
    if (!audio) {
      // console.log('[MediaHelperDebug] simulateAudioEvents: Called with null audio element.');
      return;
    }
    // console.log(`[MediaHelperDebug] simulateAudioEvents: Simulating events for ${audio.src}`);
    const eventsToSimulate = ['play', 'timeupdate', 'ended'];
    eventsToSimulate.forEach(eventName => {
      try {
        // console.log(`[MediaHelperDebug] simulateAudioEvents: Dispatching '${eventName}' for ${audio.src}`);
        const event = new Event(eventName, { bubbles: true, cancelable: false });
        audio.dispatchEvent(event);
      } catch (e) {
        // console.error(`[MediaHelperDebug] simulateAudioEvents: Error dispatching '${eventName}' for ${audio.src}:`, e);
      }
    });
    // console.log(`[MediaHelperDebug] simulateAudioEvents: Finished simulating events for ${audio.src}`);
  }

  function waitForAudioPlayersReady(maxAttempts = 5, delay = 100) {
    return new Promise((resolve, reject) => {
      try {
        const audioElements = document.querySelectorAll('audio, .player_2DX_F');
        let readyCount = 0;
        const totalAudio = audioElements.length;
        if (totalAudio === 0) {
          resolve();
          return;
        }
        let uncommonAudio = null;
        audioElements.forEach(audio => {
          const parentElement = audio.closest('.container_2CZFB, .audio-container') || audio.parentElement;
          if (parentElement && queryShadowSelector('.mh-info.highlight', parentElement)) {
            uncommonAudio = audio;
          }
        });
        const threshold = Math.ceil(totalAudio * 0.8);
        let uncommonAudioReady = uncommonAudio ? false : true;
        let resolved = false;
        const checkReadyThreshold = () => {
          if (resolved) return;
          if (readyCount >= threshold && uncommonAudioReady) {
            audioElements.forEach(simulateAudioEvents);
            resolved = true;
            resolve();
          }
        };
        // Reduced timeouts for faster execution
        const baseTimeout = 500;
        const timePerAudio = 100;
        const maxTimeout = 2000;
        const dynamicTimeout = Math.min(baseTimeout + (totalAudio * timePerAudio), maxTimeout);
        const timeoutId = setTimeout(() => {
          if (resolved) return;
          audioElements.forEach(simulateAudioEvents);
          resolved = true;
          resolve();
        }, dynamicTimeout);
        audioElements.forEach((audio) => {
          const isUncommonAudio = audio === uncommonAudio;
          if (audio.readyState >= 2) {
            readyCount++;
            if (isUncommonAudio) uncommonAudioReady = true;
          } else {
            const onCanPlay = () => {
              if (resolved) return;
              readyCount++;
              if (isUncommonAudio) uncommonAudioReady = true;
              checkReadyThreshold();
              audio.removeEventListener('canplay', onCanPlay);
              audio.removeEventListener('error', onError);
            };
            const onError = (e) => {
              if (resolved) return;
              readyCount++;
              if (isUncommonAudio) {
                uncommonAudioReady = true;
              }
              checkReadyThreshold();
              audio.removeEventListener('canplay', onCanPlay);
              audio.removeEventListener('error', onError);
            };
            audio.addEventListener('canplay', onCanPlay, { once: true });
            audio.addEventListener('error', onError, { once: true });
          }
        });
        checkReadyThreshold();
      } catch (error) {
        reject(error);
      }
    });
  }

  function clickRadioButton(element) {
    if (!element) return;
    stealthClick(element);
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Function to handle click strategy for radio buttons
  function clickByStrategy(radioButtons) {
    if (!radioButtons || radioButtons.length === 0) {
      return false;
    }

    // Check if these are buttons with payload attributes (Arabic evaluation UI)
    // This should be a fallback in case Arabic detection via other means failed
    const payloadButtons = Array.from(document.querySelectorAll('button[payload]'));
    if (payloadButtons.length > 0) {
      // Check for Arabic content again using more basic detection
      const hasArabicText = document.body.innerText.match(/[؀-ۿ]/);
      if (hasArabicText) {
        // As a fallback, use the 'ok' button if available
        let defaultButton = payloadButtons.find(btn => btn.getAttribute('payload') === 'ok');
        if (!defaultButton) defaultButton = payloadButtons[0];

        setTimeout(() => {
          stealthClick(defaultButton);
          // Simulate audio events after clicking
          simulateAllAudioEvents();
        }, 500);

        return true;
      }
    }

    // For standard radio button tasks
    if (radioButtons.length === 2) {
      // This is likely a binary choice task (like yes/no or speech/no speech)
      // We'll prefer the second option (index 1) for 2-button tasks
      const buttonToClick = radioButtons[1];
      clickRadioButton(buttonToClick);
      // Simulate audio events after clicking
      simulateAllAudioEvents();
      return true;
    } else if (radioButtons.length > 2) {
      // For tasks with more than 2 options, we'll select the first one (index 0)
      // This could be refined based on specific task patterns
      const buttonToClick = radioButtons[0];
      clickRadioButton(buttonToClick);
      // Simulate audio events after clicking
      simulateAllAudioEvents();
      return true;
    }

    return false;
  }

  async function clickRedText() {
    // console.log('[MediaHelperDebug] clickRedText: Function started.');
    const redTextElement = queryShadowSelector('.mh-info.highlight');

    if (redTextElement) {
      // console.log('[MediaHelperDebug] clickRedText: Found redTextElement:', redTextElement);

      const parentWrapper = getWrapperForShadowElement(redTextElement);
      let audioElement = null;
      if (parentWrapper) {
        audioElement = parentWrapper.querySelector('audio');
      } else {
        const root = redTextElement.getRootNode();
        const legacyParentContainer = (root instanceof ShadowRoot ? root.host : redTextElement).closest('.container_2CZFB, .audio-container') || redTextElement.parentElement;
        audioElement = legacyParentContainer ? legacyParentContainer.querySelector('.player_2DX_F, audio') : null;
      }
      // console.log('[MediaHelperDebug] clickRedText: Found audioElement:', audioElement, audioElement ? `Src: ${audioElement.src}` : 'No audioElement');

      if (audioElement) {
        // console.log('[MediaHelperDebug] clickRedText: About to await simulateAllAudioEvents, excluding audioElement:', audioElement.src);
        await simulateAllAudioEvents(audioElement); // Wait for other audios to be processed
        // console.log('[MediaHelperDebug] clickRedText: simulateAllAudioEvents finished.');
      } else {
        // console.log('[MediaHelperDebug] clickRedText: No specific audioElement found for exclusion, proceeding to click.');
      }

      try {
        // console.log('[MediaHelperDebug] clickRedText: Scrolling into view.');
        // Scroll the wrapper (visible element) instead of shadow DOM element
        const scrollTarget = parentWrapper || redTextElement;
        scrollTarget.scrollIntoView({ behavior: 'instant', block: 'center' });
      } catch (e) {
        // console.error('[MediaHelperDebug] clickRedText: Error during scrollIntoView:', e);
      }

      // console.log('[MediaHelperDebug] clickRedText: Stealth clicking. Page should handle playback.');
      // Click on the wrapper for shadow DOM elements
      const clickTarget = parentWrapper || redTextElement;
      stealthClick(clickTarget);

    } else {
      // console.log('[MediaHelperDebug] clickRedText: .mh-info.highlight element not found.');
    }
  }

  // Expose clickRedText to the window object so it can be accessed by other scripts
  window._mh.crt = clickRedText;

  // Helper function to simulate events for all audio elements on the page
  function simulateAllAudioEvents(audioToExclude = null) {
    // console.log(`[MediaHelperDebug] simulateAllAudioEvents: Started. audioToExclude: ${audioToExclude ? audioToExclude.src : 'null'}`);
    return new Promise((resolve) => {
      setTimeout(() => {
        const allAudioElements = document.querySelectorAll('audio, .player_2DX_F');
        // console.log(`[MediaHelperDebug] simulateAllAudioEvents: Found ${allAudioElements.length} audio elements on page.`);
        allAudioElements.forEach((audio, index) => {
          // console.log(`[MediaHelperDebug] simulateAllAudioEvents: Processing audio element #${index}, src: ${audio.src}`);
          if (audio === audioToExclude) {
            // console.log(`[MediaHelperDebug] simulateAllAudioEvents: Skipping audio ${audio.src} because it is audioToExclude.`);
            return;
          }
          // console.log(`[MediaHelperDebug] simulateAllAudioEvents: Calling simulateAudioEvents for ${audio.src}`);
          simulateAudioEvents(audio);
        });
        // console.log('[MediaHelperDebug] simulateAllAudioEvents: Finished processing all audio elements.');
        resolve();
      }, 10); // Reduced for faster execution (was 50)
    });
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  function findHighlightElement(maxAttempts = 5, delay = 100) {
    return new Promise((resolve) => {
      let attempts = 0;
      function checkForHighlight() {
        const highlight = queryShadowSelector('.mh-info.highlight');
        if (highlight) {
          resolve(true);
        } else if (++attempts < maxAttempts) {
          setTimeout(checkForHighlight, delay);
        } else {
          resolve(false);
        }
      }
      checkForHighlight();
    });
  }

  async function runGenoAutomation() {
    // Clear any existing timers to prevent multiple instances running
    if (window._mh.gt) {
      clearTimeout(window._mh.gt);
      window._mh.gt = null;
    }

    // Set a flag to track if we're currently processing tasks
    if (window._mh.ipt) {
      return;
    }

    window._mh.ipt = true;

    try {
      // === TEXT MARKING MATCH CHECK ===
      if (detectTextMarkingTask()) {
        checkMatchingTextMarkingTasks();
        window._mh.ipt = false;
        return;
      }

      // Ensure uncommon task answers are loaded first
      await new Promise(resolve => {
        if (!window._mh.uta) {
          loadUncommonTaskAnswers();
          // Wait a bit for loading to complete
          setTimeout(resolve, 20);
        } else {
          resolve();
        }
      });

      const result = await selectOptions();

      if (result.handled) {
        // Short cooldown since batch-clicking finishes instantly
        setTimeout(() => {
          window._mh.ipt = false;
        }, 100);
      } else {
        window._mh.gt = setTimeout(() => {
          window._mh.ipt = false;
          runGenoAutomation();
        }, 150);
      }
    } catch (e) {
      window._mh.ipt = false;
      window._mh.gt = setTimeout(runGenoAutomation, 200);
    }

    // Don't remove the highlights
    // scheduleInjectedElementRemoval();
  }

  // Helper function to process audio classification tasks
  function processAudioClassification() {
    const audioContainer = document.getElementById('audioContainer');
    if (!audioContainer || !audioContainer.querySelector('audio')) return;

    const audioElement = audioContainer.querySelector('audio');
    const options = document.querySelectorAll('input[type="radio"]');

    if (options.length === 0) return;

    // Default to selecting "No Speech" (typically the second option)
    const optionToSelect = options.length >= 2 ? options[1] : options[0];

    // Click the option
    clickRadioButton(optionToSelect);

    // Simulate audio events
    simulateAudioEvents(audioElement);
    simulateAllAudioEvents(audioElement); // Pass the specific audio element to skip

    return true;
  }

  // === TEXT MARKING TASK DETECTION & CAPTURE ===

  // Detect if the current page is a text marking task
  // Checks for the tc-group element with character spans (present even before marking)
  function detectTextMarkingTask() {
    // Primary detection: tc-group with .textContainer and span[data-index] characters
    const tcGroup = document.querySelector('tc-group');
    if (tcGroup) {
      const charSpans = tcGroup.querySelectorAll('span[data-index]');
      if (charSpans.length > 0) {
        console.log('[TM-Match] detectTextMarkingTask: DETECTED via tc-group with', charSpans.length, 'char spans');
        return true;
      }
    }
    // Fallback: already-marked spans (for backward compat)
    const markedSpans = document.querySelectorAll('span.marked.mistake, span.marked.unclear');
    if (markedSpans.length > 0) {
      console.log('[TM-Match] detectTextMarkingTask: DETECTED via marked spans', markedSpans.length);
      return true;
    }
    console.log('[TM-Match] detectTextMarkingTask: NOT a text marking task');
    return false;
  }

  // Check matching tasks against saved text marking answers
  function checkMatchingTextMarkingTasks() {
    const existingDots = document.querySelectorAll('.tm-hint-dot');
    if (existingDots.length > 0) {
      existingDots.forEach(d => d.remove());
      console.log('[TM-Match] Toggled OFF hint dots');
      showToast('Answers hidden.');
      return;
    }

    const taskDivs = document.querySelectorAll('.task, .task_focused, div[data-test-id^="task-"], .tb-task, .lUeJm._2t-aw');
    const containers = taskDivs.length > 0 ? Array.from(taskDivs) : [document.body];
    console.log('[TM-Match] checkMatchingTextMarkingTasks: found', containers.length, 'container(s)', taskDivs.length > 0 ? 'via task selectors' : 'using body as fallback');
    
    chrome.storage.local.get('textMarkingAnswers', (data) => {
      const savedAnswers = data.textMarkingAnswers || [];
      console.log('[TM-Match] savedAnswers count:', savedAnswers.length);
      if (savedAnswers.length === 0) {
        showToast('No saved Text Marking answers to match against.');
        return;
      }
      
      let matchesCount = 0;
      const compSaveAll = !!window._mh.csa;

      containers.forEach((container, index) => {
        // test mode skip logic
        if (!compSaveAll && container !== document.body) {
          let isUncommon = false;
          if (queryShadowSelector('.mh-info.highlight', container)) { 
             isUncommon = true; 
          }
          if (!isUncommon && hasBrokenAudio(container)) { 
             isUncommon = true; 
          }
          if (!isUncommon) {
              console.log(`[TM-Match] Container ${index + 1}: SKIPPED - TEST mode (not an uncommon task)`);
              return;
          }
        }
        
        let fullText = '';
        const fullTextBox = container.querySelector('full-text-box box-conent, full-text-box .box-content');
        if (fullTextBox) fullText = fullTextBox.textContent.trim();
        
        let segmentText = '';
        let charSpansRaw = [];
        const textContainer = container.querySelector('.textContainer, tc-group .textContainer');
        if (textContainer) {
          const charSpans = textContainer.querySelectorAll('span[data-index]');
          charSpansRaw = Array.from(charSpans);
          charSpans.forEach(span => { segmentText += span.textContent; });
        }
        
        const audioEl = container.querySelector('audio');
        const audioUrl = audioEl ? audioEl.src : '';

        console.log(`[TM-Match] Container ${index + 1}:`);
        console.log('  segmentText:', JSON.stringify(segmentText));
        console.log('  normalised:', JSON.stringify(normalizeTextForMatch(segmentText)));
        
        if (!segmentText) {
            console.log(`[TM-Match] Container ${index + 1}: SKIPPED - no segmentText found`);
            return;
        }

        // Match solely on segment text (pure characters, no markup)
        let matchedEntry = null;

        for (const entry of savedAnswers) {
           const eSegmentText = entry.segmentText || '';
           const eNorm = normalizeTextForMatch(eSegmentText);
           const pNorm = normalizeTextForMatch(segmentText);

           console.log(`[TM-Match]   Comparing saved entry segmentText (normalised): "${eNorm}"`);
           console.log(`[TM-Match]   Against page segmentText (normalised):           "${pNorm}"`);
           console.log(`[TM-Match]   Match?`, eNorm === pNorm);

           if (eSegmentText && segmentText && eNorm === pNorm) {
               matchedEntry = entry;
               console.log('[TM-Match] MATCH FOUND! Entry:', entry);
               break;
           }
        }
        
        if (matchedEntry) {
          matchesCount++;
          const tcGroup = container.querySelector('tc-group, .textContainer');
          
          if (matchedEntry.noMistake && (!matchedEntry.markings || matchedEntry.markings.length === 0)) {
            // Show green tick above text container
            if (tcGroup) {
              tcGroup.style.position = 'relative';
              const tick = document.createElement('div');
              tick.className = 'tm-hint-dot';
              tick.textContent = '✔️ لا توجد أخطاء';
              tick.style.cssText = 'position: absolute; top: -30px; right: 0; font-size: 13px; background: rgba(46, 204, 113, 0.95); color: white; padding: 4px 10px; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.3); z-index: 100; pointer-events: none; font-weight: bold; border: 1px solid rgba(255,255,255,0.4);';
              tcGroup.appendChild(tick);
            }
          } else if (matchedEntry.markings) {
            matchedEntry.markings.forEach(m => {
               const textToFind = m.text;
               const color = m.type === 'mistake' ? '#e74c3c' : '#3498db'; // red or blue
               
               let ptr = 0;
               while(true) {
                   const idx = segmentText.indexOf(textToFind, ptr);
                   if (idx === -1) break;
                   // Inject dots above the matching chars
                   for (let i = idx; i < idx + textToFind.length; i++) {
                       if (charSpansRaw[i]) {
                           charSpansRaw[i].style.position = 'relative';
                           const dot = document.createElement('div');
                           dot.className = 'tm-hint-dot';
                           dot.style.cssText = `position: absolute; top: -6px; left: 50%; transform: translateX(-50%); width: 6px; height: 6px; border-radius: 50%; background-color: ${color}; z-index: 100; box-shadow: 0 0 5px ${color}; pointer-events: none; opacity: 0.9;`;
                           charSpansRaw[i].appendChild(dot);
                       }
                   }
                   ptr = idx + textToFind.length;
               }
            });
          }
        } else {
          console.log(`[TM-Match] Container ${index + 1}: no match found among ${savedAnswers.length} saved entries`);
        }
      });
      
      if (matchesCount === 0) {
         console.log('[TM-Match] No matches at all - showing no-match toast');
         showToast('No saved answers matched current tasks.');
      } else {
         const modeLabel = compSaveAll ? 'ALL Mode' : 'TEST Mode';
         showToast(`Applied answers to ${matchesCount} task(s)! (${modeLabel})`, 3000);
      }
    });
  }

  function normalizeTextForMatch(text) {
     if (!text) return '';
     // Strip all spaces, punctuation, and non-word characters for a pure text match
     return text.replace(/[\s\p{P}\p{S}\p{Z}\p{C}]/gu, '').toLowerCase();
  }

  // Extract text marking data from the current page
  function extractTextMarkingData(saveAllMode = true) {
    const results = [];

    // Find all task containers on the page (each .task_focused or similar is one task)
    const taskDivs = document.querySelectorAll('.task, .task_focused, div[data-test-id^="task-"], .tb-task, .lUeJm._2t-aw');
    // If no task wrappers found, treat the whole body as one task
    const containers = taskDivs.length > 0 ? Array.from(taskDivs) : [document.body];

    containers.forEach(container => {
      // Respect Test/All mode logic for saving answers just like normal tasks
      if (!saveAllMode && container !== document.body) {
        let isUncommon = false;
        if (queryShadowSelector('.mh-info.highlight', container)) {
            isUncommon = true; 
        }
        if (!isUncommon && hasBrokenAudio(container)) {
            isUncommon = true;
        }
        if (!isUncommon) return; // Skip this container if not uncommon
      }

      // Get the full text from <full-text-box> or <box-conent>
      let fullText = '';
      const fullTextBox = container.querySelector('full-text-box box-conent, full-text-box .box-content');
      if (fullTextBox) {
        fullText = fullTextBox.textContent.trim();
      }

      // Get the audio URL
      let audioUrl = '';
      const audioEl = container.querySelector('audio');
      if (audioEl && audioEl.src) {
        audioUrl = audioEl.src;
      }

      // Get the highlighted segment container (tc-group .textContainer)
      const textContainer = container.querySelector('.textContainer, tc-group .textContainer');
      if (!textContainer) return;

      // Get ALL character spans
      const charSpans = textContainer.querySelectorAll('span[data-index]');
      if (charSpans.length === 0) return;

      // Reconstruct the full segment text
      let segmentText = '';
      charSpans.forEach(span => {
        segmentText += span.textContent;
      });

      // Extract marked words by grouping consecutive characters with the same marking
      const markings = []; // Array of {text, type} where type is 'mistake' or 'unclear'
      let currentWord = '';
      let currentType = null;

      charSpans.forEach((span, idx) => {
        const isMistake = span.classList.contains('marked') && span.classList.contains('mistake');
        const isUnclear = span.classList.contains('marked') && span.classList.contains('unclear');
        const type = isMistake ? 'mistake' : (isUnclear ? 'unclear' : null);
        const char = span.textContent;

        if (type && type === currentType) {
          // Continue building the current marked word
          currentWord += char;
        } else {
          // Save the previous word if it was marked
          if (currentType && currentWord.trim()) {
            markings.push({ text: currentWord.trim(), type: currentType });
          }
          // Start new tracking
          if (type) {
            currentWord = char;
            currentType = type;
          } else {
            currentWord = '';
            currentType = null;
          }
        }
      });
      // Don't forget the last word
      if (currentType && currentWord.trim()) {
        markings.push({ text: currentWord.trim(), type: currentType });
      }

      // Check if "no mistake" checkbox is checked
      let noMistake = false;
      const noMistakeCheckbox = container.querySelector('input[name="no_mistake"]');
      if (noMistakeCheckbox && noMistakeCheckbox.checked) {
        noMistake = true;
      }

      if (markings.length > 0 || noMistake) {
        results.push({
          fullText: fullText || segmentText,
          segmentText: segmentText,
          audioUrl: audioUrl,
          markings: markings,
          noMistake: noMistake,
          timestamp: new Date().toISOString()
        });
      }
    });

    return results;
  }

  // Save text marking answers to storage
  function saveTextMarkingAnswers(newEntries) {
    chrome.storage.local.get('textMarkingAnswers', (data) => {
      let existing = data.textMarkingAnswers || [];

      // Merge: check for duplicates by audioUrl + segmentText combo
      newEntries.forEach(entry => {
        const existingIdx = existing.findIndex(e =>
          e.audioUrl === entry.audioUrl && e.segmentText === entry.segmentText
        );
        if (existingIdx >= 0) {
          // Update existing entry
          existing[existingIdx] = entry;
        } else {
          existing.push(entry);
        }
      });

      chrome.storage.local.set({ textMarkingAnswers: existing }, () => {
        dlog('TextMarking: saved locally', newEntries.length, 'entries, total:', existing.length);
        // Push newly saved entries to Firebase real-time
        chrome.runtime.sendMessage({ 
            action: 'pushTextMarkingAnswersToCloud', 
            newEntries: existing 
        });
      });
    });
  }

  // Function to capture uncommon task answers
  function captureUncommonTaskAnswers() {
    if (window === window.top) {
      dlog('Capture: skipping main frame');
      return; // Only execute in iframes where tasks are
    }

    // === TEXT MARKING TASK ===
    if (detectTextMarkingTask()) {
      dlog('Capture: detected text marking task');
      const compSaveAll = !!window._mh.csa;
      const markingData = extractTextMarkingData(compSaveAll);
      if (markingData.length > 0) {
        saveTextMarkingAnswers(markingData);
        dlog('Capture: saved', markingData.length, 'text marking entries');
        if (typeof showToast === 'function') {
           showToast(`Saved ${markingData.length} Text Markings! Syncing...`);
        }
      } else {
        dlog('Capture: no marking data found');
        if (typeof showToast === 'function') {
           showToast(`No Text Markings found to save (or task skipped by Test Mode).`);
        }
      }
      return 'text-marking'; // Text marking tasks are handled separately
    }

    const isComparisonPage = detectAudioComparisonTask();
    const hasArabicEvaluation = window._mh.aeh &&
      typeof window._mh.aeh.detectArabicEvaluation === 'function' &&
      window._mh.aeh.detectArabicEvaluation();

    if (!hasArabicEvaluation && !isComparisonPage) {
      dlog('Capture: not an Arabic evaluation or comparison page');
      return;
    }

    // Find all uncommon highlights
    const uncommonHighlights = queryShadowSelectorAll('.mh-info.highlight');
    dlog('Capture: found uncommon highlights:', uncommonHighlights.length);

    // Also find all tasks with broken audio (expired files)
    const allTaskContainers = Array.from(document.querySelectorAll('.tb-task, .lUeJm._2t-aw, .container_2CZFB, form.form_Azrlg'));
    const brokenAudioTasks = allTaskContainers.filter(container => hasBrokenAudio(container));
    dlog('Capture: found broken audio tasks:', brokenAudioTasks.length);

    const compSaveAll = isComparisonPage && !!window._mh.csa;

    if (uncommonHighlights.length === 0 && brokenAudioTasks.length === 0 && !compSaveAll) {
      dlog('Capture: no uncommon highlights or broken audio found');
      return;
    }

    let capturedCount = 0;
    let pendingCount = 0;

    // --- Comparison task capture (تعادل) ---
    if (isComparisonPage) {
      const processedCompKeys = new Set();

      const captureTasks = Array.from(document.querySelectorAll('div[data-test-id^="task-"]'));
      if (captureTasks.length === 0) {
        const fallback = Array.from(document.querySelectorAll('.tb-task, .lUeJm._2t-aw'));
        captureTasks.push(...fallback.filter(t => !fallback.some(o => o !== t && o.contains(t))));
      }

      captureTasks.forEach(task => {
        if (!compSaveAll) {
          let isUncommon = false;
          const audioEls = task.querySelectorAll('audio');
          for (const audio of audioEls) {
            const w = audio.closest('.mh-wrapper');
            if (w && queryShadowSelector('.mh-info.highlight', w)) { isUncommon = true; break; }
          }
          if (!isUncommon) isUncommon = hasBrokenAudio(task);
          if (!isUncommon) return;
        }

        const compKey = getComparisonKey(task);
        if (!compKey || processedCompKeys.has(compKey)) return;
        processedCompKeys.add(compKey);

        const selectedAnswer = getSelectedComparisonAnswer(task);
        if (!selectedAnswer) {
          dlog('Capture: comparison task has no selected radio');
          pendingCount++;
          return;
        }

        const taskText = getComparisonTaskText(task);
        saveOrUpdateEntry(compKey, taskText, selectedAnswer);
        dlog('Capture: SAVED comparison -', selectedAnswer, 'text:', taskText.substring(0, 30));
        capturedCount++;
      });

      if (capturedCount > 0) {
        saveUncommonTaskAnswers();
        dlog('Capture: saved', capturedCount, 'comparison entries (mode:', compSaveAll ? 'ALL' : 'TEST', ')');
      } else if (pendingCount > 0) {
        dlog('Capture: comparison pending:', pendingCount);
      }
      return;
    }

    // --- Standard Arabic evaluation capture ---

    // Helper function to process a task container and capture its answer
    function processTaskContainer(taskContainer, audioElement) {
      if (!taskContainer || !audioElement) return;

      const audioUrl = audioElement.src;
      if (!audioUrl) {
        dlog('Capture: no audio URL found');
        return;
      }
      dlog('Capture: processing audio URL:', audioUrl.substring(audioUrl.length - 50));

      const selectedButton = taskContainer.querySelector([
        'button[payload].selected',
        'button[payload][data-selected="true"]',
        'button[payload].Button2_checked',
        'button[payload][aria-pressed="true"]'
      ].join(', '));

      if (!selectedButton) {
        const allButtons = taskContainer.querySelectorAll('button[payload]');
        dlog('Capture: no selected button found. Available buttons:', allButtons.length);
        allButtons.forEach((btn, idx) => {
          dlog(`Capture: button ${idx} classes:`, btn.className, 'aria-pressed:', btn.getAttribute('aria-pressed'));
        });

        pendingCount++;
        return;
      }

      const answer = selectedButton.getAttribute('payload');
      dlog('Capture: found selected answer:', answer);

      let taskText = '';
      if (window._mh.aeh && typeof window._mh.aeh.getTaskText === 'function') {
        taskText = window._mh.aeh.getTaskText(taskContainer);
        dlog('Capture: using arabicEvaluationHandler.getTaskText');
      } else {
        const rtlContainers = taskContainer.querySelectorAll('div[dir="rtl"]');
        rtlContainers.forEach(container => {
          const t = container.textContent || '';
          if (!t.includes('قيِّم النطق') && !t.includes('تقييم') && !t.includes('نطق')) {
            if (!container.querySelector('button')) {
              taskText += t.trim() + ' ';
            }
          }
        });

        if (!taskText.trim()) {
          const containers = taskContainer.querySelectorAll('.container_3rKiN');
          containers.forEach(c => taskText += c.textContent.trim() + ' ');
        }

        taskText = taskText.trim();
        dlog('Capture: using fallback text extraction');
      }

      saveOrUpdateEntry(audioUrl, taskText, answer);
      dlog('Capture: SAVED entry - URL:', audioUrl.substring(audioUrl.length - 40), 'answer:', answer, 'text:', taskText.substring(0, 30));
      capturedCount++;
    }

    // Set to track processed audio URLs to avoid duplicates
    const processedUrls = new Set();

    // Process each uncommon highlight
    uncommonHighlights.forEach(highlight => {
      const wrapper = getWrapperForShadowElement(highlight);
      if (!wrapper) {
        dlog('Capture: no wrapper found for highlight');
        return;
      }

      const audio = wrapper.querySelector('audio');
      if (!audio || !audio.src) {
        dlog('Capture: no audio found in wrapper');
        return;
      }

      if (processedUrls.has(audio.src)) return;
      processedUrls.add(audio.src);

      const taskContainer = audio.closest('.tb-task, .lUeJm._2t-aw, .container_2CZFB, form.form_Azrlg');
      if (!taskContainer) {
        dlog('Capture: no task container found for audio');
        return;
      }

      processTaskContainer(taskContainer, audio);
    });

    // Process each broken audio task
    brokenAudioTasks.forEach(taskContainer => {
      const audio = taskContainer.querySelector('audio');
      if (!audio || !audio.src) {
        dlog('Capture: broken audio task has no audio element');
        return;
      }

      if (processedUrls.has(audio.src)) return;
      processedUrls.add(audio.src);

      processTaskContainer(taskContainer, audio);
    });

    if (capturedCount > 0) {
      saveUncommonTaskAnswers();
      dlog('Capture: saved', capturedCount, 'entries to storage');

      let totalEntries = 0;
      for (const [url, entries] of uncommonTaskAnswers) {
        totalEntries += Array.isArray(entries) ? entries.length : 1;
      }
      dlog('Capture: total entries now:', totalEntries);
    } else if (pendingCount > 0) {
      dlog('Capture: no entries captured, pending:', pendingCount);
    } else {
      dlog('Capture: nothing to save');
    }
  }

  // Function to clear all saved uncommon task answers
  function clearUncommonTaskAnswers() {
    // Clear in-memory map
    uncommonTaskAnswers.clear();
    window._mh.uta = new Map();

    // Clear in storage
    chrome.storage.local.remove('uncommonTaskAnswers', () => {
    });
  }

  // Track last shortcut activation time to prevent duplicates
  let lastShortcutTime = 0;

  // Add keyboard shortcut listener for Ctrl+M and Ctrl+Shift+M as a fallback
  document.addEventListener('keydown', (event) => {
    const now = Date.now();
    // Prevent duplicate activations within 500ms
    if (now - lastShortcutTime < 500) {
      return;
    }

    if (event.ctrlKey && event.key === 'm') {
      lastShortcutTime = now;

      // Stop propagation to prevent default browser behavior
      event.preventDefault();
      event.stopPropagation();

      if (event.shiftKey) {
        // Ctrl+Shift+M to clear all saved answers
        clearUncommonTaskAnswers();
      } else {
        // Ctrl+M to capture answers
        captureUncommonTaskAnswers();
      }
    }
  });

  // === TOUCH CONTROL PANEL FOR MOBILE NAVIGATION ===
  // Functions moved to main scope for manual injection control

  // Track current focused task for navigation
  let currentTaskIndex = 0;
  let isExpanded = false;

  // Get all task containers
  function getTaskContainers() {
    // Priority 1: Use data-test-id if available (most reliable)
    let tasks = Array.from(document.querySelectorAll('div[data-test-id^="task-"]'));

    if (tasks.length === 0) {
      // Priority 2: Use specific class combination
      tasks = Array.from(document.querySelectorAll('div.lUeJm.tb-task'));
    }

    if (tasks.length === 0) {
      // Fallback: broader selectors but filter carefully
      tasks = Array.from(document.querySelectorAll('.tb-task, .task, .lUeJm')).filter(task => {
        // Must contain a form or specific task indicators
        return task.querySelector('form') || task.querySelector('.audio-container') || task.querySelector('audio');
      });
    }

    // Sort by position in DOM to ensure correct order
    tasks.sort((a, b) => {
      return (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1;
    });

    // Filter out nested tasks
    return tasks.filter(task => {
      const isNested = tasks.some(
        otherTask => otherTask !== task && otherTask.contains(task)
      );
      return !isNested;
    });
  }

  // Sync currentTaskIndex based on which task is currently visible/focused
  function syncCurrentTaskIndex() {
    const tasks = getTaskContainers();
    if (tasks.length === 0) return;

    // Find the task closest to the center of the viewport
    const center = window.innerHeight / 2;
    let closestDist = Infinity;
    let closestIdx = 0;

    tasks.forEach((task, idx) => {
      const rect = task.getBoundingClientRect();
      const taskCenter = rect.top + rect.height / 2;
      const dist = Math.abs(taskCenter - center);
      if (dist < closestDist) {
        closestDist = dist;
        closestIdx = idx;
      }
    });

    currentTaskIndex = closestIdx;
    updateTaskCounter();
  }

  // Stop all audio on the page
  function stopAllAudio() {
    const allAudio = document.querySelectorAll('audio');
    allAudio.forEach(audio => {
      if (!audio.paused) {
        audio.pause();
        audio.currentTime = 0;
      }
    });
  }

  // Play audio in a specific task
  function playTaskAudio(task) {
    if (!task) return;
    const audio = task.querySelector('audio');
    if (audio) {
      audio.currentTime = 0;
      audio.play().catch(() => { });
    }
  }

  // Navigate to prev/next task with auto-play
  function navigateTask(direction) {
    const tasks = getTaskContainers();
    if (tasks.length === 0) return;

    // ALWAYS sync first before navigating
    syncCurrentTaskIndex();

    // Stop current audio before moving
    stopAllAudio();

    // Calculate new index
    let newIndex = currentTaskIndex + direction;
    currentTaskIndex = Math.max(0, Math.min(tasks.length - 1, newIndex));

    const targetTask = tasks[currentTaskIndex];

    if (targetTask) {
      // Scroll to task
      targetTask.scrollIntoView({ behavior: 'instant', block: 'center' });

      // Remove old outlines
      tasks.forEach(t => {
        t.style.outline = '';
        t.style.boxShadow = '';
      });

      // Add visual indicator
      targetTask.style.outline = '3px solid #f093fb';
      targetTask.style.boxShadow = '0 0 15px rgba(240, 147, 251, 0.5)';

      // Focus first input/button
      const focusable = targetTask.querySelector('input, button[payload]');
      if (focusable) focusable.focus();

      // Auto-play audio in new task
      setTimeout(() => playTaskAudio(targetTask), 100);

      // Remove highlight after delay
      setTimeout(() => {
        targetTask.style.outline = '';
        targetTask.style.boxShadow = '';
      }, 2000);
    }

    updateTaskCounter();
  }

  // Go to first task
  function goToFirstTask() {
    const tasks = getTaskContainers();
    if (tasks.length === 0) return;

    stopAllAudio();
    currentTaskIndex = 0;

    const targetTask = tasks[0];
    if (targetTask) {
      targetTask.scrollIntoView({ behavior: 'instant', block: 'center' });

      tasks.forEach(t => {
        t.style.outline = '';
        t.style.boxShadow = '';
      });

      targetTask.style.outline = '3px solid #f093fb';
      targetTask.style.boxShadow = '0 0 15px rgba(240, 147, 251, 0.5)';

      setTimeout(() => playTaskAudio(targetTask), 100);

      setTimeout(() => {
        targetTask.style.outline = '';
        targetTask.style.boxShadow = '';
      }, 2000);
    }

    updateTaskCounter();
  }

  // Select nth radio button in current task (0-indexed)
  function selectRadioOption(optionIndex) {
    // Sync first
    syncCurrentTaskIndex();

    const tasks = getTaskContainers();
    const currentTask = tasks[currentTaskIndex];
    if (!currentTask) return;

    // Priority: Check for button[payload] (Arabic evaluation style)
    const payloadButtons = Array.from(currentTask.querySelectorAll('button[payload]'));
    if (payloadButtons.length > 0) {
      let targetBtn = null;
      if (optionIndex === 0) targetBtn = payloadButtons.find(b => b.getAttribute('payload') === 'ok') || payloadButtons[0];
      else if (optionIndex === 1) targetBtn = payloadButtons.find(b => b.getAttribute('payload') === 'mistake') || payloadButtons[1];
      else if (optionIndex === 2) targetBtn = payloadButtons.find(b => b.getAttribute('payload') === 'unclear') || payloadButtons[2];
      else targetBtn = payloadButtons[optionIndex];

      if (targetBtn) {
        stealthClick(targetBtn);
        targetBtn.click();

        targetBtn.style.transform = 'scale(0.95)';
        setTimeout(() => targetBtn.style.transform = '', 150);
        return;
      }
    }

    // Fallback: Standard radio buttons
    const radios = currentTask.querySelectorAll('input[type="radio"]');
    if (radios[optionIndex]) {
      clickRadioButton(radios[optionIndex]);

      const label = radios[optionIndex].closest('label') || radios[optionIndex].parentElement;
      if (label) {
        label.style.backgroundColor = 'rgba(76, 175, 80, 0.3)';
        setTimeout(() => { label.style.backgroundColor = ''; }, 300);
      }
    }
  }

  // Toggle audio playback in current task
  function toggleAudioPlayback() {
    // Sync first
    syncCurrentTaskIndex();

    const tasks = getTaskContainers();
    const currentTask = tasks[currentTaskIndex] || document.body;

    let audio = currentTask.querySelector('audio');
    if (!audio) {
      audio = document.querySelector('audio');
    }

    if (audio) {
      if (audio.paused) {
        audio.play().catch(() => { });
      } else {
        audio.pause();
      }
    }
  }

  // Quick run - only removes saved answer indicators and recalculates uncommon dates
  // Much faster than fullRefreshAndRun because it doesn't re-fetch audio headers
  function quickRunAutomation() {
    // 1. Remove only the green saved answer indicators (.mh-s-a)
    // These need to be removed so new automation can re-apply correct ones
    const savedIndicators = queryShadowSelectorAll('.mh-s-a');
    savedIndicators.forEach(indicator => {
      try {
        indicator.remove();
      } catch (_) { }
    });

    // 2. Remove any mismatch badges from previous runs
    document.querySelectorAll('.mh-mismatch-badge').forEach(badge => {
      try {
        badge.remove();
      } catch (_) { }
    });

    // 3. Reset processed tasks so they can be processed again
    if (window._mh.aeh && typeof window._mh.aeh.resetProcessedTasks === 'function') {
      window._mh.aeh.resetProcessedTasks();
    }

    // 4. Recalculate which dates are uncommon based on ONLY visible dates on page
    // This compares only the dates currently shown, not all dates in audioInfo
    recalculateVisibleDates();

    // 5. Run automation immediately - no waiting for header refetch
    runGenoAutomation();
  }

  // Full refresh and run automation (like clicking extension icon)
  // This is slower because it clears all audio info and re-fetches headers
  function fullRefreshAndRun() {
    // Clear audio info and refresh
    audioInfo.clear();
    updateAudioPlayers(true, true);

    // Reset processed tasks
    if (window._mh.aeh && typeof window._mh.aeh.resetProcessedTasks === 'function') {
      window._mh.aeh.resetProcessedTasks();
    }

    // Trigger full reset in background (clears storage date map)
    chrome.runtime.sendMessage({ action: 'triggerFullReset' }, (response) => {
      // After reset is done, wait a bit and run
      setTimeout(() => {
        chrome.runtime.sendMessage({ action: 'getAudioInfo' }, (response) => {
          if (response && response.audioInfo) {
            audioInfo = new Map(response.audioInfo);
            updateAudioPlayers(true, true);
          }
          runGenoAutomation();
        });
      }, 30);
    });
  }

  // Update task counter display
  function updateTaskCounter() {
    const tasks = getTaskContainers();
    const counter = document.querySelector('.mh-touch-controls')?.shadowRoot?.querySelector('.task-counter');
    if (counter) {
      counter.textContent = `${currentTaskIndex + 1}/${tasks.length}`;
    }
  }

  // Create the touch control panel
  function createTouchPanel() {
    const container = document.createElement('div');
    container.className = 'mh-touch-controls';

    const shadow = container.attachShadow({ mode: 'open' });

    // Inject styles - Redesigned for bigger, better arranged buttons
    const style = document.createElement('style');
    style.textContent = `
    :host {
      position: fixed;
      bottom: 15px;
      right: 15px;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      pointer-events: none;
    }
    
    .toggle-btn {
      width: 54px;
      height: 54px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(102, 126, 234, 0.7), rgba(118, 75, 162, 0.7));
      border: 2px solid rgba(255,255,255,0.4);
      color: white;
      font-size: 24px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.2s;
      -webkit-tap-highlight-color: transparent;
      backdrop-filter: blur(8px);
      pointer-events: auto;
      margin-left: auto;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    }
    
    .toggle-btn:active {
      transform: scale(0.92);
      background: linear-gradient(135deg, rgba(102, 126, 234, 0.9), rgba(118, 75, 162, 0.9));
    }
    
    .toggle-btn.expanded {
      background: linear-gradient(135deg, rgba(240, 147, 251, 0.7), rgba(245, 87, 108, 0.7));
      transform: rotate(45deg);
    }
    
    .panel {
      position: absolute;
      bottom: 65px;
      right: 0;
      display: none;
      flex-direction: column;
      gap: 10px;
      align-items: center;
      pointer-events: none;
      padding: 8px;
    }
    
    .panel.visible {
      display: flex;
      animation: slideUp 0.25s ease-out;
    }
    
    @keyframes slideUp {
      from { opacity: 0; transform: translateY(15px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .row {
      display: flex;
      gap: 8px;
      pointer-events: auto;
      justify-content: center;
    }
    
    .task-counter {
      color: white;
      font-size: 13px;
      font-weight: bold;
      text-align: center;
      background: rgba(0, 0, 0, 0.6);
      padding: 4px 12px;
      border-radius: 12px;
      pointer-events: auto;
      backdrop-filter: blur(8px);
      border: 1px solid rgba(255,255,255,0.2);
      min-width: 50px;
    }
    
    .btn {
      width: 52px;
      height: 52px;
      border-radius: 14px;
      border: 2px solid rgba(255,255,255,0.3);
      color: white;
      font-size: 20px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.15s;
      -webkit-tap-highlight-color: transparent;
      backdrop-filter: blur(8px);
      opacity: 0.75;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }
    
    .btn:active {
      transform: scale(0.92);
      opacity: 1;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    
    /* Navigation buttons - teal */
    .btn-nav { 
      background: linear-gradient(135deg, rgba(17, 153, 142, 0.7), rgba(56, 239, 125, 0.6));
    }
    
    /* Number buttons - blue */
    .btn-num { 
      background: linear-gradient(135deg, rgba(71, 118, 230, 0.7), rgba(142, 84, 233, 0.6));
    }
    
    /* Audio button - pink/purple */
    .btn-audio { 
      background: linear-gradient(135deg, rgba(240, 147, 251, 0.7), rgba(245, 87, 108, 0.6));
      font-size: 18px;
    }
    
    /* Run/Automation button - orange */
    .btn-run { 
      background: linear-gradient(135deg, rgba(242, 153, 74, 0.7), rgba(255, 107, 107, 0.6));
      font-size: 22px;
    }
    
    /* First task button - green */
    .btn-first {
      background: linear-gradient(135deg, rgba(46, 204, 113, 0.7), rgba(39, 174, 96, 0.6));
      font-size: 16px;
    }
    
    /* Save button - blue */
    .btn-save { 
      background: linear-gradient(135deg, rgba(52, 152, 219, 0.7), rgba(41, 128, 185, 0.6));
      font-size: 18px;
    }
    
    .btn-save.saving {
      animation: pulse 0.3s ease;
    }
    
    @keyframes pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.15); }
    }
    
    /* Comparison mode toggle */
    .btn-mode {
      font-size: 12px;
      font-weight: 800;
      letter-spacing: 0.5px;
    }
    .btn-mode.mode-all {
      background: linear-gradient(135deg, rgba(242, 153, 74, 0.8), rgba(243, 156, 18, 0.7));
    }
    .btn-mode.mode-test {
      background: linear-gradient(135deg, rgba(17, 153, 142, 0.7), rgba(56, 239, 125, 0.6));
    }
    
    /* Text classification modal styles */
    .text-classify-modal {
      position: fixed;
      z-index: 999998;
      display: none;
      flex-direction: column;
      gap: 6px;
      padding: 8px;
      background: rgba(30, 30, 30, 0.95);
      border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.2);
      backdrop-filter: blur(10px);
      box-shadow: 0 4px 20px rgba(0,0,0,0.4);
      pointer-events: auto;
    }
    
    .text-classify-modal.visible {
      display: flex;
      animation: fadeIn 0.15s ease-out;
    }
    
    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.9); }
      to { opacity: 1; transform: scale(1); }
    }
    
    .text-classify-modal .selected-text {
      color: rgba(255,255,255,0.8);
      font-size: 11px;
      max-width: 180px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      padding: 4px 8px;
      background: rgba(255,255,255,0.1);
      border-radius: 6px;
      direction: rtl;
    }
    
    .text-classify-modal .classify-btns {
      display: flex;
      gap: 6px;
    }
    
    .text-classify-modal .classify-btn {
      flex: 1;
      padding: 8px 10px;
      border: none;
      border-radius: 8px;
      color: white;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.15s;
      -webkit-tap-highlight-color: transparent;
    }
    
    .text-classify-modal .classify-btn:active {
      transform: scale(0.95);
    }
    
    .classify-btn.ok { background: linear-gradient(135deg, rgba(46, 204, 113, 0.9), rgba(39, 174, 96, 0.9)); }
    .classify-btn.mistake { background: linear-gradient(135deg, rgba(231, 76, 60, 0.9), rgba(192, 57, 43, 0.9)); }
    .classify-btn.unclear { background: linear-gradient(135deg, rgba(241, 196, 15, 0.9), rgba(243, 156, 18, 0.9)); }
    
    /* Wide button for bottom row */
    .btn-wide {
      width: 116px;
      border-radius: 14px;
    }
  `;
    shadow.appendChild(style);

    // Create panel structure - Redesigned layout
    const panel = document.createElement('div');
    panel.className = 'panel';
    panel.innerHTML = `
    <div class="task-counter">0/0</div>
    
    <!-- Number buttons row -->
    <div class="row">
      <button class="btn btn-num" data-action="opt1" tabindex="-1">1</button>
      <button class="btn btn-num" data-action="opt2" tabindex="-1">2</button>
      <button class="btn btn-num" data-action="opt3" tabindex="-1">3</button>
    </div>
    
    <!-- Navigation row: Up, First, Down -->
    <div class="row">
      <button class="btn btn-nav" data-action="up" title="Previous Task" tabindex="-1">▲</button>
      <button class="btn btn-first" data-action="first" title="Go to First" tabindex="-1">⏮</button>
      <button class="btn btn-nav" data-action="down" title="Next Task" tabindex="-1">▼</button>
    </div>
    
    <!-- Audio and Run row -->
    <div class="row">
      <button class="btn btn-audio btn-wide" data-action="audio" title="Play/Pause" tabindex="-1">▶ Play</button>
      <button class="btn btn-run" data-action="run" title="Quick Run (keeps dates)" tabindex="-1">⚡</button>
    </div>
    
    <!-- Save + Mode row -->
    <div class="row">
      <button class="btn btn-save btn-wide" data-action="save" title="Click to Save Answers" tabindex="-1">💾 Save</button>
      <button class="btn btn-mode mode-test" data-action="toggleMode" title="Toggle: save ALL tasks or only uncommon" tabindex="-1">TEST</button>
    </div>
  `;

    // Toggle button
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'toggle-btn';
    toggleBtn.innerHTML = '☰';
    toggleBtn.title = 'Touch Controls';
    toggleBtn.tabIndex = -1; // Prevent tab focus from landing here by default

    // Handle toggle
    toggleBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      isExpanded = !isExpanded;
      panel.classList.toggle('visible', isExpanded);
      toggleBtn.classList.toggle('expanded', isExpanded);
      toggleBtn.innerHTML = isExpanded ? '✕' : '☰';
      if (isExpanded) {
        syncCurrentTaskIndex();
      }
    });

    // Handle panel button clicks
    panel.addEventListener('click', (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;

      e.preventDefault();
      e.stopPropagation();

      // Blur immediately to release focus back to document body or where page wants it
      // This helps reduce "focus fighting" with the page's own focus management
      btn.blur();

      const action = btn.dataset.action;

      switch (action) {
        case 'up':
          navigateTask(-1);
          break;
        case 'down':
          navigateTask(1);
          break;
        case 'first':
          goToFirstTask();
          break;
        case 'opt1':
          selectRadioOption(0);
          break;
        case 'opt2':
          selectRadioOption(1);
          break;
        case 'opt3':
          selectRadioOption(2);
          break;
        case 'audio':
          toggleAudioPlayback();
          // Update button text
          syncCurrentTaskIndex();
          const tasks = getTaskContainers();
          const currentTask = tasks[currentTaskIndex] || document.body;
          let audio = currentTask.querySelector('audio') || document.querySelector('audio');
          if (audio) {
            btn.innerHTML = audio.paused ? '▶ Play' : '⏸ Pause';
          }
          break;
        case 'run':
          if (detectTextMarkingTask()) {
             const existingDots = document.querySelectorAll('.tm-hint-dot');
             if (existingDots.length > 0) {
               existingDots.forEach(d => d.remove());
               showToast('Answers hidden.');
               return;
             }
             
             btn.classList.add('saving'); // reuse saving feedback
             btn.innerHTML = '⚡';
             
             // Fetch instantly from cloud
             chrome.runtime.sendMessage({ action: 'pullTextMarkingAnswersFromCloud' }, (res) => {
                btn.classList.remove('saving');
                btn.innerHTML = '⚡';
                if (res && res.success) {
                   showToast('Cloud data synced! Checking answers...');
                } else {
                   showToast('Checking with local answers... ' + (res ? res.error || '' : ''));
                }
                checkMatchingTextMarkingTasks();
             });
             break;
          }
          // Quick run - fast, uses existing dates, only clears saved answer indicators
          quickRunAutomation();
          break;
        case 'save':
          btn.classList.add('saving');
          const saveType = captureUncommonTaskAnswers();
          if (saveType === 'text-marking') {
            // Toast is handled inside captureUncommonTaskAnswers for text marking tasks
            setTimeout(() => btn.classList.remove('saving'), 300);
          } else {
            let totalEntries = 0;
            if (uncommonTaskAnswers) {
              for (const [url, entries] of uncommonTaskAnswers) {
                totalEntries += Array.isArray(entries) ? entries.length : 1;
              }
            }
            const modeLabel = window._mh.csa ? 'ALL' : 'TEST';
            showToast(`Saved! (${totalEntries} entries, mode: ${modeLabel})`);
            setTimeout(() => btn.classList.remove('saving'), 300);
          }
          break;
        case 'toggleMode':
          window._mh.csa = !window._mh.csa;
          chrome.storage.local.set({ comparisonSaveAll: window._mh.csa });
          btn.textContent = window._mh.csa ? 'ALL' : 'TEST';
          btn.classList.toggle('mode-all', window._mh.csa);
          btn.classList.toggle('mode-test', !window._mh.csa);
          showToast(window._mh.csa ? 'Mode: Save & apply ALL tasks' : 'Mode: Uncommon tasks only');
          break;
      }
    });

    // Sync mode toggle button state with stored setting
    const modeBtn = panel.querySelector('[data-action="toggleMode"]');
    if (modeBtn) {
      chrome.storage.local.get('comparisonSaveAll', (data) => {
        const isAll = !!(data && data.comparisonSaveAll);
        modeBtn.textContent = isAll ? 'ALL' : 'TEST';
        modeBtn.classList.toggle('mode-all', isAll);
        modeBtn.classList.toggle('mode-test', !isAll);
      });
    }

    shadow.appendChild(panel);
    shadow.appendChild(toggleBtn);

    return container;
  }

  // Panel Injection Logic - Triggered Manually
  function injectPanel() {
    // Skip injection if the page contains "Write down words from the recording:" text
    if (document.body && document.body.textContent.includes('Write down words from the recording:')) {
      return;
    }

    // Only inject in iframes (or if tasks are present), skip main frame unless tasks are there
    if (window === window.top && !document.querySelector('.tb-task')) {
      return;
    }

    // Prevent duplicate injection
    if (document.querySelector('.mh-touch-controls')) {
      // If already exists, sync and update counter
      syncCurrentTaskIndex();
      return;
    }

    const panel = createTouchPanel();
    document.body.appendChild(panel);

    // Initial sync after a short delay
    setTimeout(syncCurrentTaskIndex, 500);

    // Also inject text selection modal
    injectTextSelectionModal();
  }

  // Toast notification helper
  function showToast(message, duration = 2000) {
    // Remove existing toast
    const existing = document.querySelector('.mh-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'mh-toast';
    toast.textContent = message;
    toast.style.cssText = `
      position: fixed;
      bottom: 80px;
      right: 15px;
      background: rgba(0,0,0,0.85);
      color: white;
      padding: 10px 18px;
      border-radius: 8px;
      font-size: 13px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      z-index: 999999;
      pointer-events: none;
      animation: toastFade 0.3s ease forwards;
      backdrop-filter: blur(8px);
      white-space: pre-line;
      line-height: 1.4;
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = 'toastFadeOut 0.3s ease forwards';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  // Add universal keyframes for toast at script init if not present
  if (!document.getElementById('mh-toast-styles')) {
    const styleEl = document.createElement('style');
    styleEl.id = 'mh-toast-styles';
    styleEl.textContent = `
      @keyframes toastFade {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
      }
      @keyframes toastFadeOut {
        from { opacity: 1; transform: translateY(0); }
        to { opacity: 0; transform: translateY(10px); }
      }
    `;
    document.head.appendChild(styleEl);
  }

  // Text selection modal for Android (no context menu workaround)
  let textSelectionModal = null;
  let lastSelectedText = '';
  let selectionDebounceTimer = null;

  function injectTextSelectionModal() {
    if (textSelectionModal) return;

    // Create modal container
    textSelectionModal = document.createElement('div');
    textSelectionModal.className = 'mh-text-classify-modal';
    textSelectionModal.style.cssText = `
      position: fixed;
      z-index: 999998;
      display: none;
      flex-direction: column;
      gap: 6px;
      padding: 8px;
      background: rgba(30, 30, 30, 0.95);
      border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.2);
      backdrop-filter: blur(10px);
      box-shadow: 0 4px 20px rgba(0,0,0,0.4);
      pointer-events: auto;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;

    textSelectionModal.innerHTML = `
      <div class="selected-text-preview" style="
        color: rgba(255,255,255,0.8);
        font-size: 11px;
        max-width: 200px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        padding: 4px 8px;
        background: rgba(255,255,255,0.1);
        border-radius: 6px;
        direction: rtl;
        text-align: right;
      "></div>
      <div class="classify-btns" style="display: flex; gap: 6px;">
        <button class="classify-btn" data-classification="ok" style="
          flex: 1;
          padding: 8px 10px;
          border: none;
          border-radius: 8px;
          color: white;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          -webkit-tap-highlight-color: transparent;
          background: linear-gradient(135deg, rgba(46, 204, 113, 0.9), rgba(39, 174, 96, 0.9));
        ">OK</button>
        <button class="classify-btn" data-classification="mistake" style="
          flex: 1;
          padding: 8px 10px;
          border: none;
          border-radius: 8px;
          color: white;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          -webkit-tap-highlight-color: transparent;
          background: linear-gradient(135deg, rgba(231, 76, 60, 0.9), rgba(192, 57, 43, 0.9));
        ">خطأ</button>
        <button class="classify-btn" data-classification="unclear" style="
          flex: 1;
          padding: 8px 10px;
          border: none;
          border-radius: 8px;
          color: white;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          -webkit-tap-highlight-color: transparent;
          background: linear-gradient(135deg, rgba(241, 196, 15, 0.9), rgba(243, 156, 18, 0.9));
        ">؟</button>
      </div>
    `;

    // Handle classification button clicks
    textSelectionModal.addEventListener('click', (e) => {
      const btn = e.target.closest('.classify-btn');
      if (!btn || !lastSelectedText) return;

      e.preventDefault();
      e.stopPropagation();

      const classification = btn.dataset.classification;

      // Send to background script to save
      chrome.runtime.sendMessage({
        action: 'classifySelectedText',
        text: lastSelectedText,
        classification: classification
      }, (response) => {
        if (response && response.success) {
          showToast(`Added: ${lastSelectedText.substring(0, 20)}... → ${classification}`);
        }
      });

      hideTextSelectionModal();
    });

    document.body.appendChild(textSelectionModal);

    // Listen for text selection changes
    document.addEventListener('selectionchange', () => {
      if (selectionDebounceTimer) {
        clearTimeout(selectionDebounceTimer);
      }

      selectionDebounceTimer = setTimeout(() => {
        const selection = window.getSelection();
        const selectedText = selection ? selection.toString().trim() : '';

        // Only show on Arabic evaluation task pages (uses existing detection)
        const isArabicEvalPage = window._mh.aeh &&
          typeof window._mh.aeh.detectArabicEvaluation === 'function' &&
          window._mh.aeh.detectArabicEvaluation();

        if (selectedText.length > 1 && selectedText.length < 100 && isArabicEvalPage) {
          lastSelectedText = selectedText;
          showTextSelectionModal(selection);
        } else {
          hideTextSelectionModal();
        }
      }, 400); // Debounce 400ms
    });

    // Hide modal when clicking elsewhere
    document.addEventListener('pointerdown', (e) => {
      if (textSelectionModal && !textSelectionModal.contains(e.target)) {
        // Small delay to allow selection to complete
        setTimeout(() => {
          const selection = window.getSelection();
          if (!selection || selection.isCollapsed) {
            hideTextSelectionModal();
          }
        }, 100);
      }
    });
  }

  function showTextSelectionModal(selection) {
    if (!textSelectionModal || !selection) return;

    try {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();

      // Update preview text
      const preview = textSelectionModal.querySelector('.selected-text-preview');
      if (preview) {
        preview.textContent = lastSelectedText.length > 30
          ? lastSelectedText.substring(0, 30) + '...'
          : lastSelectedText;
      }

      // Position modal above selection
      const modalWidth = 220;
      const modalHeight = 80;

      let left = rect.left + (rect.width / 2) - (modalWidth / 2);
      let top = rect.top - modalHeight - 10;

      // Keep within viewport
      left = Math.max(10, Math.min(left, window.innerWidth - modalWidth - 10));
      if (top < 10) {
        top = rect.bottom + 10; // Show below if no room above
      }

      textSelectionModal.style.left = left + 'px';
      textSelectionModal.style.top = top + 'px';
      textSelectionModal.style.display = 'flex';
    } catch (e) {
      // Selection may not have a valid range
    }
  }

  function hideTextSelectionModal() {
    if (textSelectionModal) {
      textSelectionModal.style.display = 'none';
    }
    lastSelectedText = '';
  }

})();
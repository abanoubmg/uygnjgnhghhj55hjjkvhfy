// === Arabic Evaluation Functionality ===
// This module handles Arabic pronunciation evaluation tasks

(function () {
  // Namespace all shared state under a single window property
  window._mh = window._mh || {};
  // Shadow DOM helper functions - search across shadow roots
  function queryShadowSelector(selector, root = document) {
    // First check regular DOM
    let result = root.querySelector ? root.querySelector(selector) : null;
    if (result) return result;

    // Then search in shadow roots
    const wrappers = (root.querySelectorAll ? root : document).querySelectorAll('.mh-wrapper');
    for (const wrapper of wrappers) {
      if (wrapper.shadowRoot) {
        result = wrapper.shadowRoot.querySelector(selector);
        if (result) return result;
      }
    }
    return null;
  }

  function queryShadowSelectorAll(selector, root = document) {
    const results = [];

    // Get from regular DOM
    const rootQuery = root.querySelectorAll ? root : document;
    results.push(...rootQuery.querySelectorAll(selector));

    // Get from shadow roots
    const wrappers = rootQuery.querySelectorAll('.mh-wrapper');
    for (const wrapper of wrappers) {
      if (wrapper.shadowRoot) {
        results.push(...wrapper.shadowRoot.querySelectorAll(selector));
      }
    }
    return results;
  }

  // Get the wrapper element for a shadow DOM element
  function getWrapperForShadowElement(element) {
    if (!element) return null;
    const root = element.getRootNode();
    if (root instanceof ShadowRoot) {
      return root.host;
    }
    return element.closest('.mh-wrapper');
  }

  // Check if a task contains a broken/expired audio element
  // Returns true if the audio file has expired (error_uIAm3 class or error text present)
  function hasBrokenAudio(taskElement) {
    if (!taskElement) return false;

    // Method 1: Check for error class (error_uIAm3, errorCompact_1JF7h)
    const errorElement = taskElement.querySelector('.error_uIAm3, .errorCompact_1JF7h, [class*="error"]');
    if (errorElement) {
      // Verify it's actually an audio error (contains specific error text)
      const errorText = errorElement.textContent || '';
      if (errorText.includes('failed to load') || errorText.includes('Error:') ||
        errorText.includes('does not contain audio')) {
        return true;
      }
    }

    // Method 2: Check for error text directly in the task
    const taskText = taskElement.textContent || '';
    if (taskText.includes('Error: failed to load the audio') ||
      taskText.includes('does not contain audio')) {
      return true;
    }

    // Method 3: Check for audio elements that have error state
    const audioElements = taskElement.querySelectorAll('audio');
    for (const audio of audioElements) {
      // Check if the audio has a network error (error code 4 = MEDIA_ERR_SRC_NOT_SUPPORTED)
      if (audio.error || (audio.networkState === 3)) { // 3 = NETWORK_NO_SOURCE
        return true;
      }
    }

    return false;
  }

  // Ensure an audio element has a wrapper with shadow DOM, creating one if needed
  // This is needed for broken/expired audio that never got an expiration date overlay from content.js
  function ensureWrapperWithShadow(audio) {
    if (!audio) return null;

    let wrapper = audio.closest('.mh-wrapper');
    if (!wrapper) {
      wrapper = audio.parentElement;
      if (!wrapper || !wrapper.classList.contains('mh-wrapper')) {
        // Create wrapper and shadow root for this audio
        wrapper = document.createElement('div');
        wrapper.className = 'mh-wrapper';
        audio.parentNode.insertBefore(wrapper, audio);
        wrapper.appendChild(audio);
      }
    }

    // Create shadow root if it doesn't exist
    if (!wrapper.shadowRoot) {
      const shadow = wrapper.attachShadow({ mode: 'open' });
      const style = document.createElement('style');
      style.textContent = `
        :host { display: block; width: 100%; min-width: 300px; position: relative; margin-bottom: 10px; }
        ::slotted(audio) { width: 100%; }
        .mh-info { font-size: 0.9em; color: #666; margin-top: 5px; display: block; clear: both; width: 100%; min-width: 300px; padding: 2px 4px; transition: all 0.3s ease; border-radius: 3px; }
        .mh-info.highlight { color: white; font-weight: bold; background-color: #ff0000; }
        .mh-s-a { color: white; font-weight: bold; background-color: #2ecc71; }
      `;
      shadow.appendChild(style);
      const slot = document.createElement('slot');
      shadow.appendChild(slot);
    }

    return wrapper;
  }

  // Inject red uncommon indicator for broken/expired audio tasks
  function injectBrokenAudioUncommonIndicator(taskElement) {
    if (!taskElement) return;

    try {
      const audio = taskElement.querySelector('audio');
      if (!audio) return;

      const wrapper = ensureWrapperWithShadow(audio);
      if (!wrapper || !wrapper.shadowRoot) return;

      const shadow = wrapper.shadowRoot;

      // Don't add if highlight already exists
      if (shadow.querySelector('.mh-info.highlight')) return;

      const indicator = document.createElement('div');
      indicator.className = 'mh-info highlight';
      indicator.textContent = 'expired';
      indicator.title = 'Audio file expired/broken - treated as uncommon';
      shadow.appendChild(indicator);
    } catch (e) {
      // Silently fail
    }
  }

  // Inject green saved answer indicator into task's Shadow DOM
  function injectSavedAnswerIndicator(taskElement, matchedText) {
    if (!taskElement) return;

    try {
      const audio = taskElement.querySelector('audio');
      if (!audio) return;

      const wrapper = ensureWrapperWithShadow(audio);
      if (!wrapper || !wrapper.shadowRoot) return;

      const shadow = wrapper.shadowRoot;

      // Check if indicator already exists
      let indicator = shadow.querySelector('.mh-s-a');
      if (indicator) return; // Already has indicator

      // Create the green indicator
      indicator = document.createElement('div');
      indicator.className = 'mh-info mh-s-a';
      indicator.textContent = matchedText.substring(0, 100) + (matchedText.length > 100 ? '…' : '');
      indicator.title = 'Saved answer matched: ' + matchedText;
      shadow.appendChild(indicator);
    } catch (e) {
      // Silently fail if injection fails
    }
  }

  // Store reference to the stealthClick function from content.js
  let stealthClickFn = null;
  let isInitialized = false; // Flag to track initialization

  // Add a Set to track processed tasks by their unique identifiers
  let processedTaskIds = new Set();

  // Default settings
  let settings = {
    defaultSelection: 'ok',
    rules: [],
    textLengthThreshold: 35 // Default threshold for text length
  };

  // Load settings from storage when initializing
  function loadSettings() {
    chrome.storage.local.get('arabicSettings', (data) => {
      if (data.arabicSettings) {
        settings = data.arabicSettings;
      }
    });
  }

  // Listen for settings updates
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'arabicSettingsUpdated' && message.settings) {
      settings = message.settings;
    }
  });

  // Also listen for document events (useful for cross-frame communication)
  document.addEventListener('arabicSettingsUpdated', (event) => {
    if (event.detail && event.detail.settings) {
      settings = event.detail.settings;
    }
  });

  // Show click result text in task container (for debugging which answer was clicked)
  function showClickResultInTask(taskElement, answer) {
    if (!taskElement || !answer) return;

    try {
      chrome.storage.local.get('showClickResult', (data) => {
        if (!data || !data.showClickResult) return; // Respect toggle

        // Find or create wrapper for the audio element in this task
        const audio = taskElement.querySelector('audio');
        let wrapper = audio ? audio.closest('.mh-wrapper') : null;

        if (wrapper && wrapper.shadowRoot) {
          // Inject into Shadow DOM for stealth
          const shadow = wrapper.shadowRoot;

          // Remove existing click result if present
          const existingResult = shadow.querySelector('.mh-click-result');
          if (existingResult) existingResult.remove();

          // Create the result indicator
          const resultDiv = document.createElement('div');
          resultDiv.className = 'mh-click-result';

          // Style based on answer type
          const colors = {
            'ok': '#2ecc71',
            'mistake': '#e74c3c',
            'unclear': '#f39c12'
          };
          const labels = {
            'ok': '✓ OK',
            'mistake': '✗ Mistake',
            'unclear': '? Unclear'
          };

          resultDiv.style.cssText = `
            display: inline-block;
            padding: 4px 10px;
            margin: 5px 0;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            color: white;
            background-color: ${colors[answer] || '#666'};
          `;
          resultDiv.textContent = labels[answer] || answer;

          shadow.appendChild(resultDiv);
        } else {
          // Fallback: inject directly into task container (less stealthy)
          const existingResult = taskElement.querySelector('.mh-click-result-fallback');
          if (existingResult) existingResult.remove();

          const resultDiv = document.createElement('div');
          resultDiv.className = 'mh-click-result-fallback';

          const colors = {
            'ok': '#2ecc71',
            'mistake': '#e74c3c',
            'unclear': '#f39c12'
          };
          const labels = {
            'ok': '✓ OK',
            'mistake': '✗ Mistake',
            'unclear': '? Unclear'
          };

          resultDiv.style.cssText = `
            display: inline-block;
            padding: 4px 10px;
            margin: 5px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            color: white;
            background-color: ${colors[answer] || '#666'};
            position: absolute;
            top: 5px;
            right: 5px;
            z-index: 9999;
          `;
          resultDiv.textContent = labels[answer] || answer;

          // Ensure task has relative positioning for absolute child
          const taskStyle = window.getComputedStyle(taskElement);
          if (taskStyle.position === 'static') {
            taskElement.style.position = 'relative';
          }

          taskElement.appendChild(resultDiv);
        }
      });
    } catch (e) {
      // Silently fail
    }
  }

  // Non-interactive visual indicator above a button to signal a click attempt
  function showClickIndicatorAbove(buttonElement, labelText = 'Attempted') {
    if (!buttonElement) return;
    try {
      chrome.storage.local.get('showClickIndicator', (data) => {
        if (!data || !data.showClickIndicator) return; // Respect toggle
        renderClickIndicator(buttonElement, labelText);
      });
    } catch (_) {
      // Fallback: render without checking storage if messaging isn't available here
      renderClickIndicator(buttonElement, labelText);
    }
  }

  function renderClickIndicator(buttonElement, labelText) {
    if (!buttonElement) return;
    try {
      const marker = document.createElement('div');
      marker.className = 'mh-click-indicator';
      marker.textContent = labelText;
      marker.style.position = 'absolute';
      marker.style.top = '-10px';
      marker.style.left = '50%';
      marker.style.transform = 'translateX(-50%)';
      marker.style.background = 'rgba(10,132,255,0.95)';
      marker.style.color = '#fff';
      marker.style.fontSize = '10px';
      marker.style.lineHeight = '1';
      marker.style.padding = '2px 6px';
      marker.style.borderRadius = '10px';
      marker.style.pointerEvents = 'none';
      marker.style.zIndex = '2147483647';

      const computed = window.getComputedStyle(buttonElement);
      if (computed.position === 'static') {
        buttonElement.style.position = 'relative';
      }
      buttonElement.appendChild(marker);
      setTimeout(() => { try { marker.remove(); } catch (_) { } }, 1500);
    } catch (_) { }
  }

  // Helper function to get a unique identifier for a task
  function getTaskUniqueId(taskElement) {
    // Try to use data attributes first
    const microtaskIndex = taskElement.getAttribute('data-microtask-index');
    const testId = taskElement.getAttribute('data-test-id');

    if (microtaskIndex) return `microtask-${microtaskIndex}`;
    if (testId) return `test-${testId}`;

    // If no attributes, use the task content and position in DOM as a fallback
    const taskContent = taskElement.textContent?.trim().substring(0, 50) || '';
    const elementPath = getElementPath(taskElement);
    return `task-${elementPath}-${taskContent.replace(/\s+/g, '')}`;
  }

  // Helper function to get element's path in DOM
  function getElementPath(element) {
    if (!element || element === document.body) return '';
    let path = '';
    let parent = element.parentElement;
    let index = 0;
    if (parent) {
      const siblings = Array.from(parent.children);
      index = siblings.indexOf(element);
    }
    return `${getElementPath(parent)}-${element.tagName}-${index}`;
  }

  // Helper function to simulate audio events
  function simulateAudioEventsInTask(taskElement) {
    if (!taskElement) return;

    // Find audio in current task
    const audioElements = taskElement.querySelectorAll('audio, .player_2DX_F');
    if (audioElements.length === 0) return;

    // Simulate events for each audio element
    audioElements.forEach(audio => {
      if (!audio) return;

      try {
        // Simulate play event
        audio.dispatchEvent(new Event('play', { bubbles: true }));

        // Simulate timeupdate event
        audio.dispatchEvent(new Event('timeupdate', { bubbles: true }));

        // Simulate ended event
        audio.dispatchEvent(new Event('ended', { bubbles: true }));
      } catch (e) {
        // Silently handle any errors
      }
    });
  }

  // Public interface
  window._mh.aeh = {
    // Initialize with dependencies
    init: function (dependencies) {
      if (isInitialized) {
        return;
      }
      stealthClickFn = dependencies.stealthClick;
      loadSettings();
      isInitialized = true;
      this.isInitialized = true; // Also set the public property

      // Reset processed tasks on each initialization
      processedTaskIds.clear();
    },

    // Public property to check initialization status
    isInitialized: false,

    // Check if the current page contains Arabic evaluation tasks
    detectArabicEvaluation: function () {
      try {
        if (window._mh.dbg) { try { console.log('[MH] Arabic: detect start'); } catch (_) { } }
        // Method 1: Original method - check for RTL elements with specific text
        const rtlElements = Array.from(document.querySelectorAll('div[dir="rtl"] .label_3kPe4, [dir="rtl"] div, div.label_3kPe4'));
        const hasArabicText = rtlElements.some(el => {
          const text = el.textContent || '';
          return text.includes('قيِّم النطق') || text.includes('تقييم') || text.includes('نطق');
        });

        if (hasArabicText) {
          if (window._mh.dbg) { try { console.log('[MH] Arabic: detected via RTL labels'); } catch (_) { } }
          return true;
        }

        // Method 2: Check for buttons with Arabic payloads (likely in Arabic evaluation UI)
        const buttons = document.querySelectorAll('button[payload]');
        const hasArabicButtons = Array.from(buttons).some(btn => {
          const payload = btn.getAttribute('payload') || '';
          return ['ok', 'mispronounced', 'unintelligible'].includes(payload);
        });

        if (hasArabicButtons && buttons.length > 0) {
          if (window._mh.dbg) { try { console.log('[MH] Arabic: detected via buttons'); } catch (_) { } }
          return true;
        }

        // Method 3: Check for any Arabic text in the document, BUT also ensure 
        // there are task evaluation buttons (with 'payload') so we don't trigger 
        // on arbitrary pages that happen to have Arabic text (like Text Marking)
        const allText = document.body.innerText || '';
        const hasAnyArabicChar = /[\u0600-\u06FF]/.test(allText);
        const hasPayloadButtons = document.querySelectorAll('button[payload]').length > 0;

        if (hasAnyArabicChar && hasPayloadButtons) {
          if (window._mh.dbg) { try { console.log('[MH] Arabic: detected via any Arabic text AND payload buttons'); } catch (_) { } }
          return true;
        }

        return false;
      } catch (error) {
        if (window._mh.dbg) { try { console.log('[MH] Arabic: detect error', error); } catch (_) { } }
        // If there's any error in detection, return false
        return false;
      }
    },

    // Main handler function for Arabic evaluation tasks
    handleArabicEvaluationTasks: function () {
      try {
        if (!this.isInitialized) {
          console.error("Arabic handler not initialized. Call init() first.");
          return;
        }

        // Cautious gate: if page has audio but no expiration inserts yet, use a short timed wait instead of skipping
        try {
          const hasAnyTaskAudio = document.querySelectorAll('.tb-task audio, .lUeJm._2t-aw audio').length > 0;
          const hasAnyExpirationInfo = queryShadowSelectorAll('.mh-info').length > 0;
          if (hasAnyTaskAudio && !hasAnyExpirationInfo) {
            const self = this;
            setTimeout(() => {
              try { self.processTasksSequentially(Array.from(document.querySelectorAll('.tb-task, .lUeJm._2t-aw')), 0); } catch (_) { }
            }, this.getRandomDelay(80, 140));
            // Allow flow to continue so scrolling still happens
          }
        } catch (e) { }

        // CLEANUP: Remove all previously injected badges/indicators before re-processing
        try {
          document.querySelectorAll('.mh-mismatch-badge').forEach(el => el.remove());
          // Also clear shadow DOM indicators if needed
          queryShadowSelectorAll('.mh-saved-indicator').forEach(el => el.remove());
        } catch (e) { }

        // Use a more specific selector to get only the real task containers
        // Use a query selector that targets only the parent task containers directly
        let allTaskContainers = Array.from(document.querySelectorAll('.tb-task, .lUeJm._2t-aw'));
        // Fallback for restricted pages that mask classes: look for button[payload] groups
        if (allTaskContainers.length === 0) {
          const btnParents = new Set();
          document.querySelectorAll('button[payload]').forEach(btn => { if (btn.parentElement) btnParents.add(btn.closest('*')); });
          allTaskContainers = Array.from(btnParents);
        }

        // If we can't find direct task containers, fall back to container_2CZFB but only top-level ones
        if (allTaskContainers.length === 0) {
          const containerElements = document.querySelectorAll('.container_2CZFB');
          allTaskContainers = Array.from(containerElements).filter(container => {
            // Only include containers that have button[payload] as direct children or grandchildren
            return container.querySelector('button[payload]') &&
              !container.parentElement.classList.contains('container_2CZFB');
          });
        }
        if (window._mh.dbg) { try { console.log('[MH] Arabic: containers found', allTaskContainers.length); } catch (_) { } }

        if (allTaskContainers.length === 0) {
          // No tasks found, but we should still check for red text
          this.checkAndClickRedText();
          return;
        }

        // Filter out task containers that have already been processed
        const uniqueTaskContainers = allTaskContainers.filter(task => {
          const taskId = getTaskUniqueId(task);
          if (processedTaskIds.has(taskId)) {
            return false; // Skip already processed tasks
          }
          processedTaskIds.add(taskId);
          return true;
        });
        if (window._mh.dbg) { try { console.log('[MH] Arabic: unique containers', uniqueTaskContainers.length); } catch (_) { } }

        if (uniqueTaskContainers.length === 0) {
          // No new tasks, but we should still check for red text
          this.checkAndClickRedText();
          return;
        }

        this.processTasksSequentially(uniqueTaskContainers, 0);
      } catch (error) {
        // If there's an error, we should still try to click any red text
        this.checkAndClickRedText();
      }
    },

    // Helper method to check and click red text
    checkAndClickRedText: function () {
      try {
        const redTextElement = queryShadowSelector('.mh-info.highlight');

        // --- Special Scroll Logic for "فيه مشاكل في النبرة؟" ---
        const pageText = document.body.innerText || "";
        const specificPhrase = "فيه مشاكل في النبرة؟";
        if (pageText.includes(specificPhrase)) {
          // Find FIRST audio ever on the page
          const allAudio = document.querySelectorAll('audio, .player_2DX_F');
          if (allAudio.length > 0) {
            const firstAudio = allAudio[0];
            setTimeout(() => {
              firstAudio.scrollIntoView({ behavior: 'instant', block: 'center' });
              // Also play it!
              if (firstAudio.readyState >= 2) {
                firstAudio.play().catch(() => { });
              } else {
                firstAudio.addEventListener('canplay', () => { firstAudio.play().catch(() => { }); }, { once: true });
              }
            }, 150);

            // Also ensure clicked red text behavior isn't skipped if it was intended, but priority is first audio
          }
          // We still process the rest of the function to simulate events, but we override the scroll target
        } else if (redTextElement) {
          setTimeout(() => {
            // 1. Get the wrapper (works for shadow DOM elements)
            const wrapper = getWrapperForShadowElement(redTextElement);

            // 2. Scroll the wrapper into view (not the shadow element)
            if (wrapper) {
              wrapper.scrollIntoView({ behavior: 'instant', block: 'center' });
            } else {
              redTextElement.scrollIntoView({ behavior: 'instant', block: 'center' });
            }

            // 3. Play audio if present
            const parentContainer = wrapper || redTextElement.closest('.container_2CZFB, .audio-container') || redTextElement.parentElement;
            const audioElement = parentContainer ? parentContainer.querySelector('.player_2DX_F, audio') : null;
            if (audioElement && audioElement.tagName === 'AUDIO') {
              if (audioElement.readyState >= 2) {
                audioElement.play().catch(() => { });
              } else {
                audioElement.addEventListener('canplay', () => {
                  audioElement.play().catch(() => { });
                }, { once: true });
              }
            }

            // 3. Simulate all audio events
            const allAudioElements = document.querySelectorAll('audio, .player_2DX_F');
            allAudioElements.forEach(audio => {
              if (!audio) return;
              try {
                audio.dispatchEvent(new Event('play', { bubbles: true }));
                audio.dispatchEvent(new Event('timeupdate', { bubbles: true }));
                audio.dispatchEvent(new Event('ended', { bubbles: true }));
              } catch (e) { }
            });

            // 4. LAST: Click and focus the red text (or wrapper for shadow DOM)
            setTimeout(() => {
              // Use window._mh.crt if available
              if (typeof window._mh.crt === 'function') {
                window._mh.crt();
              } else {
                // Click on the wrapper (visible element) for shadow DOM elements
                const clickTarget = wrapper || redTextElement;
                if (typeof stealthClickFn === 'function') {
                  stealthClickFn(clickTarget);
                }
                try {
                  if (!clickTarget.hasAttribute('tabindex')) {
                    clickTarget.setAttribute('tabindex', '0');
                  }
                  clickTarget.focus();
                } catch (e) { }
              }
              // Clear any other focus
              const focusTarget = wrapper || redTextElement;
              if (document.activeElement && document.activeElement !== focusTarget && typeof document.activeElement.blur === 'function') {
                document.activeElement.blur();
              }
            }, 30); // Reduced for faster execution

          }, 150); // Reduced for faster execution
        } else {
          // If no red text found, just simulate audio events
          const allAudioElements = document.querySelectorAll('audio, .player_2DX_F');
          allAudioElements.forEach(audio => {
            if (!audio) return;
            try {
              audio.dispatchEvent(new Event('play', { bubbles: true }));
              audio.dispatchEvent(new Event('timeupdate', { bubbles: true }));
              audio.dispatchEvent(new Event('ended', { bubbles: true }));
            } catch (e) { }
          });
        }
      } catch (error) {
        // Silently handle any errors in the red text handling
      }
    },

    // Decide which button to click for a single task (pure logic, no DOM clicks)
    decideTaskAction: function (task, index) {
      try {
        if (!task) return null;

        const buttons = task.querySelectorAll('button[payload]');
        if (buttons.length === 0) return null;

        let buttonToClick = null;
        const payloadMap = {};
        buttons.forEach((button, idx) => {
          payloadMap[button.getAttribute('payload')] = idx;
        });

        // Set the default button based on settings
        if (payloadMap[settings.defaultSelection] !== undefined) {
          buttonToClick = buttons[payloadMap[settings.defaultSelection]];
        } else {
          buttonToClick = buttons[0];
        }

        let isUncommonTask = false;
        let usedSavedAnswer = false;

        // Check for uncommon highlight in the task or its audio wrapper
        const taskWrapper = task.closest('.mh-wrapper');
        if (queryShadowSelector('.mh-info.highlight', task) ||
          queryShadowSelector('.mh-info.highlight', taskWrapper || task)) {
          isUncommonTask = true;
        }

        // Check if this task has broken/expired audio
        if (!isUncommonTask && hasBrokenAudio(task)) {
          isUncommonTask = true;
          injectBrokenAudioUncommonIndicator(task);
        }

        // Check audio elements for uncommon highlights and saved answers
        const audioElements = task.querySelectorAll('audio');

        if (audioElements.length > 0) {
          for (const audio of audioElements) {
            if (!audio || !audio.src) continue;

            const audioUrl = audio.src;

            const wrapper = audio.closest('.mh-wrapper');
            if (wrapper && queryShadowSelector('.mh-info.highlight', wrapper)) {
              isUncommonTask = true;
            }

            if (isUncommonTask && typeof window._mh.uta !== 'undefined') {
              const currentTaskText = this.getTaskText(task);

              const savedEntry = window._mh.fse ?
                window._mh.fse(audioUrl, currentTaskText) : null;

              let savedAnswer = null;
              let savedText = '';

              if (savedEntry) {
                savedAnswer = savedEntry.answer;
                savedText = savedEntry.text || '';
              } else if (!window._mh.fse) {
                const savedData = window._mh.uta?.get(audioUrl);
                if (savedData) {
                  if (typeof savedData === 'string') {
                    savedAnswer = savedData;
                  } else if (Array.isArray(savedData) && savedData.length > 0) {
                    for (const entry of savedData) {
                      if (window._mh.tm && window._mh.tm(entry.text, currentTaskText)) {
                        savedAnswer = entry.answer;
                        savedText = entry.text || '';
                        break;
                      }
                    }
                    if (!savedAnswer && savedData[0]) {
                      savedAnswer = savedData[0].answer;
                      savedText = savedData[0].text || '';
                    }
                  } else if (savedData && typeof savedData === 'object') {
                    savedAnswer = savedData.answer;
                    savedText = savedData.text || '';
                  }
                }
              }

              if (savedAnswer && payloadMap[savedAnswer] !== undefined) {
                buttonToClick = buttons[payloadMap[savedAnswer]];
                usedSavedAnswer = true;
                injectSavedAnswerIndicator(task, savedText || savedAnswer);
                break;
              } else {
                buttonToClick = null;
                usedSavedAnswer = true;
                break;
              }
            }
          }
        }

        if (isUncommonTask && !usedSavedAnswer) {
          buttonToClick = null;
          usedSavedAnswer = true;
        }

        if (!usedSavedAnswer) {
          const taskText = task.textContent || '';
          const ruleResult = this.applyButtonSelectionRules(buttons, taskText, buttonToClick, payloadMap);
          if (ruleResult && ruleResult.button) {
            buttonToClick = ruleResult.button;
            if (ruleResult.matchedPattern) {
              injectSavedAnswerIndicator(task, ruleResult.matchedPattern);
            }
          }
        }

        return { task, buttons, buttonToClick };
      } catch (error) {
        return null;
      }
    },

    // Process all tasks: decide all actions first, then click all buttons in a single burst
    // This prevents the website from scrolling between clicks since JS is single-threaded
    processTasksSequentially: function (tasks, index) {
      try {
        // Phase 1: Decide what to click for every task (synchronous, no DOM side effects besides indicators)
        const actions = [];
        for (let i = index; i < tasks.length; i++) {
          const action = this.decideTaskAction(tasks[i], i);
          if (action) actions.push(action);
        }

        // Phase 2: Click all buttons in a single burst (no delays between tasks)
        for (const action of actions) {
          try {
            if (action.buttonToClick && !action.buttonToClick.disabled) {
              if (window._mh.dbg) { try { console.log('[MH] Arabic: clicking payload', action.buttonToClick.getAttribute('payload')); } catch (_) { } }
              showClickIndicatorAbove(action.buttonToClick, 'Click: ' + (action.buttonToClick.getAttribute('payload') || ''));
              if (typeof stealthClickFn === 'function') {
                stealthClickFn(action.buttonToClick);
                simulateAudioEventsInTask(action.task);
                showClickResultInTask(action.task, action.buttonToClick.getAttribute('payload'));
              }
            } else if (action.buttonToClick && action.buttonToClick.disabled) {
              try { showClickIndicatorAbove(action.buttonToClick, 'Disabled: ' + (action.buttonToClick.getAttribute('payload') || '')); } catch (_) { }
              const taskId = getTaskUniqueId(action.task);
              processedTaskIds.delete(taskId);
              simulateAudioEventsInTask(action.task);
            } else {
              // No button to click (uncommon without saved answer) - still simulate audio
              try {
                if (action.buttons && action.buttons.length > 0) {
                  showClickIndicatorAbove(action.buttons[0], 'Skip (test)');
                }
              } catch (_) { }
              simulateAudioEventsInTask(action.task);
            }
          } catch (e) {
            if (window._mh.dbg) { try { console.log('[MH] Arabic: click error', e); } catch (_) { } }
          }
        }

        // Phase 3: After all clicks, check for red text (uncommon task to review)
        this.checkAndClickRedText();
      } catch (error) {
        // If something goes wrong, still try to handle red text
        this.checkAndClickRedText();
      }
    },

    applyButtonSelectionRules: function (buttons, taskText, defaultButton, payloadMap) {
      if (!buttons || buttons.length === 0) {
        return { button: defaultButton, matchedPattern: null };
      }

      // Use helper to get clean text
      const taskContainer = buttons[0].closest('.tb-task, .lUeJm._2t-aw, .container_2CZFB');
      const contentText = this.getTaskText(taskContainer) || taskText;

      // Check text length first - this takes priority over other rules
      const textLengthThreshold = settings.textLengthThreshold || 35;
      if (contentText.length > textLengthThreshold && payloadMap['mistake'] !== undefined) {
        return { button: buttons[payloadMap['mistake']], matchedPattern: null };
      }

      // If text length check didn't apply, continue with existing rule logic
      if (!settings.rules || settings.rules.length === 0) {
        return { button: defaultButton, matchedPattern: null };
      }

      // First check for exact matches
      for (const rule of settings.rules) {
        if (rule.pattern && rule.pattern.trim() !== '') {
          const trimmedPattern = rule.pattern.trim();
          // Try exact match first
          if (taskText.includes(trimmedPattern)) {
            if (payloadMap[rule.action] !== undefined) {
              return { button: buttons[payloadMap[rule.action]], matchedPattern: trimmedPattern };
            }
          }
        }
      }

      // If no exact match found, try case-insensitive matching
      for (const rule of settings.rules) {
        if (rule.pattern && rule.pattern.trim() !== '') {
          const trimmedPattern = rule.pattern.trim();
          const taskTextLower = taskText.toLowerCase();
          const patternLower = trimmedPattern.toLowerCase();

          if (taskTextLower.includes(patternLower)) {
            if (payloadMap[rule.action] !== undefined) {
              return { button: buttons[payloadMap[rule.action]], matchedPattern: trimmedPattern };
            }
          }
        }
      }

      return { button: defaultButton, matchedPattern: null };
    },

    getRandomDelay: function (min, max) {
      // Gaussian-like distribution for more natural, less detectable timing
      let u = 0, v = 0;
      while (u === 0) u = Math.random();
      while (v === 0) v = Math.random();
      let num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
      // Transform to 0-1 range (clamped)
      num = Math.max(0, Math.min(1, (num + 3) / 6));
      return Math.floor(min + num * (max - min));
    },

    // Verify if saved text matches current text roughly
    verifyTextMatch: function (savedText, currentText) {
      if (!savedText || !currentText) return { match: true }; // Can't verify, assume safe

      const normalize = t => t.replace(/[^\u0621-\u064A\s]/g, '').replace(/\s+/g, ' ').trim();
      const s = normalize(savedText);
      const c = normalize(currentText);

      // If one contains the other, or similarity is high enough
      if (s.includes(c) || c.includes(s)) return { match: true };

      // Basic overlap check for long texts
      if (s.length > 20 && c.length > 20) {
        const sPart = s.substring(0, 20);
        if (c.includes(sPart)) return { match: true };
      }

      // Safety Fallback: If current text is very short/empty, assume safe to avoid blocking
      if (c.length < 5) return { match: true };

      return { match: false };
    },

    // Extract clean task text
    getTaskText: function (taskElement) {
      if (!taskElement) return '';
      let text = '';

      // Strategy 1: Look for specific RTL containers
      const rtlContainers = taskElement.querySelectorAll('div[dir="rtl"]');
      rtlContainers.forEach(container => {
        const t = container.textContent || '';
        if (!t.includes('قيِّم النطق') && !t.includes('تقييم') && !t.includes('نطق')) {
          // Avoid adding button text
          if (!container.querySelector('button')) {
            text += t.trim() + ' ';
          }
        }
      });

      // Strategy 2: If nothing found, try specific class logic
      if (!text.trim()) {
        const containers = taskElement.querySelectorAll('.container_3rKiN');
        containers.forEach(c => text += c.textContent.trim() + ' ');
      }

      // Strategy 3: Clone and strip buttons (Last resort)
      if (!text.trim()) {
        try {
          const clone = taskElement.cloneNode(true);
          const buttons = clone.querySelectorAll('button, input, .mh-info, .mh-mismatch-badge, .mh-saved-indicator, script, style');
          buttons.forEach(b => b.remove());
          text = clone.textContent || '';
        } catch (e) { }
      }

      return text.trim();
    },

    // Add a method to explicitly reset processed tasks
    resetProcessedTasks: function () {
      processedTaskIds.clear();
    }
  };
})(); 
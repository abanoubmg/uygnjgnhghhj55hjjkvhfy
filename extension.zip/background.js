// === Media Helper + Geno Audio Helper Combined Background Script ===

let allAudioInfo = new Map();
let refreshInProgress = false;
let pendingRequests = new Set();

// Default audio settings
const defaultAudioSettings = {
  energyThreshold: 0.001,
  variationThreshold: 0.4,
  zeroCrossingThreshold: 0.35,
  minSegmentDuration: 6,
  segmentVariationThreshold: 0.15
};

// Initialize allAudioInfo from storage
chrome.storage.local.get(['allAudioInfo', 'audioSettings'], (data) => {
  if (data.allAudioInfo) {
    allAudioInfo = new Map(data.allAudioInfo);
    console.log('Loaded audio info from storage');
  }

  // Initialize audio settings if not present
  if (!data.audioSettings) {
    chrome.storage.local.set({ audioSettings: defaultAudioSettings });
    console.log('Initialized default audio settings');
  }
});

// Create context menu items for text selection
function createContextMenuItems() {
  // Remove existing menu items first
  chrome.contextMenus.removeAll(() => {
    // Parent menu item
    chrome.contextMenus.create({
      id: "textClassification",
      title: "Classify Text",
      contexts: ["selection"]
    });

    // Sub-menu items for classification
    chrome.contextMenus.create({
      id: "classifyOk",
      parentId: "textClassification",
      title: "OK (صحيح)",
      contexts: ["selection"]
    });

    chrome.contextMenus.create({
      id: "classifyMistake",
      parentId: "textClassification",
      title: "Mistake (خاطىء)",
      contexts: ["selection"]
    });

    chrome.contextMenus.create({
      id: "classifyUnclear",
      parentId: "textClassification",
      title: "Unclear (غير واضح)",
      contexts: ["selection"]
    });
  });
}

// Handle the context menu click events
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!info.selectionText) return;

  let classification = "";
  switch (info.menuItemId) {
    case "classifyOk":
      classification = "ok";
      break;
    case "classifyMistake":
      classification = "mistake";
      break;
    case "classifyUnclear":
      classification = "unclear";
      break;
    default:
      return;
  }

  // Save the classification to storage
  saveTextClassification(info.selectionText, classification);
});

// Save the classified text to storage
function saveTextClassification(text, classification) {
  chrome.storage.local.get('textClassifications', (data) => {
    const classifications = data.textClassifications || [];

    // Add new classification with timestamp
    classifications.push({
      text: text,
      classification: classification,
      timestamp: new Date().toISOString()
    });

    // Only keep the most recent 100 classifications
    const trimmedClassifications = classifications.slice(-100);

    // Save to storage
    chrome.storage.local.set({ textClassifications: trimmedClassifications }, () => {
      // Notify options page if it's open
      chrome.runtime.sendMessage({
        action: 'textClassificationAdded',
        data: {
          text: text,
          classification: classification
        }
      });

      // Add as a rule for Arabic evaluation if settings exist
      chrome.storage.local.get('arabicSettings', (data) => {
        if (data.arabicSettings) {
          const settings = data.arabicSettings;
          const existingRuleIndex = settings.rules.findIndex(rule => rule.pattern === text);

          if (existingRuleIndex >= 0) {
            // Update existing rule
            settings.rules[existingRuleIndex].action = classification;
          } else {
            // Add new rule
            settings.rules.push({
              pattern: text,
              action: classification
            });
          }

          // Save updated settings
          chrome.storage.local.set({ arabicSettings: settings }, () => {
            // Broadcast the updated settings
            broadcastArabicSettings(settings);
          });
        }
      });
    });
  });
}

// Clean up expired entries
function cleanUpAudioInfo() {
  const currentDate = new Date();
  const cleanedAudioInfo = Array.from(allAudioInfo.entries()).filter(([url, expirationDate]) => {
    try {
      return new Date(expirationDate) > currentDate;
    } catch (error) {
      console.error('Invalid date in storage:', expirationDate);
      return false;
    }
  });
  allAudioInfo = new Map(cleanedAudioInfo);
  chrome.storage.local.set({ allAudioInfo: cleanedAudioInfo });
}

// Perform initial cleanup
cleanUpAudioInfo();

// Inject content script into existing tabs upon installation or update
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed/updated');

  // Create context menu items
  createContextMenuItems();

  chrome.tabs.query({}, (tabs) => {
    for (let tab of tabs) {
      if (tab.url && tab.url.startsWith('http')) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id, allFrames: true },
            files: ['content.js']
          },
          () => {
            if (chrome.runtime.lastError) {
              console.error('Error injecting content script:', chrome.runtime.lastError.message);
            } else {
              console.log('Content script injected into tab', tab.id);
            }
          }
        );
      }
    }
  });
});

// Inject content script into dynamically loaded iframes
chrome.webNavigation.onCompleted.addListener(
  (details) => {
    if (details.frameId !== 0) {
      console.log('Frame completed:', details.url);
      chrome.scripting.executeScript(
        {
          target: { tabId: details.tabId, frameIds: [details.frameId] },
          files: ['content.js']
        },
        () => {
          if (chrome.runtime.lastError) {
            console.error('Error injecting content script into frame:', chrome.runtime.lastError.message);
          } else {
            console.log('Content script injected into frame', details.frameId);
          }
        }
      );
    }
  },
  { url: [{ urlMatches: '<all_urls>' }] }
);

// Enhanced audio detection
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    try {
      const contentTypeHeader = details.responseHeaders.find(
        (header) => header.name.toLowerCase() === 'content-type'
      );
      const isAudio =
        details.type === 'media' ||
        (contentTypeHeader && /audio\//i.test(contentTypeHeader.value)) ||
        /\.(mp3|wav|ogg|m4a)$/i.test(details.url) ||
        details.url.includes('storage.mds.yandex.net');
      if (isAudio) {
        processHeaders(details);
      }
    } catch (error) {
      console.error('Error in onHeadersReceived:', error);
    }
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

function processHeaders(details) {
  try {
    const expirationHeader = details.responseHeaders.find(
      (header) => header.name.toLowerCase() === 'x-mds-expiration-date'
    );
    if (expirationHeader) {
      updateAudioInfo(details.url, expirationHeader.value, details.tabId, details.frameId);
    }
  } catch (error) {
    console.error('Error in processHeaders:', error);
  }
}

function updateAudioInfo(url, expirationDate, tabId, frameId) {
  try {
    if (expirationDate === 'NO_DATE') {
      allAudioInfo.set(url, 'NO_DATE');
    } else {
      const date = new Date(expirationDate);
      if (isNaN(date.getTime())) {
        console.warn('Invalid expiration date received:', expirationDate);
        return;
      }
      allAudioInfo.set(url, expirationDate);
    }
    chrome.storage.local.set({ allAudioInfo: Array.from(allAudioInfo.entries()) }, () => {
      console.log('Audio info saved to storage');
    });
    if (typeof tabId === 'number' && tabId >= 0) {
      broadcastAudioInfoToTab(tabId);
    }
  } catch (error) {
    console.error('Error processing expiration date:', error);
  }
}

function broadcastAudioInfoToTab(tabId) {
  chrome.webNavigation.getAllFrames({ tabId }, (frames) => {
    if (chrome.runtime.lastError) {
      console.error('Error getting frames:', chrome.runtime.lastError);
      return;
    }
    if (!frames) return;
    const audioInfoArray = Array.from(allAudioInfo.entries());
    frames.forEach(frame => {
      chrome.tabs.sendMessage(
        tabId,
        {
          type: 'allAudioInfo',
          audioInfo: audioInfoArray
        },
        { frameId: frame.frameId },
        () => {
          if (chrome.runtime.lastError) {
            // This is normal for frames without content script
            console.debug('Could not send to frame:', frame.frameId);
          }
        }
      );
    });
  });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getAudioInfo') {
    sendResponse({ audioInfo: Array.from(allAudioInfo.entries()) });
  } else if (request.action === 'checkAudioUrl') {
    if (!pendingRequests.has(request.url) && !allAudioInfo.has(request.url)) {
      pendingRequests.add(request.url);
      fetch(request.url, { method: 'HEAD' })
        .then(response => {
          const expirationDate = response.headers.get('x-mds-expiration-date');
          if (expirationDate) {
            updateAudioInfo(request.url, expirationDate, sender.tab.id, sender.frameId);
          } else {
            updateAudioInfo(request.url, 'NO_DATE', sender.tab.id, sender.frameId);
          }
        })
        .catch(error => {
          console.error('Error fetching headers:', error);
          updateAudioInfo(request.url, 'NO_DATE', sender.tab.id, sender.frameId);
        })
        .finally(() => {
          pendingRequests.delete(request.url);
        });
    }
  } else if (request.action === 'getPendingHeaderStatus') {
    try {
      const pendingUrls = Array.from(pendingRequests.values());
      sendResponse({
        pendingCount: pendingUrls.length,
        pendingUrls,
        totalKnown: allAudioInfo.size
      });
    } catch (e) {
      sendResponse({ pendingCount: 0, pendingUrls: [], totalKnown: allAudioInfo.size });
    }
    return true;
  } else if (request.action === 'getAudioSettings') {
    chrome.storage.local.get('audioSettings', (data) => {
      sendResponse({ audioSettings: data.audioSettings || defaultAudioSettings });
    });
    return true; // Required for asynchronous sendResponse
  } else if (request.action === 'getDebugLogging') {
    chrome.storage.local.get('debugLogging', (data) => {
      sendResponse({ debugLogging: !!data.debugLogging });
    });
    return true;
  } else if (request.action === 'debugLoggingUpdated') {
    try {
      broadcastDebugLogging(!!request.debugLogging);
    } catch (_) { }
  } else if (request.action === 'showClickIndicatorUpdated') {
    try {
      broadcastShowClickIndicator(!!request.enabled);
    } catch (_) { }
  } else if (request.action === 'audioSettingsUpdated') {
    // Broadcast updated audio settings
    broadcastAudioSettings(request.settings);
  } else if (request.action === 'getArabicSettings') {
    // Return Arabic evaluation settings
    chrome.storage.local.get('arabicSettings', (data) => {
      sendResponse({ arabicSettings: data.arabicSettings || { defaultSelection: 'ok', textLengthThreshold: 35, rules: [] } });
    });
    return true; // Required for asynchronous sendResponse
  } else if (request.action === 'arabicSettingsUpdated') {
    // Broadcast updated Arabic settings to all tabs
    broadcastArabicSettings(request.settings);
  } else if (request.action === 'classifySelectedText') {
    // Handle text classification from content script (Android workaround)
    if (request.text && request.classification) {
      saveTextClassification(request.text, request.classification);
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false });
    }
    return true;
  } else if (request.action === 'triggerFullReset') {
    if (sender.tab && sender.tab.id) {
      refreshAudioInfo(sender.tab.id);
      sendResponse({ success: true });
    }
    return true;
  } else if (request.action === 'openOptionsPage') {
    chrome.runtime.openOptionsPage();
    return true;
  } else if (request.action === 'pushTextMarkingAnswersToCloud') {
    const FIREBASE_TM_URL = 'https://geno-e0098-default-rtdb.firebaseio.com/sync/textMarkingAnswers.json';
    
    fetch(FIREBASE_TM_URL)
      .then(res => res.json())
      .then(cloudData => {
         let cloudAnswers = Array.isArray(cloudData) ? cloudData : [];
         let merged = [...(request.newEntries || [])];
         
         cloudAnswers.forEach(cloudEntry => {
            const existingIdx = merged.findIndex(e =>
               e.audioUrl === cloudEntry.audioUrl && e.segmentText === cloudEntry.segmentText
            );
            if (existingIdx === -1) {
               merged.push(cloudEntry);
            }
         });
         
         return fetch(FIREBASE_TM_URL, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(merged)
         });
      })
      .then(() => { if (sendResponse) { try { sendResponse({ success: true }); } catch(e){} } })
      .catch(e => { if (sendResponse) { try { sendResponse({ success: false, error: e.message }); } catch(e){} } });
      
    return true; 
  } else if (request.action === 'pullTextMarkingAnswersFromCloud') {
    const FIREBASE_TM_URL = 'https://geno-e0098-default-rtdb.firebaseio.com/sync/textMarkingAnswers.json';
    
    fetch(FIREBASE_TM_URL)
      .then(res => res.json())
      .then(cloudData => {
         if (!cloudData || !Array.isArray(cloudData)) {
            if (sendResponse) { try { sendResponse({ success: true, count: 0 }); } catch(e){} }
            return;
         }
         
         chrome.storage.local.get('textMarkingAnswers', (localData) => {
            let localAnswers = localData.textMarkingAnswers || [];
            let merged = [...localAnswers];
            
            cloudData.forEach(cloudEntry => {
               const existingIdx = merged.findIndex(e =>
                  e.audioUrl === cloudEntry.audioUrl && e.segmentText === cloudEntry.segmentText
               );
               if (existingIdx >= 0) {
                  merged[existingIdx] = cloudEntry; 
               } else {
                  merged.push(cloudEntry);
               }
            });
            
            chrome.storage.local.set({ textMarkingAnswers: merged }, () => {
               if (sendResponse) { try { sendResponse({ success: true, count: merged.length }); } catch(e){} }
            });
         });
      })
      .catch(e => {
         if (sendResponse) { try { sendResponse({ success: false, error: e.message }); } catch(e){} }
      });
      
    return true;
  }
});

// Broadcast audio settings updates to all tabs
function broadcastAudioSettings(settings) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.url && tab.url.startsWith('http')) {
        chrome.tabs.sendMessage(
          tab.id,
          {
            type: 'audioSettingsUpdated',
            audioSettings: settings
          },
          { frameId: 0 },
          () => {
            if (chrome.runtime.lastError) {
              console.log('Error sending settings update:', chrome.runtime.lastError);
            }
          }
        );
      }
    }
  });
}

// Broadcast Arabic evaluation settings to all tabs
function broadcastArabicSettings(settings) {
  console.log("Broadcasting Arabic settings to all tabs:", settings);

  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.url && tab.url.startsWith('http')) {
        // Send to all frames, not just the main frame
        chrome.tabs.sendMessage(
          tab.id,
          {
            type: 'arabicSettingsUpdated',
            settings: settings
          },
          () => {
            if (chrome.runtime.lastError) {
              console.log('Error sending Arabic settings update:', chrome.runtime.lastError);
            }
          }
        );

        // Also try sending without frameId to reach content scripts in all frames
        try {
          chrome.tabs.sendMessage(
            tab.id,
            {
              type: 'arabicSettingsUpdated',
              settings: settings
            }
          );
        } catch (e) {
          console.log('Error in second attempt to send settings:', e);
        }
      }
    }
  });
}

function broadcastDebugLogging(enabled) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.url && tab.url.startsWith('http')) {
        chrome.tabs.sendMessage(
          tab.id,
          { type: 'debugLoggingUpdated', enabled },
          () => { }
        );
      }
    }
  });
}

function broadcastShowClickIndicator(enabled) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (tab.url && tab.url.startsWith('http')) {
        chrome.tabs.sendMessage(
          tab.id,
          { type: 'showClickIndicatorUpdated', enabled },
          () => { }
        );
      }
    }
  });
}

// --- Geno Audio Helper: Action Button and Keyboard Shortcut ---

function triggerSelectOptions(tab) {
  if (tab && tab.id) {
    chrome.tabs.sendMessage(tab.id, {
      action: "refreshAudioInfoAndSelectOptions"
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.warn(`Error sending message to tab ${tab.id}: ${chrome.runtime.lastError.message}`);
      }
    });
  } else {
    console.warn("Could not trigger selectOptions: Invalid tab.");
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (tab && tab.url && tab.url.startsWith('http')) {
    // Step 1: Refresh audio info for this tab
    refreshAudioInfo(tab.id);
    // Step 2: After a short delay, broadcast audio info and trigger Geno logic via message
    setTimeout(() => {
      broadcastAudioInfoToTab(tab.id);
      // Step 3: Send message to all frames to do a full refresh and Geno logic
      chrome.webNavigation.getAllFrames({ tabId: tab.id }, (frames) => {
        if (frames) {
          frames.forEach(frame => {
            chrome.tabs.sendMessage(
              tab.id,
              { action: 'fullRefreshAndSelect' },
              { frameId: frame.frameId }
            );
          });
        }
      });
    }, 100);
  }
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command === "select-options") {
    if (tab && tab.url && tab.url.startsWith('http')) {
      refreshAudioInfo(tab.id);
      setTimeout(() => {
        broadcastAudioInfoToTab(tab.id);
        chrome.webNavigation.getAllFrames({ tabId: tab.id }, (frames) => {
          if (frames) {
            frames.forEach(frame => {
              chrome.tabs.sendMessage(
                tab.id,
                { action: 'fullRefreshAndSelect' },
                { frameId: frame.frameId }
              );
            });
          }
        });
      }, 500);
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('http')) {
          refreshAudioInfo(tabs[0].id);
          setTimeout(() => {
            broadcastAudioInfoToTab(tabs[0].id);
            chrome.webNavigation.getAllFrames({ tabId: tabs[0].id }, (frames) => {
              if (frames) {
                frames.forEach(frame => {
                  chrome.tabs.sendMessage(
                    tabs[0].id,
                    { action: 'fullRefreshAndSelect' },
                    { frameId: frame.frameId }
                  );
                });
              }
            });
          }, 500);
        } else {
          console.error("Could not find active tab for command.");
        }
      });
    }
  } else if (command === "capture-uncommon-answers") {
    // Handle Ctrl+M for capturing uncommon task answers
    if (tab && tab.url && tab.url.startsWith('http')) {
      // Send message to all frames in the tab
      chrome.webNavigation.getAllFrames({ tabId: tab.id }, (frames) => {
        if (frames) {
          frames.forEach(frame => {
            chrome.tabs.sendMessage(
              tab.id,
              { action: 'captureUncommonAnswers' },
              { frameId: frame.frameId }
            );
          });
        }
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('http')) {
          chrome.webNavigation.getAllFrames({ tabId: tabs[0].id }, (frames) => {
            if (frames) {
              frames.forEach(frame => {
                chrome.tabs.sendMessage(
                  tabs[0].id,
                  { action: 'captureUncommonAnswers' },
                  { frameId: frame.frameId }
                );
              });
            }
          });
        } else {
          console.error("Could not find active tab for command.");
        }
      });
    }
  } else if (command === "clear-uncommon-answers") {
    // Handle Ctrl+Shift+M for clearing all saved uncommon task answers
    if (tab && tab.url && tab.url.startsWith('http')) {
      // Send message to all frames in the tab
      chrome.webNavigation.getAllFrames({ tabId: tab.id }, (frames) => {
        if (frames) {
          frames.forEach(frame => {
            chrome.tabs.sendMessage(
              tab.id,
              { action: 'clearUncommonAnswers' },
              { frameId: frame.frameId }
            );
          });
        }
      });
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs.length > 0 && tabs[0].url && tabs[0].url.startsWith('http')) {
          chrome.webNavigation.getAllFrames({ tabId: tabs[0].id }, (frames) => {
            if (frames) {
              frames.forEach(frame => {
                chrome.tabs.sendMessage(
                  tabs[0].id,
                  { action: 'clearUncommonAnswers' },
                  { frameId: frame.frameId }
                );
              });
            }
          });
        } else {
          console.error("Could not find active tab for command.");
        }
      });
    }
  }
});

function refreshAudioInfo(tabId) {
  if (refreshInProgress) return;

  refreshInProgress = true;
  console.log('Refreshing audio information');

  // Clear current audio info
  allAudioInfo = new Map();

  // Save empty map to storage
  chrome.storage.local.set({ allAudioInfo: [] }, () => {
    console.log('Cleared audio info storage');

    // Notify all tabs about the reset
    chrome.tabs.query({}, (tabs) => {
      for (const tab of tabs) {
        if (tab.url && tab.url.startsWith('http')) {
          chrome.tabs.sendMessage(
            tab.id,
            { type: 'refreshAudioInfo' },
            { frameId: 0 },
            () => {
              if (chrome.runtime.lastError) {
                console.log('Error sending refresh message:', chrome.runtime.lastError);
              }
            }
          );
        }
      }
    });

    refreshInProgress = false;
  });
}

chrome.webNavigation.onCommitted.addListener((details) => {
  // Only trigger for the main frame
  if (details.frameId === 0 && details.tabId >= 0) {
    chrome.webNavigation.getAllFrames({ tabId: details.tabId }, (frames) => {
      if (frames) {
        frames.forEach(frame => {
          chrome.tabs.sendMessage(
            details.tabId,
            { action: 'fullRefreshAndSelect' },
            { frameId: frame.frameId }
          );
        });
      }
    });
  }
});